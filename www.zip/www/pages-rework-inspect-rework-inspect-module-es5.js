(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-rework-inspect-rework-inspect-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/inspect-po/inspect-po.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/rework-inspect/inspect-po/inspect-po.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>{{ list && list.length && $any(list[0]).factory_name }}</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-back-button text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card *ngFor=\"let item of list\" mode=\"ios\">\n        <ion-item class=\"card-header\">\n            <ion-icon name=\"people\" slot=\"start\" color=\"primary\"></ion-icon>\n            <ion-label><span>合同号:</span> {{ item.contract_no }}</ion-label>\n        </ion-item>\n\n        <ion-card-content>\n            <ion-grid>\n                <ion-row class=\"title\">\n                    <ion-col align-self-center [size]=\"3\">\n                        SKU\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        中文名\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"2\">\n                        合同箱数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        操作\n                    </ion-col>\n                </ion-row>\n\n                <ion-row *ngFor=\"let sItem of item.data\">\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.sku }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.sku_chinese_name }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"2\">\n                        {{ sItem.quantity }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"4\" class=\"ion-col-no-pad\">\n                        <div>\n                            <ion-button\n                                size=\"small\"\n                                fill=\"clear\"\n                                class=\"f-l\"\n                                color=\"primary\"\n                                (click)=\"feedback(item, sItem)\"\n                                >问题描述\n                            </ion-button>\n                            <ion-button\n                                fill=\"clear\"\n                                size=\"small\"\n                                class=\"f-l\"\n                                [routerLink]=\"[\n                                    '/rework-inspect/rework-sku',\n                                    apply_inspect_no,\n                                    item.contract_no,\n                                    sItem.sku\n                                ]\"\n                                >去验货\n                            </ion-button>\n                        </div>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-card-content>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/rework-inspect.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/rework-inspect/rework-inspect.page.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>返工验货</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar\n        animated\n        clearInput\n        mode=\"ios\"\n        placeholder=\"输入工厂名检索\"\n        (ionChange)=\"factoryChange()\"\n        [(ngModel)]=\"getListParams.value\"\n    ></ion-searchbar>\n\n    <ion-button fill=\"clear\" expand=\"full\" *ngIf=\"!inspectTask || !inspectTask.length\" (click)=\"ionViewWillEnter()\"\n        >重新获取</ion-button\n    >\n    <ion-card *ngFor=\"let item of inspectTask\" mode=\"ios\">\n        <ion-item class=\"card-header\">\n            <ion-icon name=\"people\" slot=\"start\" color=\"primary\"></ion-icon>\n            <ion-label><span>验货工厂：</span>{{ item.factory_name }}</ion-label>\n            <ion-label class=\"text-c\"><span>工厂联系人：</span>{{ item.factory_contacts }}</ion-label>\n        </ion-item>\n\n        <ion-card-content>\n            <ion-grid>\n                <ion-row class=\"title\">\n                    <ion-col align-self-center [size]=\"3\">\n                        验货流水号\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        验货合同数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        验货SKU数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        操作\n                    </ion-col>\n                </ion-row>\n\n                <ion-row *ngFor=\"let sItem of item.data\">\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.apply_inspection_no }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.contract_total }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.sku_total }}\n                    </ion-col>\n                    <ion-col\n                        align-self-center\n                        [size]=\"3\"\n                        class=\"ion-col-no-pad\"\n                        fxLayout=\"row\"\n                        fxLayoutAlign=\"start center\"\n                    >\n                        <ion-button\n                            fill=\"clear\"\n                            size=\"small\"\n                            [routerLink]=\"['/rework-inspect/rework-po',sItem.apply_inspection_no]\"\n                            >查看详情</ion-button\n                        >\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-card-content>\n    </ion-card>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n        <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"正在加载\"> </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n    <p *ngIf=\"!inspectTask.length\" class=\"text-c \">暂无数据</p>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/rework-sku/rework-sku.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/rework-inspect/rework-sku/rework-sku.component.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>{{ sku }}</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-back-button text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content [formGroup]=\"skuInspectModel\">\n    <app-sku-info [sku]=\"skuInfo\" type=\"implement\"></app-sku-info>\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>验货时间/数量</p>\n                </div>\n\n                <div class=\"other-item\">\n                    <ion-item>\n                        <ion-label>验货时间</ion-label>\n                        <ion-datetime\n                            cancelText=\"取消\"\n                            doneText=\"确定\"\n                            displayFormat=\"YYYY-MM-DD\"\n                            formGroupName=\"inspectionDate\"\n                            value=\"2012-12-15T13:47:20.789\"\n                        >\n                        </ion-datetime>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label position=\"floating\">拆箱数量</ion-label>\n                        <ion-input\n                            (ionChange)=\"numChange($event)\"\n                            placeholder=\"输入拆箱数量\"\n                            type=\"number\"\n                            formGroupName=\"unpackingNum\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>拆箱比例</ion-label>\n                        <span>{{ unpackingPercent | number: '1.2' }}</span\n                        >%\n                    </ion-item>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list>\n        <ion-item formGroupName=\"barCode\">\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>条码</p>\n                </div>\n                <div class=\"bar-code\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                    <input class=\"h-30\" placeholder=\"请输入条码\" formControlName=\"text\" />\n                    <ion-button fill=\"clear\">{{ barCode }}</ion-button>\n                    <ion-button fill=\"clear\" (click)=\"scan('inner')\">\n                        扫码\n                    </ion-button>\n                    <ion-button\n                        color=\"success\"\n                        size=\"small\"\n                        fill=\"clear\"\n                        *ngIf=\"barCode === skuInspectModel.get('barCode').get('text')\"\n                    >\n                        扫码已通过\n                    </ion-button>\n                </div>\n                <app-photograph\n                    type=\"bar_code_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"skuInspectModel.value.barCode.photos\"\n                    [contract_no]=\"contract_no\"\n                    [apply_inspection_no]=\"apply_inspection_no\"\n                    [sku]=\"skuInfo.sku\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box mt-10\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"skuInspectModel.value.barCode.desc\"\n                        (onComplete)=\"descEnter($event, 'barCode')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n\n    <ion-list>\n        <ion-item class=\"w100\">\n            <div class=\"w100 other-item\">\n                <div class=\"global-inspect-title\">\n                    <p>问题阐述</p>\n                </div>\n\n                <ion-item class=\"ion-activated\">\n                    <ion-icon name=\"text\" slot=\"start\"></ion-icon>\n                    <ul>\n                        <li\n                            *ngFor=\"let item of question.desc; let i = index\"\n                            [ngStyle]=\"{ color: item.color ? item.color : '#000' }\"\n                        >\n                            {{ i + 1 + '.    ' + item.text }}\n                        </li>\n                    </ul>\n                </ion-item>\n\n                <ion-item class=\"ion-activated w100\">\n                    <ion-icon name=\"image\" slot=\"start\"></ion-icon>\n                    <ul class=\"img-list\" *ngIf=\"skuInfo && question.review_summary_img; else noData\" imgGallery>\n                        <li *ngFor=\"let item of question.review_summary_img\">\n                            <img [src]=\"imgOrigin + item\" alt=\"\" />\n                        </li>\n                    </ul>\n                </ion-item>\n\n                <ion-item class=\"ion-activated w100\">\n                    <ion-icon name=\"videocam\" slot=\"start\"></ion-icon>\n                    <ul class=\"vdo-list\" *ngIf=\"skuInfo && question.review_summary_video; else noData\">\n                        <li *ngFor=\"let item of question.review_summary_video\" (click)=\"play(item)\">\n                            <video [src]=\"imgOrigin + item\" poster=\"\"></video>\n                        </li>\n                    </ul>\n                </ion-item>\n            </div>\n        </ion-item>\n    </ion-list>\n\n    <ion-list class=\"w100\">\n        <ion-item class=\"w100\">\n            <ion-button expand=\"block\" class=\"w100\" (click)=\"submit()\">提交</ion-button>\n        </ion-item>\n    </ion-list>\n</ion-content>\n\n<ng-template #noData>暂无</ng-template>\n"

/***/ }),

/***/ "./src/app/pages/rework-inspect/inspect-po/inspect-po.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/rework-inspect/inspect-po/inspect-po.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Jld29yay1pbnNwZWN0L2luc3BlY3QtcG8vaW5zcGVjdC1wby5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/rework-inspect/inspect-po/inspect-po.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/rework-inspect/inspect-po/inspect-po.component.ts ***!
  \*************************************************************************/
/*! exports provided: InspectPoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectPoComponent", function() { return InspectPoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _feedback_feedback_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../feedback/feedback.component */ "./src/app/pages/rework-inspect/feedback/feedback.component.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _rework_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../rework.service */ "./src/app/pages/rework-inspect/rework.service.ts");






var InspectPoComponent = /** @class */ (function () {
    function InspectPoComponent(es, router, reworkCtrl) {
        var _this = this;
        this.es = es;
        this.reworkCtrl = reworkCtrl;
        this.factory_name = '天府三街新希望国际';
        this.list = [];
        this.apply_inspect_no = "";
        router.params.subscribe(function (res) {
            _this.apply_inspect_no = res.factory_id;
            _this.getData();
        });
    }
    InspectPoComponent.prototype.ngOnInit = function () { };
    InspectPoComponent.prototype.feedback = function (p, sku) {
        this.es.showModal({
            component: _feedback_feedback_component__WEBPACK_IMPORTED_MODULE_2__["FeedbackComponent"],
            componentProps: { apply_inspection_no: this.apply_inspect_no, sku: sku.sku, contract_no: p.contract_no },
        });
    };
    InspectPoComponent.prototype.getData = function () {
        var _this = this;
        this.reworkCtrl.getReworkContractForApplyId(this.apply_inspect_no)
            .subscribe(function (res) {
            _this.list = res.data;
        });
    };
    InspectPoComponent.ctorParameters = function () { return [
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: _rework_service__WEBPACK_IMPORTED_MODULE_5__["ReworkService"] }
    ]; };
    InspectPoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-inspect-po',
            template: __webpack_require__(/*! raw-loader!./inspect-po.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/inspect-po/inspect-po.component.html"),
            styles: [__webpack_require__(/*! ./inspect-po.component.scss */ "./src/app/pages/rework-inspect/inspect-po/inspect-po.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _rework_service__WEBPACK_IMPORTED_MODULE_5__["ReworkService"]])
    ], InspectPoComponent);
    return InspectPoComponent;
}());



/***/ }),

/***/ "./src/app/pages/rework-inspect/rework-inspect.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework-inspect.module.ts ***!
  \***************************************************************/
/*! exports provided: ReworkInspectPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReworkInspectPageModule", function() { return ReworkInspectPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _rework_inspect_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./rework-inspect.page */ "./src/app/pages/rework-inspect/rework-inspect.page.ts");
/* harmony import */ var _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./inspect-po/inspect-po.component */ "./src/app/pages/rework-inspect/inspect-po/inspect-po.component.ts");
/* harmony import */ var _rework_sku_rework_sku_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./rework-sku/rework-sku.component */ "./src/app/pages/rework-inspect/rework-sku/rework-sku.component.ts");
/* harmony import */ var src_app_widget_widget_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/widget/widget.module */ "./src/app/widget/widget.module.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");











var routes = [
    {
        path: '',
        component: _rework_inspect_page__WEBPACK_IMPORTED_MODULE_6__["ReworkInspectPage"],
    },
    {
        path: 'rework-po/:factory_id',
        component: _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_7__["InspectPoComponent"],
    },
    {
        path: 'rework-sku/:apply_inspection_no/:contract_no/:sku',
        component: _rework_sku_rework_sku_component__WEBPACK_IMPORTED_MODULE_8__["ReworkSkuComponent"],
    },
];
var ReworkInspectPageModule = /** @class */ (function () {
    function ReworkInspectPageModule() {
    }
    ReworkInspectPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), src_app_widget_widget_module__WEBPACK_IMPORTED_MODULE_9__["WidgetModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_flex_layout__WEBPACK_IMPORTED_MODULE_10__["FlexLayoutModule"]],
            declarations: [_rework_inspect_page__WEBPACK_IMPORTED_MODULE_6__["ReworkInspectPage"], _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_7__["InspectPoComponent"], _rework_sku_rework_sku_component__WEBPACK_IMPORTED_MODULE_8__["ReworkSkuComponent"]],
        })
    ], ReworkInspectPageModule);
    return ReworkInspectPageModule;
}());



/***/ }),

/***/ "./src/app/pages/rework-inspect/rework-inspect.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework-inspect.page.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Jld29yay1pbnNwZWN0L3Jld29yay1pbnNwZWN0LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/rework-inspect/rework-inspect.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework-inspect.page.ts ***!
  \*************************************************************/
/*! exports provided: ReworkInspectPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReworkInspectPage", function() { return ReworkInspectPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _rework_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./rework.service */ "./src/app/pages/rework-inspect/rework.service.ts");







var ReworkInspectPage = /** @class */ (function () {
    function ReworkInspectPage(router, inspectService, storage, effectCtrl, reworkCtrl) {
        this.router = router;
        this.inspectService = inspectService;
        this.storage = storage;
        this.effectCtrl = effectCtrl;
        this.reworkCtrl = reworkCtrl;
        this.getListParams = {
            keywords: 'factory_name',
            value: '',
        };
        this.metaInspectTask = [];
        this.task = [];
        this.inspectTask = [];
    }
    ReworkInspectPage.prototype.ngOnInit = function () { };
    ReworkInspectPage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.getListParams.page = 1;
        // this.inspectService.getReworkInspectList(this.getListParams).subscribe(res => {
        //     this.metaInspectTask = res.data;
        //     this.inspectTask = JSON.parse(JSON.stringify(res.data));
        //     this.task = res;
        //     this.getListParams.page = res.current_page + 1;
        //     this.storage.set('IMPLEMENT-INSPECTION-META-DATA', this.inspectTask);
        // });
        this.reworkCtrl.getReworkFactoryList()
            .subscribe(function (res) {
            _this.metaInspectTask = res.data;
            _this.inspectTask = JSON.parse(JSON.stringify(res.data));
            console.log(res);
        });
    };
    ReworkInspectPage.prototype.factoryChange = function () {
        var _this = this;
        this.getListParams.page = 1;
        this.inspectService.getReworkInspectList(this.getListParams).subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.inspectTask = res.data;
                _this.getListParams.page = res.current_page + 1;
                _this.storage.set('IMPLEMENT-INSPECTION-META-DATA', _this.inspectTask);
            }
            else {
                _this.inspectTask = [];
            }
        });
    };
    ReworkInspectPage.prototype.toInspect = function (contractNo, inspectId) {
        console.log(contractNo, inspectId);
        this.router.navigate(['/inspect-factory', contractNo, inspectId]);
    };
    ReworkInspectPage.prototype.loadData = function (event) {
        var _this = this;
        this.inspectService.getReworkInspectList(this.getListParams).subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.inspectTask = _this.inspectTask.concat(res.data);
                _this.getListParams.page = res.current_page + 1;
                _this.storage.set('IMPLEMENT-INSPECTION-META-DATA', _this.inspectTask);
            }
            else {
                _this.effectCtrl.showToast({
                    message: '别刷了，没有数据啦！',
                    color: 'danger',
                });
            }
            event.target.complete();
        });
    };
    ReworkInspectPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"] },
        { type: _rework_service__WEBPACK_IMPORTED_MODULE_6__["ReworkService"] }
    ]; };
    ReworkInspectPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-rework-inspect',
            template: __webpack_require__(/*! raw-loader!./rework-inspect.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/rework-inspect.page.html"),
            styles: [__webpack_require__(/*! ./rework-inspect.page.scss */ "./src/app/pages/rework-inspect/rework-inspect.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"],
            _rework_service__WEBPACK_IMPORTED_MODULE_6__["ReworkService"]])
    ], ReworkInspectPage);
    return ReworkInspectPage;
}());



/***/ }),

/***/ "./src/app/pages/rework-inspect/rework-sku/rework-sku.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework-sku/rework-sku.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #f2f2f2;\n  --padding-top: 15px;\n  --padding-bottom: 15px;\n  --padding-start: 10px;\n  --padding-end: 10px;\n}\nion-content .out-box {\n  padding: 5px;\n}\nion-list {\n  margin: 10px 0;\n}\n.other-item ion-item {\n  --inner-padding-start: 0 !important;\n  --padding-start: 0 !important;\n}\n:host ::ng-deep .item-native {\n  --inner-padding-start: 0 !important;\n}\n.out-box {\n  padding: 5px;\n}\n.vdo-list {\n  width: 100%;\n}\n.vdo-list li {\n  float: left;\n  width: 50%;\n}\n.vdo-list li video {\n  width: 100%;\n}\n.img-list,\n.vdo-list {\n  width: 100%;\n}\n.img-list li,\n.vdo-list li {\n  float: left;\n  width: 50%;\n  max-height: 250px;\n  overflow: hidden;\n  padding: 0.5rem;\n  padding-right: 0;\n}\n.img-list li img,\n.img-list li video,\n.vdo-list li img,\n.vdo-list li video {\n  border: 1px solid #ccc;\n  height: 100%;\n  width: 100%;\n}\n.img-list::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\nion-text {\n  color: #505050;\n  font-size: 14px;\n}\nul {\n  padding-bottom: 10px;\n}\nul li {\n  line-height: 18px;\n  font-size: 14px;\n  width: 100%;\n  margin-top: 5px;\n  border: 0;\n}\nion-item:last-child {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\nion-item:not(:first-child) .global-inspect-title {\n  margin-top: 10px !important;\n}\n.global-inspect-title {\n  font-size: 14px;\n  color: #3880fc;\n  font-weight: bold;\n  margin: 5px 0 !important;\n}\n.global-inspect-title p {\n  margin: 0;\n}\n.gray-color {\n  color: #a2a2a2;\n}\n.w100 {\n  width: 100% !important;\n}\n.global-inspect-title + div {\n  margin-top: 10px;\n}\n.h-30 {\n  height: 30px;\n}\n.bar-code {\n  margin-bottom: 10px;\n}\n.bar-code input {\n  outline: none;\n  border: 1px solid #e8e8e8;\n  width: 150px;\n}\n.mt-10 {\n  margin-top: 10px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9yZXdvcmstaW5zcGVjdC9yZXdvcmstc2t1L3Jld29yay1za3UuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3Jld29yay1pbnNwZWN0L3Jld29yay1za3UvcmV3b3JrLXNrdS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUNDSjtBREFJO0VBQ0ksWUFBQTtBQ0VSO0FEQ0E7RUFDSSxjQUFBO0FDRUo7QURBQTtFQUNJLG1DQUFBO0VBQ0EsNkJBQUE7QUNHSjtBRERBO0VBQ0ksbUNBQUE7QUNJSjtBREZBO0VBQ0ksWUFBQTtBQ0tKO0FERkE7RUFDSSxXQUFBO0FDS0o7QURKSTtFQUNJLFdBQUE7RUFDQSxVQUFBO0FDTVI7QURMUTtFQUNJLFdBQUE7QUNPWjtBREZBOztFQUVJLFdBQUE7QUNLSjtBREpJOztFQUNJLFdBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ09SO0FETlE7Ozs7RUFFSSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDVVo7QURMQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ1FKO0FETEE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtBQ1FKO0FETEE7RUFDSSxvQkFBQTtBQ1FKO0FEUEk7RUFDSSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUNTUjtBRExBO0VBQ0ksaUJBQUE7RUFDQSx1QkFBQTtBQ1FKO0FETEE7RUFDSSwyQkFBQTtBQ1FKO0FETEE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUNRSjtBRFBJO0VBQ0ksU0FBQTtBQ1NSO0FETEE7RUFDSSxjQUFBO0FDUUo7QURMQTtFQUNJLHNCQUFBO0FDUUo7QURMQTtFQUNJLGdCQUFBO0FDUUo7QURMQTtFQUNJLFlBQUE7QUNRSjtBRExBO0VBQ0ksbUJBQUE7QUNRSjtBRFBJO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQ1NSO0FETkE7RUFDSSwyQkFBQTtBQ1NKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcmV3b3JrLWluc3BlY3QvcmV3b3JrLXNrdS9yZXdvcmstc2t1LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgICAtLXBhZGRpbmctdG9wOiAxNXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gICAgLm91dC1ib3gge1xuICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgfVxufVxuaW9uLWxpc3Qge1xuICAgIG1hcmdpbjogMTBweCAwO1xufVxuLm90aGVyLWl0ZW0gaW9uLWl0ZW0ge1xuICAgIC0taW5uZXItcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xuICAgIC0tcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5pdGVtLW5hdGl2ZSB7XG4gICAgLS1pbm5lci1wYWRkaW5nLXN0YXJ0OiAwICFpbXBvcnRhbnQ7XG59XG4ub3V0LWJveCB7XG4gICAgcGFkZGluZzogNXB4O1xufVxuXG4udmRvLWxpc3Qge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGxpIHtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIHdpZHRoOiA1MCU7XG4gICAgICAgIHZpZGVvIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uaW1nLWxpc3QsXG4udmRvLWxpc3Qge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGxpIHtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIHdpZHRoOiA1MCU7XG4gICAgICAgIG1heC1oZWlnaHQ6IDI1MHB4O1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICBwYWRkaW5nOiAwLjVyZW07XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDA7XG4gICAgICAgIGltZyxcbiAgICAgICAgdmlkZW8ge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uaW1nLWxpc3Q6OmFmdGVyIHtcbiAgICBjb250ZW50OiAnJztcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjbGVhcjogYm90aDtcbn1cblxuaW9uLXRleHQge1xuICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbn1cblxudWwge1xuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICAgIGxpIHtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgYm9yZGVyOiAwO1xuICAgIH1cbn1cblxuaW9uLWl0ZW06bGFzdC1jaGlsZCB7XG4gICAgLS1ib3JkZXItd2lkdGg6IDA7XG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG59XG5cbmlvbi1pdGVtOm5vdCg6Zmlyc3QtY2hpbGQpIC5nbG9iYWwtaW5zcGVjdC10aXRsZSB7XG4gICAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBjb2xvcjogIzM4ODBmYztcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG4gICAgcCB7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICB9XG59XG5cbi5ncmF5LWNvbG9yIHtcbiAgICBjb2xvcjogI2EyYTJhMjtcbn1cblxuLncxMDAge1xuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5nbG9iYWwtaW5zcGVjdC10aXRsZSArIGRpdiB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmgtMzAge1xuICAgIGhlaWdodDogMzBweDtcbn1cblxuLmJhci1jb2RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIGlucHV0IHtcbiAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcbiAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgIH1cbn1cbi5tdC0xMHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG4gIC0tcGFkZGluZy10b3A6IDE1cHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbn1cbmlvbi1jb250ZW50IC5vdXQtYm94IHtcbiAgcGFkZGluZzogNXB4O1xufVxuXG5pb24tbGlzdCB7XG4gIG1hcmdpbjogMTBweCAwO1xufVxuXG4ub3RoZXItaXRlbSBpb24taXRlbSB7XG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctc3RhcnQ6IDAgIWltcG9ydGFudDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5pdGVtLW5hdGl2ZSB7XG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xufVxuXG4ub3V0LWJveCB7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLnZkby1saXN0IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4udmRvLWxpc3QgbGkge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDUwJTtcbn1cbi52ZG8tbGlzdCBsaSB2aWRlbyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uaW1nLWxpc3QsXG4udmRvLWxpc3Qge1xuICB3aWR0aDogMTAwJTtcbn1cbi5pbWctbGlzdCBsaSxcbi52ZG8tbGlzdCBsaSB7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogNTAlO1xuICBtYXgtaGVpZ2h0OiAyNTBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgcGFkZGluZzogMC41cmVtO1xuICBwYWRkaW5nLXJpZ2h0OiAwO1xufVxuLmltZy1saXN0IGxpIGltZyxcbi5pbWctbGlzdCBsaSB2aWRlbyxcbi52ZG8tbGlzdCBsaSBpbWcsXG4udmRvLWxpc3QgbGkgdmlkZW8ge1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uaW1nLWxpc3Q6OmFmdGVyIHtcbiAgY29udGVudDogXCJcIjtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNsZWFyOiBib3RoO1xufVxuXG5pb24tdGV4dCB7XG4gIGNvbG9yOiAjNTA1MDUwO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbnVsIHtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG51bCBsaSB7XG4gIGxpbmUtaGVpZ2h0OiAxOHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGJvcmRlcjogMDtcbn1cblxuaW9uLWl0ZW06bGFzdC1jaGlsZCB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcbn1cblxuaW9uLWl0ZW06bm90KDpmaXJzdC1jaGlsZCkgLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHtcbiAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMzg4MGZjO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiA1cHggMCAhaW1wb3J0YW50O1xufVxuLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHAge1xuICBtYXJnaW46IDA7XG59XG5cbi5ncmF5LWNvbG9yIHtcbiAgY29sb3I6ICNhMmEyYTI7XG59XG5cbi53MTAwIHtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuLmdsb2JhbC1pbnNwZWN0LXRpdGxlICsgZGl2IHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmgtMzAge1xuICBoZWlnaHQ6IDMwcHg7XG59XG5cbi5iYXItY29kZSB7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4uYmFyLWNvZGUgaW5wdXQge1xuICBvdXRsaW5lOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xuICB3aWR0aDogMTUwcHg7XG59XG5cbi5tdC0xMCB7XG4gIG1hcmdpbi10b3A6IDEwcHggIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/rework-inspect/rework-sku/rework-sku.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework-sku/rework-sku.component.ts ***!
  \*************************************************************************/
/*! exports provided: ReworkSkuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReworkSkuComponent", function() { return ReworkSkuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _rework_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../rework.service */ "./src/app/pages/rework-inspect/rework.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var src_app_widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/widget/scan/scan.component */ "./src/app/widget/scan/scan.component.ts");








var ReworkSkuComponent = /** @class */ (function () {
    function ReworkSkuComponent(fb, activeRoute, es, reworkCtrl) {
        var _this = this;
        this.fb = fb;
        this.activeRoute = activeRoute;
        this.es = es;
        this.reworkCtrl = reworkCtrl;
        this.sku = '';
        this.contract_no = '';
        this.apply_inspection_no = '';
        this.skuInfo = {
            name: '',
        };
        this.imgOrigin = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].fileUrlPath;
        this.unpackingPercent = 0;
        this.question = {
            desc: '',
            review_summary_img: [],
            review_summary_video: [],
        };
        activeRoute.params.subscribe(function (res) {
            _this.apply_inspection_no = res.apply_inspection_no;
            _this.contract_no = res.contract_no;
            _this.sku = res.sku;
            _this.skuInspectModel = _this.fb.group({
                sku: _this.fb.control(_this.sku),
                apply_inspection_no: _this.fb.control(_this.apply_inspection_no),
                contract_no: _this.fb.control(_this.contract_no),
                inspectionDate: _this.fb.control(''),
                unpackingNum: _this.fb.control(''),
                unpackingPercent: _this.fb.control(''),
                barCode: _this.fb.group({
                    text: _this.fb.control(''),
                    isTrue: _this.fb.control(''),
                    photos: _this.fb.array([]),
                    desc: _this.fb.array([]),
                }),
                sumUp: _this.fb.group({
                    videos: _this.fb.array([]),
                    photos: _this.fb.array([]),
                    desc: _this.fb.array([]),
                }),
            });
        });
    }
    ReworkSkuComponent.prototype.ngOnInit = function () {
        this.getData();
    };
    ReworkSkuComponent.prototype.play = function (p) { };
    ReworkSkuComponent.prototype.scan = function () {
        var _this = this;
        var modal = this.es.showModal({
            component: src_app_widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_7__["ScanComponent"],
        }, function (res) {
            _this.barCode = res.value;
        });
    };
    ReworkSkuComponent.prototype.descEnter = function (e, type) {
        this.skuInspectModel.get(type).get('desc').clear();
        for (var i = 0; i < e.length; i++) {
            this.skuInspectModel.get(type).get('desc').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
        }
        this.skuInspectModel.get(type).get('desc').setValue(e);
    };
    ReworkSkuComponent.prototype.getData = function () {
        var _this = this;
        this.reworkCtrl
            .getReworkSkuInfo({
            sku: this.sku,
            contract_no: this.contract_no,
            apply_inspection_no: this.apply_inspection_no,
        })
            .subscribe(function (res) {
            _this.skuInfo = res.data.sku_info;
            _this.question = res.data.rework_desc;
            _this.dynamicCreateDescForm(res.data.sku_info.barCode.desc, 'barCode');
            _this.skuInspectModel.patchValue({
                inspectionDate: res.data.sku_info.inspectionDate,
                unpackingNum: res.data.sku_info.unpackingNum,
                unpackingPercent: res.data.sku_info.unpackingPercent,
                barCode: {
                    text: res.data.sku_info.barCode.text,
                    isTrue: res.data.sku_info.barCode.isTrue,
                    photos: res.data.sku_info.barCode.photos,
                    desc: res.data.sku_info.barCode.desc,
                },
                sumUp: {
                    videos: res.data.sku_info.sumUp.videos,
                    photos: res.data.sku_info.sumUp.photos,
                    desc: res.data.sku_info.sumUp.desc,
                },
            });
            console.log(_this.skuInspectModel.value);
        });
    };
    ReworkSkuComponent.prototype.dynamicCreateDescForm = function (ary, type) {
        var _this = this;
        if (!ary || !ary.length)
            return;
        ary.forEach(function (res) {
            _this.skuInspectModel.get(type).get('desc').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
        });
    };
    ReworkSkuComponent.prototype.numChange = function (e) {
        if (!this.skuInfo.quantity)
            return;
        this.unpackingPercent = (Number(e.detail.value) / Number(this.skuInfo.quantity)) * 100;
    };
    ReworkSkuComponent.prototype.submit = function () {
        var _this = this;
        this.skuInspectModel.patchValue({
            sku: this.sku,
            apply_inspection_no: this.apply_inspection_no,
            contract_no: this.contract_no
        });
        this.reworkCtrl.submitReworkSku(this.skuInspectModel.value).subscribe(function (res) {
            console.log(res);
            _this.es.showToast({
                message: res.message,
                color: res.status ? 'success' : 'danger'
            });
        });
    };
    ReworkSkuComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] },
        { type: _rework_service__WEBPACK_IMPORTED_MODULE_5__["ReworkService"] }
    ]; };
    ReworkSkuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-rework-sku',
            template: __webpack_require__(/*! raw-loader!./rework-sku.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/rework-sku/rework-sku.component.html"),
            styles: [__webpack_require__(/*! ./rework-sku.component.scss */ "./src/app/pages/rework-inspect/rework-sku/rework-sku.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"],
            _rework_service__WEBPACK_IMPORTED_MODULE_5__["ReworkService"]])
    ], ReworkSkuComponent);
    return ReworkSkuComponent;
}());



/***/ }),

/***/ "./src/app/pages/rework-inspect/rework.service.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/rework-inspect/rework.service.ts ***!
  \********************************************************/
/*! exports provided: ReworkService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReworkService", function() { return ReworkService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/http.service */ "./src/app/services/http.service.ts");



var ReworkService = /** @class */ (function () {
    function ReworkService(http) {
        this.http = http;
    }
    ReworkService.prototype.getReworkFactoryList = function () {
        return this.http.get({ url: '/task/inspection_task_list_rework2' });
    };
    ReworkService.prototype.getReworkContractForApplyId = function (apply_inspection_no) {
        return this.http.get({ url: '/task/inspection_rework_contract_info', params: { apply_inspection_no: apply_inspection_no } });
    };
    ReworkService.prototype.getReworkSkuInfo = function (params) {
        return this.http.get({ url: '/task/get_rework_sku_info', params: params });
    };
    ReworkService.prototype.submitReworkSku = function (params) {
        return this.http.post({ url: '/task/post_inspection_task_rework_data', params: params });
    };
    ReworkService.ctorParameters = function () { return [
        { type: src_app_services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] }
    ]; };
    ReworkService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"]])
    ], ReworkService);
    return ReworkService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-rework-inspect-rework-inspect-module-es5.js.map