(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/home/home.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>\n            首页\n        </ion-title>\n        <ion-title slot=\"end\">\n            <img src=\"../../../assets/img/slogan.png\" alt=\"\" />\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card class=\"welcome-card\">\n        <ion-img [src]=\"src\"></ion-img>\n        <ion-card-header>\n            <ion-card-subtitle\n                >姓名：{{user.info.name }}\n                <span> </span>\n                工号：{{user.info.company_no}}</ion-card-subtitle\n            >\n            <ion-card-title>欢迎进入鹰眼系统</ion-card-title>\n            \n        </ion-card-header>\n        <ion-card-content>\n            <ion-button (click)=\"showModal()\" size=\"small\">上传进度</ion-button>\n        </ion-card-content>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"],
                    },
                ]),
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]],
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".welcome-card ion-img {\n  overflow: hidden;\n}\n\nion-title {\n  font-size: 16px;\n}\n\nion-title span {\n  display: inline-block;\n  width: 20px;\n}\n\n.title {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.title > span:first-child {\n  font-size: 0.6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUNDSjs7QURDQTtFQUNJLGVBQUE7QUNFSjs7QURESTtFQUNJLHFCQUFBO0VBQ0EsV0FBQTtBQ0dSOztBREFBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUNHSjs7QURGSTtFQUNJLGlCQUFBO0FDSVIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndlbGNvbWUtY2FyZCBpb24taW1nIHtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuaW9uLXRpdGxlIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgc3BhbiB7XG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgfVxufVxuLnRpdGxlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgID4gc3BhbjpmaXJzdC1jaGlsZCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMC42cmVtO1xuICAgIH1cbn1cbiIsIi53ZWxjb21lLWNhcmQgaW9uLWltZyB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbmlvbi10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbmlvbi10aXRsZSBzcGFuIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMjBweDtcbn1cblxuLnRpdGxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLnRpdGxlID4gc3BhbjpmaXJzdC1jaGlsZCB7XG4gIGZvbnQtc2l6ZTogMC42cmVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_screen_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/screen.service */ "./src/app/services/screen.service.ts");
/* harmony import */ var _services_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/menu.service */ "./src/app/services/menu.service.ts");
/* harmony import */ var _services_user_info_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/user-info.service */ "./src/app/services/user-info.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _implement_inspection_queue_queue_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../implement-inspection/queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../implement-inspection/upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");










var HomePage = /** @class */ (function () {
    function HomePage(menu, cd, user, menuService, screen, Router, es, uQueue) {
        this.menu = menu;
        this.cd = cd;
        this.user = user;
        this.menuService = menuService;
        this.screen = screen;
        this.Router = Router;
        this.es = es;
        this.uQueue = uQueue;
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
    }
    HomePage.prototype.ngOnInit = function () {
        var _this = this;
        this.setDiffImgSize(this.screen.screenAngle);
        this.menu.close();
        if (this.user.info.is_first) {
            var menuItem = {
                url: '/create-department',
                sonIndex: 2,
            };
            this.menuService.setMenuExpand(menuItem);
            this.Router.navigate(['/modify-pwd']);
        }
        this.screen.onResize.subscribe(function (res) {
            _this.setDiffImgSize(res);
        });
    };
    HomePage.prototype.setDiffImgSize = function (screenAngle) {
        if (screen.availWidth >= 1080) {
            this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_1595X510.jpg";
        }
        else {
            if (screenAngle == 'Vertical') {
                this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_390X311.jpg";
            }
            else
                this.src = "../../../assets/img/home-img/" + this.dayToBeat + "_1254X570.jpg";
        }
    };
    HomePage.prototype.showModal = function () {
        this.es.showModal({
            component: _implement_inspection_queue_queue_component__WEBPACK_IMPORTED_MODULE_7__["QueueComponent"]
        });
        this.alreadyUpProgress = true;
    };
    Object.defineProperty(HomePage.prototype, "dayToBeat", {
        get: function () {
            var today = new Date().getDay();
            var some = '';
            switch (today) {
                case 1:
                    some = 'A';
                    break;
                case 2:
                    some = 'B';
                    break;
                case 3:
                    some = 'C';
                    break;
                case 4:
                    some = 'D';
                    break;
                case 5:
                    some = 'E';
                    break;
                default: {
                    some = 'F';
                }
            }
            return some;
        },
        enumerable: true,
        configurable: true
    });
    HomePage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["MenuController"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__["ChangeDetectorRef"] },
        { type: _services_user_info_service__WEBPACK_IMPORTED_MODULE_3__["UserInfoService"] },
        { type: _services_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenuService"] },
        { type: _services_screen_service__WEBPACK_IMPORTED_MODULE_1__["ScreenService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_8__["PageEffectService"] },
        { type: _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_9__["UploadQueueService"] }
    ]; };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__["MenuController"],
            _angular_core__WEBPACK_IMPORTED_MODULE_5__["ChangeDetectorRef"],
            _services_user_info_service__WEBPACK_IMPORTED_MODULE_3__["UserInfoService"],
            _services_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenuService"],
            _services_screen_service__WEBPACK_IMPORTED_MODULE_1__["ScreenService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_8__["PageEffectService"],
            _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_9__["UploadQueueService"]])
    ], HomePage);
    return HomePage;
}());



/***/ }),

/***/ "./src/app/services/screen.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/screen.service.ts ***!
  \********************************************/
/*! exports provided: ScreenService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScreenService", function() { return ScreenService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var ScreenService = /** @class */ (function () {
    function ScreenService() {
        var _this = this;
        this.onResize = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.screenResize = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(window, 'orientationchange');
        this.screenResize.subscribe(function (res) {
            _this.onResize.next(_this.screenAngle);
        });
    }
    Object.defineProperty(ScreenService.prototype, "screenAngle", {
        get: function () {
            var rval;
            if (screen.orientation.angle == 0 || screen.orientation.angle == 180)
                rval = 'Vertical';
            else
                rval = 'Horizontal';
            return rval;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ScreenService.prototype, "ScreenHeight", {
        get: function () {
            return document.documentElement.clientHeight;
        },
        enumerable: true,
        configurable: true
    });
    ScreenService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ScreenService);
    return ScreenService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module-es5.js.map