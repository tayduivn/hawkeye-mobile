(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-implement-inspection-implement-inspection-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/inspect-tab-bar/inspect-tab-bar.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/inspect-tab-bar/inspect-tab-bar.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ul>\n  <li (click)=\"select('before')\" [ngClass]=\"[current === 'before' ? 'active': '']\">\n    开箱前\n  </li>\n  <li (click)=\"select('after')\" [ngClass]=\"[current === 'after' ? 'active': '']\">\n    开箱后\n  </li>\n  <li (click)=\"select('require')\" [ngClass]=\"[current === 'require' ? 'active': '']\">\n    验货要求\n  </li>\n</ul>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/evaluation/evaluation.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/evaluation/evaluation.component.html ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>综合评价</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-back-button text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content></ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/implement-inspection.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/implement-inspection.page.html ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>执行验货</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar\n        animated\n        clearInput\n        mode=\"ios\"\n        placeholder=\"输入工厂名检索\"\n        (ionChange)=\"factoryChange()\"\n        [(ngModel)]=\"getListParams.value\"\n    ></ion-searchbar>\n\n    <ion-button fill='clear' expand=\"full\" *ngIf=\"!inspectTask || !inspectTask.length\" (click)=\"ionViewWillEnter()\">重新获取</ion-button>\n    <ion-card *ngFor=\"let item of inspectTask\" mode=\"ios\">\n        <ion-item class=\"card-header\">\n            <ion-icon name=\"people\" slot=\"start\" color=\"primary\"></ion-icon>\n            <ion-label><span>验货工厂：</span>{{ item.factory_name }}</ion-label>\n            <ion-label class=\"text-c\"><span>工厂联系人：</span>{{ item.factory_contacts }}</ion-label>\n        </ion-item>\n\n        <ion-card-content>\n            <ion-grid>\n                <ion-row class=\"title\">\n                    <ion-col align-self-center [size]=\"3\">\n                        验货流水号\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        验货合同数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        验货SKU数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        操作\n                    </ion-col>\n                </ion-row>\n\n                <ion-row *ngFor=\"let sItem of item.sku_data\">\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.apply_inspection_no }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.contract_data.length }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"3\">\n                        {{ sItem.data.length }}\n                    </ion-col>\n                    <ion-col\n                        align-self-center\n                        [size]=\"3\"\n                        class=\"ion-col-no-pad\"\n                        fxLayout=\"row\"\n                        fxLayoutAlign=\"start center\"\n                    >\n                        <ion-button\n                            fill=\"clear\"\n                            size=\"small\"\n                            (click)=\"toInspect(sItem.apply_inspection_no,item.inspection_group_id)\"\n                            >去验货</ion-button\n                        >\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-card-content>\n    </ion-card>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n        <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"正在加载\"> </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n    <p *ngIf=\"!inspectTask.length\" class=\"text-c \">暂无数据</p>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-check/inspect-check.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-check/inspect-check.component.html ***!
  \*****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>合同号</ion-title>\n\n        <ion-buttons slot=\"end\" class=\"tops\">\n            <ion-button (click)=\"showModal()\" [disabled]=\"alreadyUpProgress\">上传进度</ion-button>\n        </ion-buttons>\n\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/inspect-po\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content [formGroup]=\"skuInspectModel\">\n    <app-sku-info [sku]=\"skuInfo\" type=\"implement\"></app-sku-info>\n    <ion-list>\n      <!--  formGroupName=\"barCode\" -->\n        <ion-item> \n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>条码</p>\n                </div>\n                <div class=\"bar-code\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                    <input class=\"h-30\" placeholder=\"请输入条码\" /> <!--formControlName=\"text\" -->\n                    <ion-button fill=\"clear\">{{ barCode }}</ion-button>\n                    <ion-button fill=\"clear\" (click)=\"scan('inner')\">\n                        扫码\n                    </ion-button>\n                    <ion-button\n                        color=\"success\"\n                        size=\"small\"\n                        fill=\"clear\"\n                        *ngIf=\"true\"\n                    >\n                        扫码已通过\n                    </ion-button>\n                </div>\n                <app-photograph\n                    type=\"bar_code_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"contract_no\"\n                    [apply_inspection_no]=\"apply_inspection_no\"\n                    [sku]=\"skuInfo.sku\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box mt-10\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"[]\"\n                        (onComplete)=\"descEnter($event, 'barCode')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>配件唛头(照相需六面)</p>\n                </div>\n                <app-photograph\n                    type=\"outer_box_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"\"\n                    [apply_inspection_no]=\"\"\n                    [sku]=\"\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>配件数量</p>\n                </div>\n                <input type=\"number\" placeholder=\"输入数量\" />\n                <app-photograph\n                    type=\"outer_box_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"\"\n                    [apply_inspection_no]=\"\"\n                    [sku]=\"\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>配件细节图</p>\n                </div>\n                <app-photograph\n                    type=\"outer_box_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"\"\n                    [apply_inspection_no]=\"\"\n                    [sku]=\"\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.html":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.html ***!
  \*****************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list>\n    <div class=\"global-inspect-title pl-10\">\n        <p>自定义测试（可添加）</p>\n    </div>\n    <ion-item *ngFor=\"let item of _customTestArray; let i = index\">\n        <div class=\"w100\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n            <div class=\"w-60\"><!-- [class]=\"i === _customTestArray.length - 1 ? 'w-60' : 'w100'\" -->\n                <div>\n                    <span class=\"preview mr-20\">{{ item.name }}</span>\n                    <input (blur)=\"onValueChange.emit(_customTestArray)\" [(ngModel)]=\"item.name\" placeholder=\"请填写或编辑测试字段名\" class=\"text-l\" />\n                </div>  \n                <app-photograph\n                    [type]=\"'custom_test'\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"item.pic\"\n                    [contract_no]=\"contract_no\"\n                    [apply_inspection_no]=\"apply_inspection_no\"\n                    [sku]=\"sku\"\n                    [box_type]=\"box_type\"\n                    [sort_index]=\"i\"\n                ></app-photograph>\n                <app-videotape\n                    [type]=\"'custom_test'\"\n                    [videos]=\"item.videos\"\n                    [contract_no]=\"contract_no\"\n                    [apply_inspection_no]=\"apply_inspection_no\"\n                    [sku]=\"sku\" \n                    [box_type]=\"box_type\"\n                    [sort_index]=\"i\"\n                ></app-videotape>\n                <div class=\"test-feedback\">\n                    <div>\n                        <div>\n                         <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"item.desc\"\n                                (onComplete)=\"descEnter($event, i, box_type)\"\n                            >\n                        </app-item-by-item-desc>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n            <div>\n                <ion-button size=\"small\" [hidden]=\"i !== _customTestArray.length - 1\" (click)=\"addCustomTest()\">添加</ion-button>\n            </div>\n\n            \n            <ion-button (click)=\"delete(i)\" color='danger' size=\"small\" [hidden]=\"_customTestArray.length === 1\">删除</ion-button>\n        </div>\n    </ion-item>\n</ion-list>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.html":
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.html ***!
  \***********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"detail\">\n    <div *ngFor=\"let item of _data.review_summary_desc\">\n        <p [style]=\"{'color': item.color}\">{{ item.text }}</p>\n    </div>\n</div>\n\n<ul class=\"videos\">\n    <li *ngFor=\"let item of _data.video_arr\">\n        <video [src]=\"env + '/' + item\" controls></video>\n    </li>\n</ul>\n\n<ul class=\"images\" imgGallery>\n    <li *ngFor=\"let item of _data.img_arr\">\n        <img [src]=\"env + '/' + item\" alt=\"\" />\n    </li>\n</ul>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.html ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>{{ data.factory_name }}</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"showModal()\" size=\"small\">上传进度</ion-button>\n            <ion-back-button defaultHref=\"/implement-inspection\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <form [formGroup]=\"factoryModel\">\n        <ion-list>\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\" formArrayName=\"environments\">\n                        <label>工厂环境照片：</label>\n                        <div class=\"label-right\">\n                            <app-photograph\n                                moduleType=\"removeFactoryPic\"\n                                [photos]=\"environments.value\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                type=\"factory_environment_pic\"\n                            ></app-photograph>\n                        </div>\n                    </div>\n                    <div class=\"form-valid\" *ngIf=\"!environments.controls.length\">\n                        *请上传工厂环境照片\n                    </div>\n                </div>\n            </ion-item>\n\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\">\n                        <label>样 品 间 照 片：</label>\n                        <div class=\"label-right\">\n                            <app-photograph\n                                moduleType=\"removeFactoryPic\"\n                                [photos]=\"sampleRoom.value\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                type=\"factory_sample_room_pic\"\n                            ></app-photograph>\n                        </div>\n                    </div>\n                    <div class=\"form-valid\" *ngIf=\"!environments.controls.length\">\n                        *请上传样品间照片\n                    </div>\n                </div>\n            </ion-item>\n\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\">\n                        <label>工厂其他照片：</label>\n                        <div class=\"label-right\">\n                            <app-photograph\n                                moduleType=\"removeFactoryPic\"\n                                [photos]=\"factoryOther.value\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                type=\"factory_other_pic\"\n                            ></app-photograph>\n                        </div>\n                    </div>\n                    <div class=\"form-valid\" *ngIf=\"!environments.controls.length\">\n                        *请上传工厂其他照片\n                    </div>\n                </div>\n            </ion-item>\n        </ion-list>\n\n        <ion-list>\n            <ion-item formGroupName=\"factoryAddress\">\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between start\" class=\"item-inner text\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start start\">\n                        <label class=\"mr-0\">工&nbsp;&nbsp;&nbsp;厂&nbsp;&nbsp;地&nbsp;&nbsp;&nbsp;址：</label>\n                        <div>\n                            <div class=\"pos-r ques\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label>是否是实际地址</label>\n                                <select class=\"select\" formControlName=\"isTrue\">\n                                    <option value=\"1\">是</option>\n                                    <option value=\"0\">否</option>\n                                </select>\n                            </div>\n                            <ion-input\n                                type=\"text\"\n                                *ngIf=\"factoryModel.controls['factoryAddress'].value.isTrue == 0\"\n                                formControlName=\"text\"\n                                [placeholder]=\"\n                                    factoryModel.controls['factoryAddress'].value.isTrue == 0 ? '请输入实际地址' : ''\n                                \"\n                            >\n                            </ion-input>\n                        </div>\n                    </div>\n                    <div\n                        class=\"form-valid\"\n                        *ngIf=\"\n                            factoryModel.controls['factoryAddress'].value.isTrue == 0 &&\n                            !factoryModel.controls['factoryAddress'].value.text\n                        \"\n                    >\n                        *请输入工厂地址\n                    </div>\n                </div>\n            </ion-item>\n\n            <ion-item formGroupName=\"receptionist\" class=\"no-border\">\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between start\" class=\"item-inner text w100\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start start\" class=\" w80\">\n                        <label class=\"mr-0\">工&nbsp;厂&nbsp;&nbsp;接&nbsp;待&nbsp;人：</label>\n                        <div class=\"w100\">\n                            <div class=\"pos-r ques\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label>是否是实际接待人</label>\n                                <select class=\"select\" formControlName=\"isTrue\">\n                                    <option value=\"1\">是</option>\n                                    <option value=\"0\">否</option>\n                                </select>\n                            </div>\n                            <div>\n                                <div\n                                    fxLayout=\"row\"\n                                    fxLayoutAlign=\"start center\"\n                                    class=\"small\"\n                                    *ngIf=\"factoryModel.controls['receptionist'].value.isTrue == 0\"\n                                >\n                                    <label>姓名:</label>\n                                    <ion-input\n                                        type=\"text\"\n                                        [(ngModel)]=\"data.factory_contacts\"\n                                        formControlName=\"name\"\n                                        [placeholder]=\"\n                                            factoryModel.controls['receptionist'].value.isTrue == 0\n                                                ? '请输入实际接待人'\n                                                : ''\n                                        \"\n                                    ></ion-input>\n                                </div>\n\n                                <div\n                                    fxLayout=\"row\"\n                                    fxLayoutAlign=\"start center\"\n                                    class=\"small\"\n                                    *ngIf=\"factoryModel.controls['receptionist'].value.isTrue == 0\"\n                                >\n                                    <label>职位:</label>\n                                    <ion-input\n                                        type=\"text\"\n                                        formControlName=\"post\"\n                                        [placeholder]=\"\n                                            factoryModel.controls['receptionist'].value.isTrue == 0\n                                                ? '请输入实际接待人职位'\n                                                : ''\n                                        \"\n                                    >\n                                    </ion-input>\n                                </div>\n\n                                <div\n                                    fxLayout=\"row\"\n                                    fxLayoutAlign=\"start center\"\n                                    class=\"small\"\n                                    *ngIf=\"factoryModel.controls['receptionist'].value.isTrue == 0\"\n                                >\n                                    <label>电话:</label>\n                                    <ion-input\n                                        type=\"text\"\n                                        formControlName=\"tel\"\n                                        [placeholder]=\"\n                                            factoryModel.controls['receptionist'].value.isTrue == 0\n                                                ? '请输入实际接待人电话'\n                                                : ''\n                                        \"\n                                    >\n                                    </ion-input>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div\n                        class=\"form-valid\"\n                        *ngIf=\"\n                            factoryModel.controls['receptionist'].value.isTrue == 0 &&\n                            !factoryModel.controls['receptionist'].value.name\n                        \"\n                    >\n                        <!-- *请完善接待人信息 -->\n                    </div>\n                </div>\n            </ion-item>\n        </ion-list>\n\n        <ion-list>\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\">\n                        <label class=\"mr-0\">工&nbsp;&nbsp;厂&nbsp;&nbsp;工&nbsp;&nbsp;人&nbsp;数：</label>\n                        <ion-input\n                            placeholder=\"请输入工厂工人数\"\n                            (ionChange)=\"regValid($event)\"\n                            formControlName=\"worksNum\"\n                            type=\"number\"\n                        ></ion-input>\n                    </div>\n                    <div\n                        class=\"form-valid\"\n                        *ngIf=\"!factoryModel.get('worksNum').valid && factoryModel.get('worksNum').touched\"\n                    >\n                        *请输入工厂工人数\n                    </div>\n                </div>\n            </ion-item>\n\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\">\n                        <label class=\"mr-0\"\n                            >工&nbsp;&nbsp;&nbsp;&nbsp;厂&nbsp;&nbsp;&nbsp;设&nbsp;&nbsp;&nbsp;&nbsp;备：</label\n                        >\n                        <ion-input placeholder=\"请输入工厂设备\" formControlName=\"equipment\"></ion-input>\n                    </div>\n                    <div\n                        class=\"form-valid\"\n                        *ngIf=\"!factoryModel.get('equipment').valid && factoryModel.get('equipment').touched\"\n                    >\n                        *请输入设备\n                    </div>\n                </div>\n            </ion-item>\n\n            <ion-item>\n                <div fxLayout=\"col\" fxLayoutAlign=\"space-between center\" class=\"item-inner\">\n                    <div fxLayout=\"col\" fxLayoutAlign=\"start center\">\n                        <label class=\"mr-0\">实&nbsp;际&nbsp;验&nbsp;货&nbsp;时&nbsp;间：</label>\n                        <ion-datetime\n                            display-format=\"YYYY年MM月DD号\"\n                            doneText=\"完成\"\n                            max=\"2100\"\n                            placeholder=\"请输入实际验货时间\"\n                            formControlName=\"trulyInspectionDate\"\n                            (ionChange)=\"getListByTime()\"\n                            min=\"2020\"\n                            cancelText=\"取消\"\n                            monthShortNames=\"01, 02,03,04, 05,06,07,08,09,10,11,12\"\n                        >\n                        </ion-datetime>\n                    </div>\n                    <div\n                        class=\"form-valid\"\n                        *ngIf=\"\n                            !factoryModel.get('trulyInspectionDate').valid &&\n                            factoryModel.get('trulyInspectionDate').touched\n                        \"\n                    >\n                        *请输入实际验货时间\n                    </div>\n                </div>\n            </ion-item>\n        </ion-list>\n\n        <ion-list>\n            <ion-list-header>逐&nbsp;条&nbsp;增&nbsp;加备注：</ion-list-header>\n\n            <ion-item class=\"pb-10\">\n                <app-item-by-item-desc\n                    class=\"w100\"\n                    description=\"备注\"\n                    [ary]=\"factoryModel.value.remarks\"\n                    (onComplete)=\"descEnter($event)\"\n                ></app-item-by-item-desc>\n            </ion-item>\n        </ion-list>\n\n        <ion-list *ngIf=\"review_status\">\n            <ion-list-header>审&nbsp;&nbsp;核&nbsp;&nbsp;详&nbsp;&nbsp;情：</ion-list-header>\n            <app-examine-detail [data]=\"examineDetail\"></app-examine-detail>\n        </ion-list>\n\n        <div class=\"next\" fxLayout=\"row\" fxLayoutAlign=\"center center\" fxLayoutGap=\"gappx\">\n            <button class=\"next-btn\" (click)=\"toInspectPo()\">\n                <ion-icon name=\"arrow-dropright\" mode=\"ios\"></ion-icon>\n            </button>\n        </div>\n    </form>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.html ***!
  \*****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>合同号</ion-title>\n\n        <ion-buttons slot=\"end\" class=\"tops\">\n            <ion-button (click)=\"showModal()\" [disabled]=\"alreadyUpProgress\">上传进度</ion-button>\n        </ion-buttons>\n\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/inspect-po\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>唛头(照相需六面)</p>\n                </div>\n                <app-photograph\n                    type=\"outer_box_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"\"\n                    [apply_inspection_no]=\"\"\n                    [sku]=\"\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>配件箱尺寸（单位：CM）</p>\n                </div>\n                <div class=\"w100\">\n                    <ion-grid class=\"size-grid\">\n                        <ion-row align-items-center>\n                            <ion-col size=\"6\">尺寸</ion-col>\n                            <ion-col size=\"6\">照片上传</ion-col>\n                        </ion-row>\n                        <ion-row align-items-center>\n                            <ion-col size=\"6\">\n                                <input type=\"number\" placeholder=\"长\" />\n                            </ion-col>\n                            <ion-col size=\"6\">\n                                <app-photograph\n                                    type=\"size_pic_length\"\n                                    moduleType=\"removeSkuPic\"\n                                    [photos]=\"\"\n                                    [contract_no]=\"\"\n                                    [apply_inspection_no]=\"\"\n                                    [sku]=\"\"\n                                    box_type=\"inner\"\n                                ></app-photograph>\n                            </ion-col>\n                        </ion-row>\n                        <ion-row align-items-center>\n                            <ion-col size=\"6\">\n                                <input type=\"number\" placeholder=\"宽\" />\n                            </ion-col>\n                            <ion-col size=\"6\">\n                                <app-photograph\n                                    type=\"size_pic_length\"\n                                    moduleType=\"removeSkuPic\"\n                                    [photos]=\"\"\n                                    [contract_no]=\"\"\n                                    [apply_inspection_no]=\"\"\n                                    [sku]=\"\"\n                                    box_type=\"inner\"\n                                ></app-photograph>\n                            </ion-col>\n                        </ion-row>\n                        <ion-row align-items-center>\n                            <ion-col size=\"6\">\n                                <input type=\"number\" placeholder=\"高\" />\n                            </ion-col>\n                            <ion-col size=\"6\">\n                                <app-photograph\n                                    type=\"size_pic_length\"\n                                    moduleType=\"removeSkuPic\"\n                                    [photos]=\"\"\n                                    [contract_no]=\"\"\n                                    [apply_inspection_no]=\"\"\n                                    [sku]=\"\"\n                                    box_type=\"inner\"\n                                ></app-photograph>\n                            </ion-col>\n                        </ion-row>\n                    </ion-grid>\n                </div>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'size', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>配件箱毛重(单位：KG)</p>\n                </div>\n                <input type=\"number\" placeholder=\"输入毛重\" />\n                <app-photograph\n                    type=\"outer_box_pic\"\n                    moduleType=\"removeSkuPic\"\n                    [photos]=\"[]\"\n                    [contract_no]=\"\"\n                    [apply_inspection_no]=\"\"\n                    [sku]=\"\"\n                    box_type=\"inner\"\n                ></app-photograph>\n                <div class=\"desc-box\">\n                    <app-item-by-item-desc\n                        description=\"备注\"\n                        [ary]=\"\"\n                        (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                    ></app-item-by-item-desc>\n                </div>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list>\n        <ion-item>\n            <div class=\"w100\">\n                <div class=\"global-inspect-title\">\n                    <p>清单</p>\n                </div>\n\n                <ion-grid class=\"size-grid\">\n                    <ion-row align-items-center>\n                        <ion-col size=\"3\">配件编号</ion-col>\n                        <ion-col size=\"5\">中文名</ion-col>\n                        <ion-col size=\"2\">数量</ion-col>\n                        <ion-col size=\"2\">操作</ion-col>\n                    </ion-row>\n                    <ion-row align-items-center>\n                        <ion-col size=\"3\">32423423</ion-col>\n                        <ion-col size=\"5\">中文名</ion-col>\n                        <ion-col size=\"2\">3</ion-col>\n                        <ion-col size=\"2\">\n                            <ion-button fill=\"clear\" size=\"small\" [routerLink]=\"['/inspect-check']\">查验</ion-button>\n                        </ion-col>\n                    </ion-row>\n                </ion-grid>\n            </div>\n        </ion-item>\n    </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-po/inspect-po.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-po/inspect-po.component.html ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>{{ data.factoryName }}</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"showModal()\" [disabled]=\"alreadyUpProgress\" size=\"small\">上传进度</ion-button>\n            <ion-back-button text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-list class=\"po-list\">\n        <ion-item *ngFor=\"let item of currentApplyInsData.contract_data\">\n            <!-- data.sku_data[0].contract_data -->\n            <div class=\"wd-100\">\n                <div class=\"wd-100 po\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n                    <h4>{{ item.contract_no }}</h4>\n                    <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                        <label>合同大货包装完成数量:</label>\n                        <ion-input\n                            class=\"complete-num\"\n                            placeholder=\"0\"\n                            [disabled]=\"true\"\n                            [(ngModel)]=\"item.inspection_complete_no\"\n                            type=\"number\"\n                        ></ion-input>\n                    </div>\n                </div>\n                <!-- {{item.data | json}} -->\n                <ol class=\"sku-list\">\n                    <li *ngFor=\"let sItem of item.data\" fxLayout=\"column\" fxLayoutAlign=\"start start\">\n                        <div fxLayout=\"row\" fxLayoutAlign=\"space-between  center\" class=\"wd-100\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start  center\">\n                                <img\n                                    class=\"head\"\n                                    [src]=\"imgOrigin + sItem.pic[0]\"\n                                    alt=\"\"\n                                    imgGallery\n                                    [url]=\"imgOrigin + sItem.pic[0]\"\n                                />\n                                <div class=\"span-box\">\n                                    <span><span class=\"label\"> SKU: </span>{{ sItem.sku }}</span\n                                    ><br />\n                                    <p class=\"lh-10\">\n                                        <span class=\"label\">中文名： </span>\n                                        {{ sItem.sku_chinese_name }}\n                                    </p>\n                                    <span class=\"label\">申请验货数量：</span>\n                                    {{ sItem.quantity }}\n                                </div>\n                            </div>\n\n                            <div>\n                                <ion-button\n                                    size=\"small\"\n                                    class=\"f-r\"\n                                    expand=\"clear\"\n                                    color=\"primary\"\n                                    (click)=\"toInspectSku(item, sItem, 'go')\"\n                                    >去验货</ion-button\n                                >\n                                <ion-button class=\"f-r\" size=\"small\" color=\"primary\" (click)=\"toInspectSku(item, sItem)\"\n                                    >保存</ion-button\n                                >\n                            </div>\n                        </div>\n\n                        <div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"input-item\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"label\">大货包装完成数量:</label>\n                                <ion-input\n                                    (ionChange)=\"calcMust($event, sItem, 'sku_package_complete_num')\"\n                                    placeholder=\"0\"\n                                    [max]=\"sItem.quantity\"\n                                    type=\"number\"\n                                    (ionChange)=\"regValid($event)\"\n                                    (ionBlur)=\"calcContractNum(item, sItem)\"\n                                    [(ngModel)]=\"sItem.sku_package_complete_num\"\n                                ></ion-input>\n                            </div>\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"label\">大货生产完成数量:</label>\n                                <ion-input\n                                    (ionChange)=\"calcMust($event, sItem, 'sku_production_complete_num')\"\n                                    placeholder=\"0\"\n                                    (ionChange)=\"regValid($event)\"\n                                    type=\"number\"\n                                    [(ngModel)]=\"sItem.sku_production_complete_num\"\n                                ></ion-input>\n                            </div>\n                        </div>\n\n                        <div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"input-item mt-5\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"label\">箱率（符合否）:</label>\n                                <select [(ngModel)]=\"sItem.rate_res\">\n                                    <option value=\"\">请选择</option>\n                                    <option value=\"accord\">符合</option>\n                                    <option value=\"notAccord\">不符合</option>\n                                </select>\n                            </div>\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"label\">MADE IN CHINA 标识（符合否）:</label>\n                                <select [(ngModel)]=\"sItem.made_in_china_res\">\n                                    <option value=\"\">请选择</option>\n                                    <option value=\"accord\">符合</option>\n                                    <option value=\"notAccord\">不符合</option>\n                                </select>\n                            </div>\n                        </div>\n\n                        <div class=\"w100 mt-10\">\n                            <ion-button\n                                class=\"f-r\"\n                                *ngIf=\"item.is_rework == '1'\"\n                                size=\"small\"\n                                expand=\"clear\"\n                                color=\"primary\"\n                                (click)=\"feedback(item, sItem)\"\n                                >问题描述</ion-button\n                            >\n\n                            <!-- *ngIf=\"item.data && item.data.length > 1\" -->\n                            <ion-button class=\"f-r\" size=\"small\" color=\"danger\" (click)=\"copy(item, sItem)\"\n                                >复制SKU</ion-button\n                            >\n                        </div>\n                        <app-photograph\n                            [disabled]=\"sItem.is_appraise\"\n                            errorInfo=\"已评价不能上传图片！\"\n                            moduleType=\"removeContractPic\"\n                            [photos]=\"sItem.implement_photo\"\n                            [contract_no]=\"item.contract_no\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"sItem.sku\"\n                            type=\"contract_sku_pic\"\n                        ></app-photograph>\n\n                        <app-item-by-item-desc\n                            class=\"wd-100\"\n                            description=\"备注\"\n                            [ary]=\"sItem.desc\"\n                            (onComplete)=\"descEnter($event, sItem)\"\n                        ></app-item-by-item-desc>\n                    </li>\n                </ol>\n            </div>\n        </ion-item>\n    </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.html ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>{{ data.sku }}</ion-title>\n        <ion-buttons slot=\"end\" class=\"tops\">\n            <ion-button (click)=\"showModal()\" [disabled]=\"alreadyUpProgress\">上传进度</ion-button>\n            <span>箱率：{{ data.rate_container }}</span>\n            <select (change)=\"toggleBoxRate()\" [(ngModel)]=\"rateStatus\" *ngIf=\"data.rate_container != 1\">\n                <option value=\"inner\">内箱</option>\n                <option value=\"outer\">外箱</option>\n            </select>\n            <select *ngIf=\"data.rate_container == 1\">\n                <option value=\"outer\" selected>外箱</option>\n            </select>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/inspect-po\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content #content>\n    <app-sku-info [sku]=\"data\" type=\"implement\"></app-sku-info>\n    <div class=\"label-item\">\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"1.8\">工厂备注:</ion-col>\n                <ion-col size=\"10.2\">{{ factory.factory_desc }}</ion-col>\n            </ion-row>\n        </ion-grid>\n    </div>\n    <div class=\"toggle-box\">\n        <ion-segment (ionChange)=\"segmentChanged($event)\" mode=\"ios\" value=\"beforeUnpacking\">\n            <ion-segment-button value=\"beforeUnpacking\" mode=\"ios\">\n                <ion-label>开箱前</ion-label>\n            </ion-segment-button>\n            <ion-segment-button value=\"afterUnpacking\" mode=\"ios\">\n                <ion-label>开箱后</ion-label>\n            </ion-segment-button>\n            <ion-segment-button value=\"requirement\" mode=\"ios\">\n                <ion-label>验货要求</ion-label>\n            </ion-segment-button>\n        </ion-segment>\n    </div>\n    <form [formGroup]=\"SkuInspectModel\">\n        <div class=\"out-box\">\n            <ion-list>\n                <ion-item fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                    <div class=\"header-input\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                        <label class=\"label\">计划抽检数量</label>\n                        <ion-input\n                            placeholder=\"0\"\n                            type=\"number\"\n                            formControlName=\"spotCheckNum\"\n                            (ionChange)=\"regValid($event)\"\n                        ></ion-input>\n                    </div>\n                    <div class=\"header-input\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                        <label class=\"label\">PO号</label>\n                        <ion-input placeholder=\"PO号\" formControlName=\"poNo\" type=\"text\"></ion-input>\n                    </div>\n\n                    <div class=\"schedule-item w30 border-0\">\n                        <ion-label>PO号是否符合</ion-label>\n                        <select formControlName=\"poNoRes\">\n                            <option value=\"none\">请选择</option>\n                            <option value=\"accord\">符合</option>\n                            <option value=\"notAccord\">不符合</option>\n                        </select>\n                    </div>\n                </ion-item>\n            </ion-list>\n        </div>\n        <!-- 内箱 -->\n        <div class=\"out-box\" *ngIf=\"rateStatus == 'inner'\" formGroupName=\"inner_box_data\">\n            <ion-list *ngIf=\"currentToggle.key == 'beforeUnpacking'\">\n                <ion-item>\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>唛头(照相需六面)</p>\n                        </div>\n                        <app-photograph\n                            type=\"outer_box_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.shippingMarks.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.inner_box_data.shippingMarks.desc\"\n                                (onComplete)=\"descEnter($event, 'shippingMarks', 'inner')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <ion-item formGroupName=\"size\" *ngIf=\"data.rate_container == 1\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>外箱尺寸(单位：CM,叠高高度：1-2M）</p>\n                        </div>\n                        <div class=\"w100\">\n                            <ion-grid class=\"size-grid\">\n                                <ion-row align-items-center>\n                                    <ion-col size=\"4\">叠高尺寸</ion-col>\n                                    <ion-col size=\"4\">叠高数量</ion-col>\n                                    <ion-col size=\"4\">照片上传</ion-col>\n                                </ion-row>\n                                <ion-row align-items-center formGroupName=\"length\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"长\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_length\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.inner_box_data.size.length.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"inner\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n                                <ion-row align-items-center formGroupName=\"width\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"宽\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_width\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.inner_box_data.size.width.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"inner\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n                                <ion-row align-items-center formGroupName=\"height\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"高\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_height\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.inner_box_data.size.height.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"inner\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n                            </ion-grid>\n                        </div>\n\n                        <div class=\"custom-size mt-10\">\n                            <app-custom-outer-size\n                                [sizes]=\"customOuterSize\"\n                                type=\"size_other_pic\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                (onChange)=\"outerSizeChange($event)\"\n                            ></app-custom-outer-size>\n                        </div>\n\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.inner_box_data.size.desc\"\n                                (onComplete)=\"descEnter($event, 'size', 'inner')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <ion-item *ngIf=\"data.rate_container != 1\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>尺寸(单位：CM）</p>\n                        </div>\n                        <inspect-product-size\n                            type=\"size\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            (onChange)=\"sizeChange($event)\"\n                            [sizes]=\"SkuInspectModel.value.inner_box_data.size\"\n                        ></inspect-product-size>\n                        <div class=\"pb-10\" formGroupName=\"sizeDesc\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.sizeDesc.desc\"\n                                    (onComplete)=\"descEnter($event, 'sizeDesc', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n            <ion-list *ngIf=\"currentToggle.key == 'beforeUnpacking'\">\n                <ion-item formGroupName=\"barCode\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>条码</p>\n                        </div>\n                        <div class=\"bar-code\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <input class=\"h-30\" placeholder=\"请输入条码\" formControlName=\"text\" />\n                            <ion-button fill=\"clear\">{{ barCode }}</ion-button>\n                            <ion-button fill=\"clear\" (click)=\"scan('inner')\">\n                                <!-- *ngIf=\"!SkuInspectModel.value.inner_box_data.barCode.isTrue\" -->\n                                扫码\n                            </ion-button>\n                            <ion-button\n                                *ngIf=\"\n                                    SkuInspectModel.value.inner_box_data.barCode.isTrue === '1' ||\n                                    (barCode.length && barCode === SkuInspectModel.value.inner_box_data.barCode.text) ||\n                                    (barCode.length && barCode === innerCode)\n                                \"\n                                color=\"success\"\n                                size=\"small\"\n                                fill=\"clear\"\n                            >\n                                扫码已通过\n                            </ion-button>\n                        </div>\n                        <app-photograph\n                            type=\"bar_code_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.barCode.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <p class=\"global-inspect-title gray-color\">\n                                是否六面条码一致？\n                            </p>\n                            <select class=\"select\" formControlName=\"agreement\">\n                                <option value=\"none\">请选择</option>\n                                <option value=\"1\">是</option>\n                                <option value=\"0\">否</option>\n                            </select>\n                        </div>\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.inner_box_data.barCode.desc\"\n                                (onComplete)=\"descEnter($event, 'barCode', 'inner')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n                <ion-item formGroupName=\"grossWeight\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>毛重(单位：KG)</p>\n                        </div>\n                        <div class=\"maozhong\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\" #grossWeight>\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"text\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text1\"\n                                />\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"text\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text2\"\n                                />\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"text\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text3\"\n                                />\n                            </div>\n                            <div fxLayout=\"row\" class=\"mt-10\" fxLayoutAlign=\"start center\" *ngIf=\"otherGrossWeight\">\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text4\"\n                                />\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text5\"\n                                />\n                            </div>\n                            <app-photograph\n                                type=\"gross_weight_pic\"\n                                moduleType=\"removeSkuPic\"\n                                [photos]=\"SkuInspectModel.value.inner_box_data.grossWeight.photos\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                box_type=\"inner\"\n                            ></app-photograph>\n                            <div class=\"desc-box\">\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.grossWeight.desc\"\n                                    (onComplete)=\"descEnter($event, 'grossWeight', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n            <!-- 摔箱测试 -->\n            <ion-list *ngIf=\"currentToggle.key == 'beforeUnpacking'\">\n                <ion-item formGroupName=\"throwBox\" [hidden]=\"data.is_need_drop_test === '0'\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>摔箱测试</p>\n                        </div>\n                        <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <div class=\"header-input w180\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"label\">计划摔箱数</label>\n                                <ion-input\n                                    placeholder=\"0\"\n                                    [disabled]=\"!data.is_need_drop_test\"\n                                    type=\"number\"\n                                    formControlName=\"text\"\n                                ></ion-input>\n                            </div>\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <p class=\"global-inspect-title gray-color\">是否通过：</p>\n                                <select class=\"select\" formControlName=\"isPass\" [disabled]=\"!data.is_need_drop_test\">\n                                    <option value=\"none\">请选择</option>\n                                    <option value=\"1\">是</option>\n                                    <option value=\"0\">否</option>\n                                </select>\n                            </div>\n                        </div>\n                        <app-photograph\n                            type=\"throw_box_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.throwBox.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <app-videotape\n                            [videos]=\"SkuInspectModel.value.inner_box_data.throwBox.videos\"\n                            type=\"throw_box_video\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-videotape>\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.throwBox.desc\"\n                                        (onComplete)=\"descEnter($event, 'throwBox', 'inner')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n            <!-- 包装 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"packing\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>包装</p>\n                        </div>\n                        <div class=\"packing-info\">\n                            {{ data.packing_type }}\n                        </div>\n                        <p class=\"global-inspect-title gray-color desc-tips\">\n                            包含纸箱层数和纸箱鼓包特写照片\n                        </p>\n                        <app-photograph\n                            type=\"packing_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.packing.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否与以上信息对应？\n                                    </p>\n                                    <select class=\"select\" formControlName=\"isTrue\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"1\">是</option>\n                                        <option value=\"0\">否</option>\n                                    </select>\n                                </div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否是双纸箱:\n                                    </p>\n                                    <select class=\"select\" formControlName=\"is_double_carton\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"1\">是</option>\n                                        <option value=\"0\">否</option>\n                                    </select>\n                                </div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        请选择纸箱类型:\n                                    </p>\n                                    <select class=\"select\" formControlName=\"packingType\">\n                                        <option value=\"none\">\n                                            请选择\n                                        </option>\n                                        <option\n                                            value=\"inner\"\n                                            *ngIf=\"SkuInspectModel.value.inner_box_data.packing.is_double_carton == 1\"\n                                        >\n                                            内箱纸箱类型</option\n                                        >\n                                        <option\n                                            value=\"outer\"\n                                            *ngIf=\"SkuInspectModel.value.inner_box_data.packing.is_double_carton == 1\"\n                                        >\n                                            外箱纸箱类型</option\n                                        >\n                                        <option\n                                            value=\"1\"\n                                            *ngIf=\"SkuInspectModel.value.inner_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            三层单瓦楞</option\n                                        >\n                                        <option\n                                            value=\"2\"\n                                            *ngIf=\"SkuInspectModel.value.inner_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            五层双瓦楞</option\n                                        >\n                                        <option\n                                            value=\"3\"\n                                            *ngIf=\"SkuInspectModel.value.inner_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            七层三瓦楞</option\n                                        >\n                                    </select>\n                                </div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <!--class=\"schedule-item\"-->\n                                    <p class=\"global-inspect-title gray-color\">\n                                        打包带及粘胶带:\n                                    </p>\n                                    <select formControlName=\"packingBelt\" class=\"select\">\n                                        <option value=\"passed\">通过</option>\n                                        <option value=\"notPass\">不通过</option>\n                                        <option value=\"undetermined\">待定</option>\n                                    </select>\n                                </div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否存在鼓包:\n                                    </p>\n                                    <select formControlName=\"swelling\" class=\"select\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"y\">存在</option>\n                                        <option value=\"n\">不存在</option>\n                                    </select>\n                                </div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        多箱率、超重标、易碎贴向上标识等\n                                    </p>\n                                    <ion-label></ion-label>\n                                    <select formControlName=\"rateWeightMark\" class=\"select\">\n                                        <option value=\"passed\">通过</option>\n                                        <option value=\"notPass\">不通过</option>\n                                        <option value=\"undetermined\">待定</option>\n                                    </select>\n                                </div>\n                            </div>\n                            <div\n                                fxLayout=\"row\"\n                                fxLayoutAlign=\"space-between center\"\n                                class=\"schedule-container mb-10\"\n                            ></div>\n\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.packing.desc\"\n                                        (onComplete)=\"descEnter($event, 'packing', 'inner')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n            <!-- 摆放图与说明书及配件包 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"layout\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>摆放图</p>\n                        </div>\n                        <app-photograph\n                            type=\"product_place_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.layout.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.layout.desc\"\n                                    (onComplete)=\"descEnter($event, 'layout', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <!-- <ion-item formGroupName=\"productDetail\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>产品细节图</p>\n                        </div>\n                        <app-photograph\n                            type=\"product_detail_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.productDetail.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.productDetail.desc\"\n                                    (onComplete)=\"descEnter($event, 'productDetail', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item> -->\n            </ion-list>\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"instructions\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>说明书</p>\n                        </div>\n                        <div class=\"ask-about\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <div class=\"item\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <p class=\"global-inspect-title gray-color\">\b是否有说明书</p>\n                                <select class=\"select\" formControlName=\"isHas\">\n                                    <option value=\"none\">请选择</option>\n                                    <option value=\"1\">是</option>\n                                    <option value=\"0\">否</option>\n                                </select>\n                            </div>\n                            <div class=\"item ml-15\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <label class=\"global-inspect-title gray-color\">选择说明书类型</label>\n                                <select class=\"select\" formControlName=\"instructionsType\">\n                                    <option value=\"1\">中性说明书</option>\n                                    <option value=\"2\">我司说明书</option>\n                                </select>\n                            </div>\n                        </div>\n                        <app-photograph\n                            type=\"instructions_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.instructions.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.instructions.desc\"\n                                    (onComplete)=\"descEnter($event, 'instructions', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n                <ion-item formGroupName=\"crews\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>螺丝包</p>\n                        </div>\n\n                        <div class=\"ask-about\">\n                            <div class=\"item\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <p class=\"global-inspect-title gray-color\">\b是否有螺丝包</p>\n                                <select class=\"select\" formControlName=\"isTrue\">\n                                    <option value=\"none\">请选择</option>\n                                    <option value=\"1\">是</option>\n                                    <option value=\"0\">否</option>\n                                </select>\n                            </div>\n                        </div>\n                        <app-photograph\n                            type=\"screws_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.crews.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.crews.desc\"\n                                    (onComplete)=\"descEnter($event, 'crews', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"disputes\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>SKU中文描述</p>\n                        </div>\n\n                        <div class=\"packing-info\">\n                            {{ data.chinese_description }}\n                        </div>\n\n                        <div class=\"w100\">\n                            <div>\n                                <ion-textarea formControlName=\"text\" placeholder=\"请输入SKU描述争议\"></ion-textarea>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 产品整体图 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"whole\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>产品照片</p>\n                        </div>\n                        <app-photograph\n                            type=\"product_wholes_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.whole.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.whole.desc\"\n                                    (onComplete)=\"descEnter($event, 'whole', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 产品尺寸 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item>\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>产品尺寸(单位：CM )</p>\n                        </div>\n                        <inspect-product-size\n                            type=\"productSize\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            (onChange)=\"productSizeChange($event)\"\n                            [sizes]=\"SkuInspectModel.value.inner_box_data.productSize\"\n                        ></inspect-product-size>\n                        <div class=\"pb-10\" formGroupName=\"productSizeDesc\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.inner_box_data.productSizeDesc.desc\"\n                                    (onComplete)=\"descEnter($event, 'productSizeDesc', 'inner')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 净重 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"netWeight\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>净重(单位：KG)</p>\n                        </div>\n                        <div class=\"maozhong\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                <ion-input\n                                    placeholder=\"请输入净重\"\n                                    type=\"number\"\n                                    class=\"mr-10\"\n                                    formControlName=\"textOne\"\n                                >\n                                </ion-input>\n\n                                <ion-input placeholder=\"请输入净重\" type=\"number\" formControlName=\"textTwo\"></ion-input>\n                            </div>\n\n                            <app-photograph\n                                type=\"net_weight_pic\"\n                                moduleType=\"removeSkuPic\"\n                                [photos]=\"SkuInspectModel.value.inner_box_data.netWeight.photos\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                box_type=\"inner\"\n                            ></app-photograph>\n\n                            <div class=\"pb-10\">\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.netWeight.desc\"\n                                        (onComplete)=\"descEnter($event, 'netWeight', 'inner')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 外观检测选项 -->\n            <!-- <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"appearance\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>外观检测选项</p>\n                        </div>\n                        <div class=\"maozhong\">\n                            <ion-input placeholder=\"外观检测选项\" type=\"number\"></ion-input>\n                            <app-photograph\n                                type=\"appearance_pic\"\n                                moduleType=\"removeSkuPic\"\n                                [photos]=\"SkuInspectModel.value.inner_box_data.appearance.photos\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                box_type=\"inner\"\n                            >\n                            </app-photograph>\n                            <app-videotape\n                                [videos]=\"SkuInspectModel.value.inner_box_data.appearance.videos\"\n                                type=\"appearance_video\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                box_type=\"inner\"\n                            ></app-videotape>\n                            <div class=\"test-feedback\">\n                                <div>\n                                    <p class=\"global-inspect-title gray-color desc-tips\">\n                                        请输入说明\n                                    </p>\n                                    <div>\n                                        <app-item-by-item-desc\n                                            description=\"备注\"\n                                            [ary]=\"SkuInspectModel.value.inner_box_data.appearance.desc\"\n                                            (onComplete)=\"descEnter($event, 'appearance', 'inner')\"\n                                        >\n                                        </app-item-by-item-desc>\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list> -->\n\n            <!-- 测试部分 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <!-- 功能性测试 -->\n                <ion-item formGroupName=\"function\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>功能性测试</p>\n                        </div>\n                        <app-photograph\n                            type=\"functions_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.function.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <app-videotape\n                            [videos]=\"SkuInspectModel.value.inner_box_data.function.videos\"\n                            type=\"functions_video\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-videotape>\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.function.desc\"\n                                        (onComplete)=\"descEnter($event, 'function', 'inner')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <!-- 承重测试 -->\n                <ion-item formGroupName=\"bearing\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>承重测试</p>\n                        </div>\n                        <app-photograph\n                            type=\"bearing_test_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.bearing.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <app-videotape\n                            type=\"bearing_test_video\"\n                            [videos]=\"SkuInspectModel.value.inner_box_data.bearing.videos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-videotape>\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.bearing.desc\"\n                                        (onComplete)=\"descEnter($event, 'bearing', 'inner')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <!-- 含水量测试 -->\n                <!-- <ion-item formGroupName=\"waterContent\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>含水量检测</p>\n                        </div>\n                        <app-photograph\n                            type=\"water_content_test_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.waterContent.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <app-videotape\n                            type=\"water_content_test_video\"\n                            [videos]=\"SkuInspectModel.value.inner_box_data.waterContent.videos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-videotape>\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.inner_box_data.waterContent.desc\"\n                                        (onComplete)=\"descEnter($event, 'waterContent', 'inner')\"\n                                    >\n                                    </app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item> -->\n\n                <app-inspect-custom-test\n                    [contract_no]=\"contractNo\"\n                    [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                    [sku]=\"data.sku\"\n                    [box_type]=\"'outer'\"\n                    (onValueChange)=\"customTestChange($event)\"\n                    [customTestArray]=\"customTestArray\"\n                >\n                </app-inspect-custom-test>\n            </ion-list>\n\n            <!-- 总结 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"sumUp\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>总结</p>\n                        </div>\n\n                        <div class=\"maozhong pb-10\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n                            <label for=\"\" class=\"label mf\">请输入实际抽检数量</label>\n                            <ion-input\n                                placeholder=\"0\"\n                                type=\"number\"\n                                class=\"w150\"\n                                class=\"mr-10\"\n                                formControlName=\"textOne\"\n                            ></ion-input>\n                            <label for=\"\" class=\"label mf\">请输入实际摔箱数量</label>\n                            <ion-input placeholder=\"0\" type=\"number\" class=\"w150\" formControlName=\"textTwo\">\n                            </ion-input>\n                        </div>\n\n                        <div class=\"mapzhong schedule-container\">\n                            <div class=\"schedule-item\">\n                                <ion-label>大货生产进度</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"prodSchedule\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                            <div class=\"schedule-item\">\n                                <ion-label>包装</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"package\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                            <div class=\"schedule-item\">\n                                <ion-label>唛头和条形码信息</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"marksAndCode\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                            <div class=\"schedule-item\">\n                                <ion-label>产品信息</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"prodInfo\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                            <div class=\"schedule-item\">\n                                <ion-label>品质工艺</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"qualityTechnology\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                            <div class=\"schedule-item\">\n                                <ion-label>现场测试</ion-label>\n                                <select placeholder=\"请选择\" formControlName=\"fieldTest\">\n                                    <option value=\"passed\">通过</option>\n                                    <option value=\"notPass\">不通过</option>\n                                    <option value=\"undetermined\">待定</option>\n                                </select>\n                            </div>\n                        </div>\n\n                        <app-videotape\n                            type=\"summary_video\"\n                            [videos]=\"SkuInspectModel.value.inner_box_data.sumUp.videos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-videotape>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 备注 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"desc\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>备注</p>\n                        </div>\n                        <app-photograph\n                            type=\"summary_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.inner_box_data.desc.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"inner\"\n                        ></app-photograph>\n                        <div class=\"maozhong pb-10\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.inner_box_data.desc.desc\"\n                                (onComplete)=\"descEnter($event, 'desc', 'inner')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 验货要求 -->\n            <ion-grid class=\"inspection_require\" *ngIf=\"currentToggle.key == 'requirement'\">\n                <!-- *ngIf=\"data.inspection_require && data.inspection_require.length\" -->\n                <ion-row>\n                    <ion-col [size]=\"1.8\" align-self-center>验货条目</ion-col>\n                    <ion-col [size]=\"3.1\" align-self-center>验货要求</ion-col>\n                    <ion-col [size]=\"3.1\" align-self-center>验货标准</ion-col>\n                    <ion-col [size]=\"4\" align-self-center>要求反馈</ion-col>\n                </ion-row>\n                <ng-container *ngIf=\"data.inspection_require && data.inspection_require.length\">\n                    <ion-row *ngFor=\"let item of data.inspection_require; let i = index\">\n                        <ion-col align-self-center [size]=\"1.8\" class=\"content\" Chipboard class=\"chip-text\">\n                            {{ item.theme_name }}\n                        </ion-col>\n                        <ion-col align-self-center [size]=\"3.1\" class=\"content\" Chipboard class=\"chip-text content\">\n                            {{ item.require }}\n                        </ion-col>\n                        <ion-col align-self-center [size]=\"3.1\" class=\"content\" Chipboard class=\"chip-text content\">\n                            {{ item.standard }}\n                        </ion-col>\n                        <ion-col align-self-center [size]=\"4\">\n                            <div>\n                                <app-photograph\n                                    type=\"inspection_require_pic\"\n                                    moduleType=\"removeSkuPic\"\n                                    [photos]=\"\n                                        inspectionRequire && inspectionRequire[i] ? inspectionRequire[i].pic : null\n                                    \"\n                                    [sort_index]=\"i\"\n                                    [contract_no]=\"contractNo\"\n                                    [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                    [sku]=\"data.sku\"\n                                    box_type=\"inner\"\n                                ></app-photograph>\n                            </div>\n                            <div>\n                                <app-videotape\n                                    [videos]=\"\n                                        inspectionRequire && inspectionRequire[i] ? inspectionRequire[i].videos : null\n                                    \"\n                                    type=\"inspection_require_video\"\n                                    [sort_index]=\"i\"\n                                    [contract_no]=\"contractNo\"\n                                    [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                    [sku]=\"data.sku\"\n                                    box_type=\"inner\"\n                                ></app-videotape>\n                            </div>\n                        </ion-col>\n                    </ion-row>\n                </ng-container>\n                <ion-row *ngIf=\"data.inspection_require && !data.inspection_require.length\">\n                    <ion-col size=\"12\" style=\"text-align: center;\" class=\"danger\">暂无</ion-col>\n                </ion-row>\n            </ion-grid>\n        </div>\n\n        <!-- 外箱 -->\n        <div class=\"out-box\" *ngIf=\"rateStatus == 'outer'\" formGroupName=\"outer_box_data\">\n            <ion-list *ngIf=\"currentToggle.key == 'beforeUnpacking'\">\n                <ion-item>\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>唛头(照相需六面)</p>\n                        </div>\n\n                        <app-photograph\n                            type=\"outer_box_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.outer_box_data.shippingMarks.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"outer\"\n                        ></app-photograph>\n\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.outer_box_data.shippingMarks.desc\"\n                                (onComplete)=\"descEnter($event, 'shippingMarks', 'outer')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <ion-item formGroupName=\"size\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>外箱尺寸(单位：CM,叠高高度：1-2M）</p>\n                        </div>\n\n                        <div class=\"w100\">\n                            <ion-grid class=\"size-grid\">\n                                <ion-row align-items-center>\n                                    <ion-col size=\"4\">叠高尺寸</ion-col>\n                                    <ion-col size=\"4\">叠高数量</ion-col>\n                                    <ion-col size=\"4\">照片上传</ion-col>\n                                </ion-row>\n\n                                <ion-row align-items-center formGroupName=\"length\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"长\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_length\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.outer_box_data.size.length.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"outer\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n\n                                <ion-row align-items-center formGroupName=\"width\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"宽\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_width\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.outer_box_data.size.width.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"outer\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n\n                                <ion-row align-items-center formGroupName=\"height\">\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"高\" formControlName=\"text\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <input type=\"number\" placeholder=\"0\" formControlName=\"num\" />\n                                    </ion-col>\n                                    <ion-col size=\"4\">\n                                        <app-photograph\n                                            type=\"size_pic_height\"\n                                            moduleType=\"removeSkuPic\"\n                                            [photos]=\"SkuInspectModel.value.outer_box_data.size.height.pic\"\n                                            [contract_no]=\"contractNo\"\n                                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                            [sku]=\"data.sku\"\n                                            box_type=\"outer\"\n                                        ></app-photograph>\n                                    </ion-col>\n                                </ion-row>\n                            </ion-grid>\n                        </div>\n\n                        <div class=\"custom-size mt-10\">\n                            <app-custom-outer-size\n                                [sizes]=\"customOuterSize\"\n                                type=\"size_other_pic\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                (onChange)=\"outerSizeChange($event)\"\n                            ></app-custom-outer-size>\n                        </div>\n\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.outer_box_data.size.desc\"\n                                (onComplete)=\"descEnter($event, 'size', 'outer')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <ion-list *ngIf=\"currentToggle.key == 'beforeUnpacking'\">\n                <ion-item formGroupName=\"barCode\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>条码</p>\n                        </div>\n                        <div class=\"bar-code\" fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <input class=\"h-30\" placeholder=\"请输入条码\" formControlName=\"text\" />\n                            <ion-button fill=\"clear\">{{ outerBarCode }}</ion-button>\n                            <ion-button [fill]=\"'clear'\" (click)=\"scan('outer')\">\n                                扫码\n                                <!-- [disabled]=\"barCode\" -->\n                                <!-- *ngIf=\"!SkuInspectModel.value.outer_box_data.barCode.isTrue\" -->\n                                <!-- {{ barCode ? barCode : '扫码' }} -->\n                            </ion-button>\n                            <ion-button\n                                *ngIf=\"\n                                    SkuInspectModel.value.outer_box_data.barCode.isTrue == '1' ||\n                                    (outerBarCode &&\n                                        outerBarCode == SkuInspectModel.value.outer_box_data.barCode.text) ||\n                                    (outerBarCode && outerBarCode == outerCode)\n                                \"\n                                color=\"success\"\n                                size=\"small\"\n                                fill=\"clear\"\n                            >\n                                扫码已通过\n                            </ion-button>\n                        </div>\n                        <app-photograph\n                            type=\"bar_code_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.outer_box_data.barCode.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"outer\"\n                        ></app-photograph>\n\n                        <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                            <p class=\"global-inspect-title gray-color\">\n                                是否六面条码一致？\n                            </p>\n                            <select class=\"select\" formControlName=\"agreement\">\n                                <option value=\"none\">请选择</option>\n                                <option value=\"1\">是</option>\n                                <option value=\"0\">否</option>\n                            </select>\n                        </div>\n                        <div class=\"desc-box\">\n                            <app-item-by-item-desc\n                                description=\"备注\"\n                                [ary]=\"SkuInspectModel.value.outer_box_data.barCode.desc\"\n                                (onComplete)=\"descEnter($event, 'barCode', 'outer')\"\n                            ></app-item-by-item-desc>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <ion-item formGroupName=\"grossWeight\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>毛重(单位：KG)</p>\n                        </div>\n                        <div class=\"maozhong\">\n                            <div fxLayout=\"row\" fxLayoutAlign=\"start center\" #grossWeight>\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text1\"\n                                />\n\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text2\"\n                                />\n\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text3\"\n                                />\n                            </div>\n\n                            <div fxLayout=\"row\" class=\"mt-10\" fxLayoutAlign=\"start center\" *ngIf=\"otherGrossWeight\">\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text4\"\n                                />\n                                <input\n                                    placeholder=\"请输入毛重\"\n                                    type=\"number\"\n                                    (change)=\"calcGrossWeight()\"\n                                    class=\"mr-10\"\n                                    formControlName=\"text5\"\n                                />\n                            </div>\n\n                            <app-photograph\n                                type=\"gross_weight_pic\"\n                                moduleType=\"removeSkuPic\"\n                                [photos]=\"SkuInspectModel.value.outer_box_data.grossWeight.photos\"\n                                [contract_no]=\"contractNo\"\n                                [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                                [sku]=\"data.sku\"\n                                box_type=\"outer\"\n                            ></app-photograph>\n                            <div class=\"desc-box\">\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.outer_box_data.grossWeight.desc\"\n                                    (onComplete)=\"descEnter($event, 'grossWeight', 'outer')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 包装 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"packing\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>包装</p>\n                        </div>\n\n                        <div class=\"packing-info\">\n                            {{ data.packing_type }}\n                        </div>\n                        <p class=\"global-inspect-title gray-color desc-tips\">\n                            包含纸箱层数和纸箱鼓包特写照片\n                        </p>\n                        <app-photograph\n                            type=\"packing_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.outer_box_data.packing.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"outer\"\n                        ></app-photograph>\n\n                        <div class=\"test-feedback\">\n                            <div>\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否与以上信息对应？\n                                    </p>\n                                    <select class=\"select\" formControlName=\"isTrue\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"1\">是</option>\n                                        <option value=\"0\">否</option>\n                                    </select>\n                                </div>\n\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否是双纸箱\n                                    </p>\n                                    <select class=\"select\" formControlName=\"is_double_carton\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"1\">是</option>\n                                        <option value=\"0\">否</option>\n                                    </select>\n                                </div>\n\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        请选择纸箱类型\n                                    </p>\n                                    <select class=\"select\" formControlName=\"packingType\">\n                                        <option value=\"none\">\n                                            请选择\n                                        </option>\n                                        <option\n                                            value=\"inner\"\n                                            *ngIf=\"SkuInspectModel.value.outer_box_data.packing.is_double_carton == 1\"\n                                        >\n                                            内箱纸箱类型</option\n                                        >\n                                        <option\n                                            value=\"outer\"\n                                            *ngIf=\"SkuInspectModel.value.outer_box_data.packing.is_double_carton == 1\"\n                                        >\n                                            外箱纸箱类型</option\n                                        >\n                                        <option\n                                            value=\"1\"\n                                            *ngIf=\"SkuInspectModel.value.outer_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            三层单瓦楞</option\n                                        >\n                                        <option\n                                            value=\"2\"\n                                            *ngIf=\"SkuInspectModel.value.outer_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            五层双瓦楞</option\n                                        >\n                                        <option\n                                            value=\"3\"\n                                            *ngIf=\"SkuInspectModel.value.outer_box_data.packing.is_double_carton == 0\"\n                                        >\n                                            七层三瓦楞</option\n                                        >\n                                    </select>\n                                </div>\n\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        打包带及粘胶带:\n                                    </p>\n                                    <select formControlName=\"packingBelt\" class=\"select\">\n                                        <option value=\"passed\">通过</option>\n                                        <option value=\"notPass\">不通过</option>\n                                        <option value=\"undetermined\">待定</option>\n                                    </select>\n                                </div>\n\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        是否存在鼓包:\n                                    </p>\n                                    <select formControlName=\"swelling\" class=\"select\">\n                                        <option value=\"none\">请选择</option>\n                                        <option value=\"y\">存在</option>\n                                        <option value=\"n\">不存在</option>\n                                    </select>\n                                </div>\n\n                                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                                    <p class=\"global-inspect-title gray-color\">\n                                        多箱率、超重标、易碎贴向上标识等\n                                    </p>\n                                    <select formControlName=\"rateWeightMark\" class=\"select\">\n                                        <option value=\"passed\">通过</option>\n                                        <option value=\"notPass\">不通过</option>\n                                        <option value=\"undetermined\">待定</option>\n                                    </select>\n                                </div>\n                            </div>\n\n                            <div>\n                                <div>\n                                    <app-item-by-item-desc\n                                        description=\"备注\"\n                                        [ary]=\"SkuInspectModel.value.outer_box_data.packing.desc\"\n                                        (onComplete)=\"descEnter($event, 'packing', 'outer')\"\n                                    ></app-item-by-item-desc>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n\n            <!-- 摆放图与说明书及配件包 -->\n            <ion-list *ngIf=\"currentToggle.key == 'afterUnpacking'\">\n                <ion-item formGroupName=\"layout\">\n                    <div class=\"w100\">\n                        <div class=\"global-inspect-title\">\n                            <p>摆放图</p>\n                        </div>\n                        <app-photograph\n                            type=\"product_place_pic\"\n                            moduleType=\"removeSkuPic\"\n                            [photos]=\"SkuInspectModel.value.outer_box_data.layout.photos\"\n                            [contract_no]=\"contractNo\"\n                            [apply_inspection_no]=\"currentApplyInsData.apply_inspection_no\"\n                            [sku]=\"data.sku\"\n                            box_type=\"outer\"\n                        ></app-photograph>\n                        <div class=\"pb-10\">\n                            <div>\n                                <app-item-by-item-desc\n                                    description=\"备注\"\n                                    [ary]=\"SkuInspectModel.value.outer_box_data.layout.desc\"\n                                    (onComplete)=\"descEnter($event, 'layout', 'outer')\"\n                                ></app-item-by-item-desc>\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n            </ion-list>\n        </div>\n    </form>\n</ion-content>\n\n<ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" *ngIf=\"!inspectRequireSegment\">\n    <ion-fab-button color=\"secondary\">\n        <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n\n    <ion-fab-list side=\"start\">\n        <ion-fab-button (click)=\"save().subscribe()\" color=\"danger\">\n            <p>保存</p>\n        </ion-fab-button>\n\n        <!-- <ion-fab-button (click)=\"uQueue.run()\" color=\"primary\">\n            <p>上传</p>\n        </ion-fab-button> -->\n    </ion-fab-list>\n\n    <ion-fab-list side=\"top\">\n        <ion-fab-button (click)=\"content.scrollToTop()\" color=\"primary\">\n            <p>顶部</p>\n        </ion-fab-button>\n    </ion-fab-list>\n</ion-fab>\n"

/***/ }),

/***/ "./src/app/inspect-tab-bar/inspect-tab-bar.component.scss":
/*!****************************************************************!*\
  !*** ./src/app/inspect-tab-bar/inspect-tab-bar.component.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ul {\n  width: 100%;\n  border: 1px solid #2c6aff;\n  height: 24px;\n  color: #2c6aff;\n  border-radius: 4px;\n  overflow: hidden;\n}\nul li {\n  cursor: pointer;\n  text-align: center;\n  line-height: 24px;\n  width: 33.33%;\n  float: left;\n  font-size: 13px;\n  background: #fff;\n  border-right: 1px solid #2c6aff;\n}\nul li:last-child {\n  border: 0;\n}\nul li.active {\n  background: #2c6aff;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9pbnNwZWN0LXRhYi1iYXIvaW5zcGVjdC10YWItYmFyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9pbnNwZWN0LXRhYi1iYXIvaW5zcGVjdC10YWItYmFyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDQ0o7QURBSTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtBQ0VSO0FEQUk7RUFDSSxTQUFBO0FDRVI7QURBSTtFQUNJLG1CQUFBO0VBQ0EsV0FBQTtBQ0VSIiwiZmlsZSI6InNyYy9hcHAvaW5zcGVjdC10YWItYmFyL2luc3BlY3QtdGFiLWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInVse1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICMyYzZhZmY7XG4gICAgaGVpZ2h0OiAyNHB4O1xuICAgIGNvbG9yOiAjMmM2YWZmO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweCA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBsaXtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICAgICAgICB3aWR0aDogMzMuMzMlO1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjMmM2YWZmO1xuICAgIH1cbiAgICBsaTpsYXN0LWNoaWxke1xuICAgICAgICBib3JkZXI6IDAgO1xuICAgIH1cbiAgICBsaS5hY3RpdmV7XG4gICAgICAgIGJhY2tncm91bmQ6ICMyYzZhZmY7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgIH1cbn0iLCJ1bCB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXI6IDFweCBzb2xpZCAjMmM2YWZmO1xuICBoZWlnaHQ6IDI0cHg7XG4gIGNvbG9yOiAjMmM2YWZmO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG51bCBsaSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgd2lkdGg6IDMzLjMzJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzJjNmFmZjtcbn1cbnVsIGxpOmxhc3QtY2hpbGQge1xuICBib3JkZXI6IDA7XG59XG51bCBsaS5hY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjMmM2YWZmO1xuICBjb2xvcjogI2ZmZjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/inspect-tab-bar/inspect-tab-bar.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/inspect-tab-bar/inspect-tab-bar.component.ts ***!
  \**************************************************************/
/*! exports provided: InspectTabBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectTabBarComponent", function() { return InspectTabBarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var InspectTabBarComponent = /** @class */ (function () {
    function InspectTabBarComponent() {
        this.onSelect = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.current = 'before';
    }
    InspectTabBarComponent.prototype.ngOnInit = function () { };
    InspectTabBarComponent.prototype.select = function (s) {
        this.current = s;
        this.onSelect.emit(s);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], InspectTabBarComponent.prototype, "onSelect", void 0);
    InspectTabBarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-inspect-tab-bar',
            template: __webpack_require__(/*! raw-loader!./inspect-tab-bar.component.html */ "./node_modules/raw-loader/index.js!./src/app/inspect-tab-bar/inspect-tab-bar.component.html"),
            styles: [__webpack_require__(/*! ./inspect-tab-bar.component.scss */ "./src/app/inspect-tab-bar/inspect-tab-bar.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], InspectTabBarComponent);
    return InspectTabBarComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/evaluation/evaluation.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/evaluation/evaluation.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2V2YWx1YXRpb24vZXZhbHVhdGlvbi5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/evaluation/evaluation.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/evaluation/evaluation.component.ts ***!
  \*******************************************************************************/
/*! exports provided: EvaluationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluationComponent", function() { return EvaluationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");




var EvaluationComponent = /** @class */ (function () {
    function EvaluationComponent(es, storage) {
        this.es = es;
        this.storage = storage;
    }
    EvaluationComponent.prototype.ngOnInit = function () { };
    EvaluationComponent.ctorParameters = function () { return [
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] }
    ]; };
    EvaluationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-evaluation',
            template: __webpack_require__(/*! raw-loader!./evaluation.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/evaluation/evaluation.component.html"),
            styles: [__webpack_require__(/*! ./evaluation.component.scss */ "./src/app/pages/implement-inspection/evaluation/evaluation.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"], src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"]])
    ], EvaluationComponent);
    return EvaluationComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/implement-inspection.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/implement-inspection.module.ts ***!
  \***************************************************************************/
/*! exports provided: ImplementInspectionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImplementInspectionPageModule", function() { return ImplementInspectionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _inspect_factory_examine_detail_examine_detail_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inspect-factory/examine-detail/examine-detail.component */ "./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.ts");
/* harmony import */ var _evaluation_evaluation_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./evaluation/evaluation.component */ "./src/app/pages/implement-inspection/evaluation/evaluation.component.ts");
/* harmony import */ var _inspect_sku_inspect_sku_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inspect-sku/inspect-sku.component */ "./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.ts");
/* harmony import */ var _directives_directive_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../directives/directive.module */ "./src/app/directives/directive.module.ts");
/* harmony import */ var _pipe_sku_list_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../pipe/sku-list.pipe */ "./src/app/pipe/sku-list.pipe.ts");
/* harmony import */ var _widget_widget_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../widget/widget.module */ "./src/app/widget/widget.module.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _implement_inspection_page__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./implement-inspection.page */ "./src/app/pages/implement-inspection/implement-inspection.page.ts");
/* harmony import */ var src_app_pipe_contract_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/pipe/contract.pipe */ "./src/app/pipe/contract.pipe.ts");
/* harmony import */ var _inspect_factory_inspect_factory_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./inspect-factory/inspect-factory.component */ "./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.ts");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./inspect-po/inspect-po.component */ "./src/app/pages/implement-inspection/inspect-po/inspect-po.component.ts");
/* harmony import */ var src_app_pipe_test_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/pipe/test.pipe */ "./src/app/pipe/test.pipe.ts");
/* harmony import */ var _sku_guard__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./sku.guard */ "./src/app/pages/implement-inspection/sku.guard.ts");
/* harmony import */ var src_app_inspect_tab_bar_inspect_tab_bar_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/inspect-tab-bar/inspect-tab-bar.component */ "./src/app/inspect-tab-bar/inspect-tab-bar.component.ts");
/* harmony import */ var _inspect_parts_inspect_parts_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./inspect-parts/inspect-parts.component */ "./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.ts");
/* harmony import */ var _inspect_custom_test_inspect_custom_test_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./inspect-custom-test/inspect-custom-test.component */ "./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.ts");
/* harmony import */ var _inspect_check_inspect_check_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./inspect-check/inspect-check.component */ "./src/app/pages/implement-inspection/inspect-check/inspect-check.component.ts");
























var routes = [
    {
        path: 'implement-inspection',
        component: _implement_inspection_page__WEBPACK_IMPORTED_MODULE_13__["ImplementInspectionPage"],
    },
    {
        path: 'inspect-factory/:fid/:apply_group_id',
        component: _inspect_factory_inspect_factory_component__WEBPACK_IMPORTED_MODULE_15__["InspectFactoryComponent"],
    },
    {
        path: 'inspect-po/:fid',
        component: _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_17__["InspectPoComponent"],
    },
    {
        path: 'inspect-sku/:contract_no',
        component: _inspect_sku_inspect_sku_component__WEBPACK_IMPORTED_MODULE_3__["InspectSkuComponent"],
        canDeactivate: [_sku_guard__WEBPACK_IMPORTED_MODULE_19__["SkuGuard"]],
    },
    {
        path: 'inspect-evaluation',
        component: _evaluation_evaluation_component__WEBPACK_IMPORTED_MODULE_2__["EvaluationComponent"],
    },
    {
        path: 'inspect-parts',
        component: _inspect_parts_inspect_parts_component__WEBPACK_IMPORTED_MODULE_21__["InspectPartsComponent"]
    },
    {
        path: 'inspect-check',
        component: _inspect_check_inspect_check_component__WEBPACK_IMPORTED_MODULE_23__["InspectCheckComponent"]
    }
];
var ImplementInspectionPageModule = /** @class */ (function () {
    function ImplementInspectionPageModule() {
    }
    ImplementInspectionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_8__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_9__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_7__["FlexLayoutModule"],
                _widget_widget_module__WEBPACK_IMPORTED_MODULE_6__["WidgetModule"],
                _directives_directive_module__WEBPACK_IMPORTED_MODULE_4__["DirectiveModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_12__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_11__["RouterModule"].forChild(routes),
            ],
            declarations: [
                _implement_inspection_page__WEBPACK_IMPORTED_MODULE_13__["ImplementInspectionPage"],
                src_app_pipe_contract_pipe__WEBPACK_IMPORTED_MODULE_14__["ContractPipe"],
                _pipe_sku_list_pipe__WEBPACK_IMPORTED_MODULE_5__["SkuListPipe"],
                src_app_pipe_test_pipe__WEBPACK_IMPORTED_MODULE_18__["TestPipe"],
                _inspect_factory_inspect_factory_component__WEBPACK_IMPORTED_MODULE_15__["InspectFactoryComponent"],
                _inspect_po_inspect_po_component__WEBPACK_IMPORTED_MODULE_17__["InspectPoComponent"],
                _inspect_sku_inspect_sku_component__WEBPACK_IMPORTED_MODULE_3__["InspectSkuComponent"],
                _evaluation_evaluation_component__WEBPACK_IMPORTED_MODULE_2__["EvaluationComponent"],
                _inspect_factory_examine_detail_examine_detail_component__WEBPACK_IMPORTED_MODULE_1__["ExamineDetailComponent"],
                src_app_inspect_tab_bar_inspect_tab_bar_component__WEBPACK_IMPORTED_MODULE_20__["InspectTabBarComponent"],
                _inspect_parts_inspect_parts_component__WEBPACK_IMPORTED_MODULE_21__["InspectPartsComponent"],
                _inspect_custom_test_inspect_custom_test_component__WEBPACK_IMPORTED_MODULE_22__["InspectCustomTestComponent"],
                _inspect_check_inspect_check_component__WEBPACK_IMPORTED_MODULE_23__["InspectCheckComponent"]
            ],
            providers: [_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_16__["Camera"]],
        })
    ], ImplementInspectionPageModule);
    return ImplementInspectionPageModule;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/implement-inspection.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/implement-inspection.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-col {\n  height: 100%;\n}\n\n.ion-col-no-pad {\n  padding: 0 !important;\n  padding-right: 0 !important;\n}\n\nion-row.title {\n  font-weight: bold;\n  background: #f7f7f7;\n}\n\n.card-header {\n  font-size: 14px !important;\n}\n\n.card-header span {\n  color: #636363;\n}\n\nion-card {\n  background: #f5f6f9;\n}\n\nion-card > ion-item {\n  --background: #ebecee;\n}\n\nion-card .card-content-md {\n  padding-right: 0 !important;\n  padding-left: 0 !important;\n}\n\nion-card ion-grid {\n  padding: 0 !important;\n}\n\n.text-r {\n  text-align: right !important;\n}\n\n.text-c {\n  text-align: center !important;\n}\n\n.pl-5 {\n  font-weight: bold;\n  padding-left: 5px !important;\n}\n\nion-button {\n  margin: 0 !important;\n  --padding-start: 5px;\n  --padding-end: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbXBsZW1lbnQtaW5zcGVjdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2ltcGxlbWVudC1pbnNwZWN0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUNDSjs7QURHQTtFQUNJLHFCQUFBO0VBQ0EsMkJBQUE7QUNBSjs7QURHQTtFQUNJLGlCQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURHQTtFQUNJLDBCQUFBO0FDQUo7O0FEQ0k7RUFDSSxjQUFBO0FDQ1I7O0FER0E7RUFDSSxtQkFBQTtBQ0FKOztBRENJO0VBQ0kscUJBQUE7QUNDUjs7QURDSTtFQUNJLDJCQUFBO0VBQ0EsMEJBQUE7QUNDUjs7QURDSTtFQUNJLHFCQUFBO0FDQ1I7O0FER0E7RUFDSSw0QkFBQTtBQ0FKOztBREdBO0VBQ0ksNkJBQUE7QUNBSjs7QURHQTtFQUNJLGlCQUFBO0VBQ0EsNEJBQUE7QUNBSjs7QURHQTtFQUNJLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW1wbGVtZW50LWluc3BlY3Rpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICNlYmViZWJcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tcm93LnRpdGxlIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xufVxuXG4uY2FyZC1oZWFkZXJ7XG4gICAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG4gICAgc3BhbntcbiAgICAgICAgY29sb3I6ICM2MzYzNjM7XG4gICAgfVxufVxuXG5pb24tY2FyZCB7XG4gICAgYmFja2dyb3VuZDogI2Y1ZjZmOTtcbiAgICA+IGlvbi1pdGVtIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZWJlY2VlO1xuICAgIH1cbiAgICAuY2FyZC1jb250ZW50LW1kIHtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAgIWltcG9ydGFudDtcbiAgICB9XG4gICAgaW9uLWdyaWQge1xuICAgICAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuXG4udGV4dC1yIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodCAhaW1wb3J0YW50O1xufVxuXG4udGV4dC1jIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuLnBsLTV7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogNXB4O1xufVxuXG5pb24tY2FyZC1jb250ZW50e1xuICAgIC8vIHBhZGRpbmctdG9wOiAwICFpbXBvcnRhbnQ7XG59IiwiaW9uLWNvbCB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1yb3cudGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbn1cblxuLmNhcmQtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG59XG4uY2FyZC1oZWFkZXIgc3BhbiB7XG4gIGNvbG9yOiAjNjM2MzYzO1xufVxuXG5pb24tY2FyZCB7XG4gIGJhY2tncm91bmQ6ICNmNWY2Zjk7XG59XG5pb24tY2FyZCA+IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZWJlY2VlO1xufVxuaW9uLWNhcmQgLmNhcmQtY29udGVudC1tZCB7XG4gIHBhZGRpbmctcmlnaHQ6IDAgIWltcG9ydGFudDtcbiAgcGFkZGluZy1sZWZ0OiAwICFpbXBvcnRhbnQ7XG59XG5pb24tY2FyZCBpb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbn1cblxuLnRleHQtciB7XG4gIHRleHQtYWxpZ246IHJpZ2h0ICFpbXBvcnRhbnQ7XG59XG5cbi50ZXh0LWMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuLnBsLTUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctc3RhcnQ6IDVweDtcbiAgLS1wYWRkaW5nLWVuZDogNXB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/implement-inspection.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/implement-inspection.page.ts ***!
  \*************************************************************************/
/*! exports provided: ImplementInspectionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImplementInspectionPage", function() { return ImplementInspectionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");







var ImplementInspectionPage = /** @class */ (function () {
    function ImplementInspectionPage(inspectService, effectCtrl, storage, router) {
        this.inspectService = inspectService;
        this.effectCtrl = effectCtrl;
        this.storage = storage;
        this.router = router;
        this.active = 'factory';
        this.inspectTask = [];
        this.metaInspectTask = [];
        this.task = [];
        this.factory = '';
        this.contract = '';
        this.contractList = [];
        this.getListParams = {
            page: 1,
            keywords: 'factory_name',
            value: '',
        };
        this.keywords = '';
        this.page = 1;
    }
    ImplementInspectionPage.prototype.ngOnInit = function () { };
    ImplementInspectionPage.prototype.toInspect = function (contractNo, inspectId) {
        console.log(contractNo, inspectId);
        this.router.navigate(['/inspect-factory', contractNo, inspectId]);
    };
    ImplementInspectionPage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.getListParams.page = 1;
        this.inspectService.getInspectTaskList(this.getListParams).subscribe(function (res) {
            _this.metaInspectTask = res.data;
            _this.inspectTask = JSON.parse(JSON.stringify(res.data));
            _this.task = res;
            _this.getListParams.page = res.current_page + 1;
            _this.storage.set('IMPLEMENT-INSPECTION-META-DATA', _this.inspectTask);
        });
    };
    Object.defineProperty(ImplementInspectionPage.prototype, "apply_id", {
        get: function () {
            var _this = this;
            if (!this.task.length)
                return;
            var rVal;
            this.task.forEach(function (res) {
                res.forEach(function (task) {
                    task.contract.id == _this.factory && (rVal = task.id);
                });
            });
            return rVal;
        },
        enumerable: true,
        configurable: true
    });
    ImplementInspectionPage.prototype.factoryChange = function () {
        var _this = this;
        this.getListParams.page = 1;
        this.inspectService.getInspectTaskList(this.getListParams).subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.inspectTask = res.data;
                _this.getListParams.page = res.current_page + 1;
                _this.storage.set('IMPLEMENT-INSPECTION-META-DATA', _this.inspectTask);
            }
            else {
                _this.inspectTask = [];
            }
        });
    };
    ImplementInspectionPage.prototype.loadData = function (event) {
        var _this = this;
        this.inspectService.getInspectTaskList(this.getListParams).subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.inspectTask = _this.inspectTask.concat(res.data);
                _this.getListParams.page = res.current_page + 1;
                _this.storage.set('IMPLEMENT-INSPECTION-META-DATA', _this.inspectTask);
            }
            else {
                _this.effectCtrl.showToast({
                    message: '别刷了，没有数据啦！',
                    color: 'danger',
                });
            }
            event.target.complete();
        });
    };
    ImplementInspectionPage.ctorParameters = function () { return [
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
    ]; };
    ImplementInspectionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-implement-inspection',
            template: __webpack_require__(/*! raw-loader!./implement-inspection.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/implement-inspection.page.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["trigger"])('openClose', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('open', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        opacity: 1,
                        right: 0,
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('closed', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        opacity: 0,
                        right: '100%',
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('back', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        opacity: 0,
                        right: '-100%',
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('open => closed', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('0.3s ease-in-out')]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('back => open', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('0.3s ease-out')]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('open => back', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('0.3s ease-in-out')]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('closed => open', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('0.3s ease-out')]),
                ]),
            ],
            styles: [__webpack_require__(/*! ./implement-inspection.page.scss */ "./src/app/pages/implement-inspection/implement-inspection.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], ImplementInspectionPage);
    return ImplementInspectionPage;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-check/inspect-check.component.scss":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-check/inspect-check.component.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #f2f2f2;\n  --padding-top: 15px;\n  --padding-bottom: 15px;\n  --padding-start: 10px;\n  --padding-end: 10px;\n}\nion-content .out-box {\n  padding: 5px;\n}\n.global-inspect-title {\n  font-size: 14px;\n  color: #3880fc;\n  font-weight: bold;\n  margin: 5px 0 !important;\n}\n.global-inspect-title p {\n  margin: 0;\n}\n.desc-box {\n  width: 100%;\n  padding-bottom: 10px;\n}\nion-item:last-child {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\n.label {\n  color: #434343;\n}\nion-input,\ninput {\n  height: 30px;\n  margin-right: 40px;\n  border: 1px solid #e3e3e3;\n  width: 100px;\n  font-size: 14px;\n  text-align: center;\n  border-radius: 5px;\n  --padding-top: 5px;\n  --padding-bottom: 5px;\n}\nion-list {\n  margin: 10px 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LWNoZWNrL2luc3BlY3QtY2hlY2suY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtY2hlY2svaW5zcGVjdC1jaGVjay5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUNDSjtBREFJO0VBQ0ksWUFBQTtBQ0VSO0FER0E7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUNBSjtBRENJO0VBQ0ksU0FBQTtBQ0NSO0FER0E7RUFDSSxXQUFBO0VBQ0Esb0JBQUE7QUNBSjtBREdBO0VBQ0ksaUJBQUE7RUFDQSx1QkFBQTtBQ0FKO0FER0E7RUFDSSxjQUFBO0FDQUo7QURHQTs7RUFFSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNBSjtBREdBO0VBQ0ksY0FBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1jaGVjay9pbnNwZWN0LWNoZWNrLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgICAtLXBhZGRpbmctdG9wOiAxNXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gICAgLm91dC1ib3gge1xuICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgfVxufVxuIFxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBjb2xvcjogIzM4ODBmYztcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG4gICAgcCB7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICB9XG59XG5cbi5kZXNjLWJveCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1pdGVtOmxhc3QtY2hpbGQge1xuICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xufVxuXG4ubGFiZWwge1xuICAgIGNvbG9yOiAjNDM0MzQzO1xufVxuXG5pb24taW5wdXQsXG5pbnB1dCB7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIG1hcmdpbi1yaWdodDogNDBweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTNlM2UzO1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAtLXBhZGRpbmctdG9wOiA1cHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG5pb24tbGlzdCB7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG4gIC0tcGFkZGluZy10b3A6IDE1cHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbn1cbmlvbi1jb250ZW50IC5vdXQtYm94IHtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMzg4MGZjO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiA1cHggMCAhaW1wb3J0YW50O1xufVxuLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHAge1xuICBtYXJnaW46IDA7XG59XG5cbi5kZXNjLWJveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWl0ZW06bGFzdC1jaGlsZCB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcbn1cblxuLmxhYmVsIHtcbiAgY29sb3I6ICM0MzQzNDM7XG59XG5cbmlvbi1pbnB1dCxcbmlucHV0IHtcbiAgaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDQwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XG4gIHdpZHRoOiAxMDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgLS1wYWRkaW5nLXRvcDogNXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbmlvbi1saXN0IHtcbiAgbWFyZ2luOiAxMHB4IDA7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-check/inspect-check.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-check/inspect-check.component.ts ***!
  \*************************************************************************************/
/*! exports provided: InspectCheckComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectCheckComponent", function() { return InspectCheckComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");






var InspectCheckComponent = /** @class */ (function () {
    function InspectCheckComponent(uQueue, es, fb) {
        this.uQueue = uQueue;
        this.es = es;
        this.fb = fb;
        this.skuInfo = {};
        this.skuInspectModel = this.fb.group({});
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
    }
    InspectCheckComponent.prototype.ngOnInit = function () { };
    InspectCheckComponent.prototype.showModal = function () {
        this.es.showModal({
            component: _queue_queue_component__WEBPACK_IMPORTED_MODULE_4__["QueueComponent"],
        });
        this.uQueue.alreadyUpProgress = true;
    };
    InspectCheckComponent.prototype.descEnter = function (e, type, boxType) { };
    InspectCheckComponent.prototype.scan = function () {
    };
    InspectCheckComponent.ctorParameters = function () { return [
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_2__["UploadQueueService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] }
    ]; };
    InspectCheckComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-inspect-check',
            template: __webpack_require__(/*! raw-loader!./inspect-check.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-check/inspect-check.component.html"),
            styles: [__webpack_require__(/*! ./inspect-check.component.scss */ "./src/app/pages/implement-inspection/inspect-check/inspect-check.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_upload_queue_service__WEBPACK_IMPORTED_MODULE_2__["UploadQueueService"], src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]])
    ], InspectCheckComponent);
    return InspectCheckComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.scss":
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.scss ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".global-inspect-title {\n  font-size: 14px;\n  color: #000;\n  font-weight: bold;\n  margin: 5px 0 !important;\n  padding-left: 15px;\n}\n.global-inspect-title p {\n  text-decoration: underline;\n  margin: 0;\n}\ninput {\n  border: 1px solid #e3e3e3;\n  height: 30px;\n  width: 50%;\n  outline: 0;\n  border-radius: 5px;\n  font-size: 14px;\n  overflow: hidden;\n}\n.w-60 {\n  width: 60%;\n}\nion-item {\n  margin-top: 10px;\n}\n.preview {\n  font-size: 14px;\n  color: #3880fc;\n  font-weight: bold;\n}\n.mr-20 {\n  margin-right: 20px !important;\n}\n.w100 {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LWN1c3RvbS10ZXN0L2luc3BlY3QtY3VzdG9tLXRlc3QuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtY3VzdG9tLXRlc3QvaW5zcGVjdC1jdXN0b20tdGVzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSx3QkFBQTtFQUNBLGtCQUFBO0FDQ0o7QURBSTtFQUNJLDBCQUFBO0VBQ0EsU0FBQTtBQ0VSO0FERUE7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQ0o7QURFQTtFQUNJLFVBQUE7QUNDSjtBREVBO0VBQ0ksZ0JBQUE7QUNDSjtBREVBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0NKO0FERUE7RUFDSSw2QkFBQTtBQ0NKO0FERUE7RUFDSSxXQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LWN1c3RvbS10ZXN0L2luc3BlY3QtY3VzdG9tLXRlc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBjb2xvcjogIzAwMDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1sZWZ0OiAxNXB4O1xuICAgIHAge1xuICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgIH1cbn1cblxuaW5wdXR7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2UzZTNlMztcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBvdXRsaW5lOiAwO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnctNjB7XG4gICAgd2lkdGg6IDYwJTtcbn1cblxuaW9uLWl0ZW17XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnByZXZpZXd7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGNvbG9yOiAjMzg4MGZjO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ubXItMjB7XG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi53MTAwe1xuICAgIHdpZHRoOiAxMDAlO1xufSIsIi5nbG9iYWwtaW5zcGVjdC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctbGVmdDogMTVweDtcbn1cbi5nbG9iYWwtaW5zcGVjdC10aXRsZSBwIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIG1hcmdpbjogMDtcbn1cblxuaW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZTNlM2UzO1xuICBoZWlnaHQ6IDMwcHg7XG4gIHdpZHRoOiA1MCU7XG4gIG91dGxpbmU6IDA7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udy02MCB7XG4gIHdpZHRoOiA2MCU7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnByZXZpZXcge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMzg4MGZjO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLm1yLTIwIHtcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi53MTAwIHtcbiAgd2lkdGg6IDEwMCU7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.ts":
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.ts ***!
  \*************************************************************************************************/
/*! exports provided: InspectCustomTestComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectCustomTestComponent", function() { return InspectCustomTestComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/implement-inspect.service */ "./src/app/services/implement-inspect.service.ts");




var InspectCustomTestComponent = /** @class */ (function () {
    function InspectCustomTestComponent(es, implement) {
        this.es = es;
        this.implement = implement;
        this.contract_no = '';
        this.apply_inspection_no = '';
        this.sku = '';
        this.box_type = '';
        this.onValueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this._customTestArray = [
            {
                name: '',
                pic: [],
                videos: [],
                desc: [],
            },
        ];
    }
    Object.defineProperty(InspectCustomTestComponent.prototype, "customTestArray", {
        set: function (input) {
            if (!!input) {
                this._customTestArray = input;
            }
            else {
                this._customTestArray = [
                    {
                        pic: [],
                        videos: [],
                        desc: [],
                        name: '',
                    },
                ];
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InspectCustomTestComponent.prototype, "last", {
        get: function () {
            return this._customTestArray[this._customTestArray.length - 1];
        },
        enumerable: true,
        configurable: true
    });
    InspectCustomTestComponent.prototype.ngOnInit = function () { };
    InspectCustomTestComponent.prototype.descEnter = function (e, i, b) {
        this._customTestArray.find(function (item, index) { return index == i; }).desc = e;
        this.onValueChange.emit(this._customTestArray);
    };
    InspectCustomTestComponent.prototype.addCustomTest = function () {
        if (!this.last.name) {
            this.es.showToast({
                message: '请填写完测试名在添加！',
                color: 'danger',
            });
            return;
        }
        this._customTestArray.push({
            name: '',
            pic: [],
            videos: [],
            desc: [],
        });
        console.log(this._customTestArray);
    };
    InspectCustomTestComponent.prototype.delete = function (i) {
        var _this = this;
        this.es.showAlert({
            message: '确定要删除吗？',
            buttons: [
                {
                    text: '取消',
                },
                {
                    text: '确定',
                    handler: function () {
                        var params = {
                            index: i,
                            apply_inspection_no: _this.apply_inspection_no,
                            contract_no: _this.contract_no,
                            sku: _this.sku,
                            type: 'custom_test'
                        };
                        _this.implement.deleteInspectFiled(params).subscribe(function (res) {
                            _this.es.showToast({
                                message: res.message,
                                color: res.status ? 'success' : 'danger',
                            });
                            res.status && _this._customTestArray.splice(i, 1);
                        });
                    },
                },
            ],
        });
    };
    InspectCustomTestComponent.ctorParameters = function () { return [
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_3__["ImplementInspectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Array])
    ], InspectCustomTestComponent.prototype, "customTestArray", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InspectCustomTestComponent.prototype, "contract_no", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InspectCustomTestComponent.prototype, "apply_inspection_no", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InspectCustomTestComponent.prototype, "sku", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InspectCustomTestComponent.prototype, "box_type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], InspectCustomTestComponent.prototype, "onValueChange", void 0);
    InspectCustomTestComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-inspect-custom-test',
            template: __webpack_require__(/*! raw-loader!./inspect-custom-test.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.html"),
            styles: [__webpack_require__(/*! ./inspect-custom-test.component.scss */ "./src/app/pages/implement-inspection/inspect-custom-test/inspect-custom-test.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"], src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_3__["ImplementInspectService"]])
    ], InspectCustomTestComponent);
    return InspectCustomTestComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.scss":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.scss ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".detail {\n  font-size: 14px;\n  padding: 0 15px;\n}\n\n.videos li {\n  width: 50%;\n  float: left;\n  padding: 5px;\n}\n\n.videos li video {\n  width: 100%;\n  height: 260px;\n}\n\n.images li {\n  width: 50%;\n  float: left;\n  padding: 5px;\n}\n\n.images li img {\n  width: 100%;\n  height: 260px;\n}\n\n.videos::after, .images::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LWZhY3RvcnkvZXhhbWluZS1kZXRhaWwvZXhhbWluZS1kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtZmFjdG9yeS9leGFtaW5lLWRldGFpbC9leGFtaW5lLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxlQUFBO0FDQ0o7O0FER0k7RUFDSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNBUjs7QURDUTtFQUNJLFdBQUE7RUFDQSxhQUFBO0FDQ1o7O0FES0k7RUFDSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNGUjs7QURHUTtFQUNJLFdBQUE7RUFDQSxhQUFBO0FDRFo7O0FETUE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNISiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtZmFjdG9yeS9leGFtaW5lLWRldGFpbC9leGFtaW5lLWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kZXRhaWx7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIHBhZGRpbmc6MCAxNXB4O1xufVxuXG4udmlkZW9ze1xuICAgIGxpe1xuICAgICAgICB3aWR0aDogNTAlO1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICB2aWRlb3tcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDI2MHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uaW1hZ2Vze1xuICAgIGxpe1xuICAgICAgICB3aWR0aDogNTAlO1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICBpbWd7XG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiAyNjBweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLnZpZGVvczo6YWZ0ZXIsLmltYWdlczo6YWZ0ZXJ7XG4gICAgY29udGVudDogJyc7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgY2xlYXI6IGJvdGg7XG59IiwiLmRldGFpbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgcGFkZGluZzogMCAxNXB4O1xufVxuXG4udmlkZW9zIGxpIHtcbiAgd2lkdGg6IDUwJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHBhZGRpbmc6IDVweDtcbn1cbi52aWRlb3MgbGkgdmlkZW8ge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAyNjBweDtcbn1cblxuLmltYWdlcyBsaSB7XG4gIHdpZHRoOiA1MCU7XG4gIGZsb2F0OiBsZWZ0O1xuICBwYWRkaW5nOiA1cHg7XG59XG4uaW1hZ2VzIGxpIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDI2MHB4O1xufVxuXG4udmlkZW9zOjphZnRlciwgLmltYWdlczo6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBkaXNwbGF5OiBibG9jaztcbiAgY2xlYXI6IGJvdGg7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.ts":
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.ts ***!
  \*******************************************************************************************************/
/*! exports provided: ExamineDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExamineDetailComponent", function() { return ExamineDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var ExamineDetailComponent = /** @class */ (function () {
    function ExamineDetailComponent() {
        this.env = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].usFileUrl;
        this._data = {
            video_arr: [],
            img_arr: [],
            review_summary_desc: [],
        };
    }
    Object.defineProperty(ExamineDetailComponent.prototype, "data", {
        set: function (input) {
            if (!!input)
                this._data = input;
            if (typeof input.review_summary_desc == 'string') {
                this._data.review_summary_desc = [{
                        color: '#000',
                        text: input.review_summary_desc
                    }];
            }
        },
        enumerable: true,
        configurable: true
    });
    ExamineDetailComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], ExamineDetailComponent.prototype, "data", null);
    ExamineDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-examine-detail',
            template: __webpack_require__(/*! raw-loader!./examine-detail.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.html"),
            styles: [__webpack_require__(/*! ./examine-detail.component.scss */ "./src/app/pages/implement-inspection/inspect-factory/examine-detail/examine-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ExamineDetailComponent);
    return ExamineDetailComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.scss":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.scss ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\nion-content {\n  --background: #f2f2f2;\n  color: #343434;\n  --padding-top: 15px;\n  --padding-bottom: 15px;\n  --padding-start: 15px;\n  --padding-end: 15px;\n}\nion-content .w100 {\n  width: 100%;\n}\nion-content .w80 {\n  width: 80%;\n}\nion-content .pb-10 {\n  padding-bottom: 10px !important;\n}\nion-content ion-list:first-child {\n  margin-top: 0;\n}\nion-content ion-list {\n  border-radius: 10px;\n  margin: 15px 0;\n}\nion-content ion-list ion-item .item-inner {\n  width: 100%;\n}\nion-content ion-list ion-item .item-inner label {\n  color: #848484;\n  width: 120px;\n}\nion-content ion-list ion-item .item-inner ul.img-list {\n  padding: 15px 0;\n  width: calc(100% - 120px);\n}\nion-content ion-list ion-item .item-inner > div > div {\n  width: calc(100% - 120px);\n}\nion-content ion-list ion-item .item-inner.text {\n  padding: 10px 0;\n}\nion-content ion-list ion-item label {\n  line-height: 45px;\n  font-size: 14px;\n  text-align: justify;\n  color: #2b2b2b;\n  margin-right: 10px;\n}\nion-content ion-list ion-item .form-valid {\n  text-align: right;\n  font-size: 14px;\n  color: #f00;\n  line-height: 45px;\n}\nion-content ion-list ion-item li {\n  float: left;\n}\nion-content ion-list ion-item li.image-list {\n  width: 68px;\n  height: 60px;\n  margin-right: 5px;\n  margin-bottom: 5px;\n}\nion-content ion-list ion-item li.image-list img {\n  width: 100%;\n  height: 100%;\n}\nion-content ion-list ion-item li.image-list .pos-a {\n  background: rgba(1, 1, 1, 0.5);\n  width: 30px;\n  height: 30px;\n  font-size: 30px;\n  border-radius: 100%;\n  right: -15px;\n  color: #fff;\n  top: -15px;\n}\nion-content ion-list ion-item ul:after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\nion-item:last-child {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\nion-item.no-border .item-native {\n  border: 0 !important;\n}\n.readonly {\n  border: 0;\n  background: #f2f2f2;\n  padding: 3px;\n  border-radius: 3px;\n}\n.ques {\n  margin-right: 15px;\n}\n.ques label {\n  width: auto !important;\n}\n.ques ion-select {\n  width: 50px;\n  --padding-start: 0;\n}\nion-input {\n  width: 100%;\n  font-size: 14px;\n  --color: #797979；;\n}\nion-select {\n  --color: #797979;\n}\n.next {\n  padding: 20px 0;\n}\n.next .next-btn {\n  margin: 0 auto;\n  width: 56px;\n  height: 56px;\n  color: #fff;\n  font-size: 28px;\n  text-align: center;\n  line-height: 66px;\n  border-radius: 100%;\n  background-color: #0cd1e8;\n}\n.mr-0 {\n  margin-right: 0 !important;\n}\n.small {\n  border-bottom: 1px solid #dedede;\n}\n.small label {\n  width: auto !important;\n}\n.small:last-child {\n  border: 0;\n}\n.label-right {\n  width: calc(100% - 120px);\n  padding: 10px 0 !important;\n}\nselect {\n  border: 0;\n  background: 0;\n}\nion-datetime {\n  font-size: 14px;\n}\n.must-text {\n  color: red;\n  font-size: 28px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1mYWN0b3J5L2luc3BlY3QtZmFjdG9yeS5jb21wb25lbnQuc2NzcyIsIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LWZhY3RvcnkvaW5zcGVjdC1mYWN0b3J5LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjtFQVVJLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FEUEo7QUNQSTtFQUNJLFdBQUE7QURTUjtBQ1BJO0VBQ0ksVUFBQTtBRFNSO0FDUEk7RUFDSSwrQkFBQTtBRFNSO0FDREk7RUFDSSxhQUFBO0FER1I7QUNESTtFQUNJLG1CQUFBO0VBQ0EsY0FBQTtBREdSO0FDRFk7RUFDSSxXQUFBO0FER2hCO0FDRmdCO0VBQ0ksY0FBQTtFQUNBLFlBQUE7QURJcEI7QUNGZ0I7RUFDSSxlQUFBO0VBQ0EseUJBQUE7QURJcEI7QUNBb0I7RUFDSSx5QkFBQTtBREV4QjtBQ0VZO0VBQ0ksZUFBQTtBREFoQjtBQ0VZO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QURBaEI7QUNFWTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBREFoQjtBQ0VZO0VBQ0ksV0FBQTtBREFoQjtBQ0VZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FEQWhCO0FDQ2dCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QURDcEI7QUNDZ0I7RUFDSSw4QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FEQ3BCO0FDRVk7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QURBaEI7QUNLQTtFQUNJLGlCQUFBO0VBQ0EsdUJBQUE7QURGSjtBQ01JO0VBQ0ksb0JBQUE7QURIUjtBQ09BO0VBQ0ksU0FBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FESko7QUNPQTtFQUlJLGtCQUFBO0FEUEo7QUNJSTtFQUNJLHNCQUFBO0FERlI7QUNLSTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBREhSO0FDT0E7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FESko7QUNPQTtFQUNJLGdCQUFBO0FESko7QUNNQTtFQUNJLGVBQUE7QURISjtBQ0lJO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBREZSO0FDTUE7RUFDSSwwQkFBQTtBREhKO0FDTUE7RUFDSSxnQ0FBQTtBREhKO0FDSUk7RUFDSSxzQkFBQTtBREZSO0FDTUE7RUFDSSxTQUFBO0FESEo7QUNNQTtFQUNJLHlCQUFBO0VBQ0EsMEJBQUE7QURISjtBQ01BO0VBQ0ksU0FBQTtFQUNBLGFBQUE7QURISjtBQ01BO0VBQ0UsZUFBQTtBREhGO0FDTUE7RUFDSSxVQUFBO0VBQ0EsZUFBQTtBREhKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1mYWN0b3J5L2luc3BlY3QtZmFjdG9yeS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICBjb2xvcjogIzM0MzQzNDtcbiAgLS1wYWRkaW5nLXRvcDogMTVweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMTVweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xuICAtLXBhZGRpbmctZW5kOiAxNXB4O1xufVxuaW9uLWNvbnRlbnQgLncxMDAge1xuICB3aWR0aDogMTAwJTtcbn1cbmlvbi1jb250ZW50IC53ODAge1xuICB3aWR0aDogODAlO1xufVxuaW9uLWNvbnRlbnQgLnBiLTEwIHtcbiAgcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcbn1cbmlvbi1jb250ZW50IGlvbi1saXN0OmZpcnN0LWNoaWxkIHtcbiAgbWFyZ2luLXRvcDogMDtcbn1cbmlvbi1jb250ZW50IGlvbi1saXN0IHtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luOiAxNXB4IDA7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSAuaXRlbS1pbm5lciB7XG4gIHdpZHRoOiAxMDAlO1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gLml0ZW0taW5uZXIgbGFiZWwge1xuICBjb2xvcjogIzg0ODQ4NDtcbiAgd2lkdGg6IDEyMHB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gLml0ZW0taW5uZXIgdWwuaW1nLWxpc3Qge1xuICBwYWRkaW5nOiAxNXB4IDA7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMjBweCk7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSAuaXRlbS1pbm5lciA+IGRpdiA+IGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMjBweCk7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSAuaXRlbS1pbm5lci50ZXh0IHtcbiAgcGFkZGluZzogMTBweCAwO1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gbGFiZWwge1xuICBsaW5lLWhlaWdodDogNDVweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICBjb2xvcjogIzJiMmIyYjtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gLmZvcm0tdmFsaWQge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogI2YwMDtcbiAgbGluZS1oZWlnaHQ6IDQ1cHg7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBsaSB7XG4gIGZsb2F0OiBsZWZ0O1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gbGkuaW1hZ2UtbGlzdCB7XG4gIHdpZHRoOiA2OHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBsaS5pbWFnZS1saXN0IGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG5pb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBsaS5pbWFnZS1saXN0IC5wb3MtYSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMSwgMSwgMSwgMC41KTtcbiAgd2lkdGg6IDMwcHg7XG4gIGhlaWdodDogMzBweDtcbiAgZm9udC1zaXplOiAzMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICByaWdodDogLTE1cHg7XG4gIGNvbG9yOiAjZmZmO1xuICB0b3A6IC0xNXB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0gdWw6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBkaXNwbGF5OiBibG9jaztcbiAgY2xlYXI6IGJvdGg7XG59XG5cbmlvbi1pdGVtOmxhc3QtY2hpbGQge1xuICAtLWJvcmRlci13aWR0aDogMDtcbiAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG59XG5cbmlvbi1pdGVtLm5vLWJvcmRlciAuaXRlbS1uYXRpdmUge1xuICBib3JkZXI6IDAgIWltcG9ydGFudDtcbn1cblxuLnJlYWRvbmx5IHtcbiAgYm9yZGVyOiAwO1xuICBiYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICBwYWRkaW5nOiAzcHg7XG4gIGJvcmRlci1yYWRpdXM6IDNweDtcbn1cblxuLnF1ZXMge1xuICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG59XG4ucXVlcyBsYWJlbCB7XG4gIHdpZHRoOiBhdXRvICFpbXBvcnRhbnQ7XG59XG4ucXVlcyBpb24tc2VsZWN0IHtcbiAgd2lkdGg6IDUwcHg7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbn1cblxuaW9uLWlucHV0IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgLS1jb2xvcjogIzc5Nzk3Oe+8mztcbn1cblxuaW9uLXNlbGVjdCB7XG4gIC0tY29sb3I6ICM3OTc5Nzk7XG59XG5cbi5uZXh0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuLm5leHQgLm5leHQtYnRuIHtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHdpZHRoOiA1NnB4O1xuICBoZWlnaHQ6IDU2cHg7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDI4cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGluZS1oZWlnaHQ6IDY2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICMwY2QxZTg7XG59XG5cbi5tci0wIHtcbiAgbWFyZ2luLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG5cbi5zbWFsbCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGVkZWRlO1xufVxuLnNtYWxsIGxhYmVsIHtcbiAgd2lkdGg6IGF1dG8gIWltcG9ydGFudDtcbn1cblxuLnNtYWxsOmxhc3QtY2hpbGQge1xuICBib3JkZXI6IDA7XG59XG5cbi5sYWJlbC1yaWdodCB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMjBweCk7XG4gIHBhZGRpbmc6IDEwcHggMCAhaW1wb3J0YW50O1xufVxuXG5zZWxlY3Qge1xuICBib3JkZXI6IDA7XG4gIGJhY2tncm91bmQ6IDA7XG59XG5cbmlvbi1kYXRldGltZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLm11c3QtdGV4dCB7XG4gIGNvbG9yOiByZWQ7XG4gIGZvbnQtc2l6ZTogMjhweDtcbn0iLCJpb24tY29udGVudCB7XG4gICAgLncxMDAge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICB9XG4gICAgLnc4MCB7XG4gICAgICAgIHdpZHRoOiA4MCU7XG4gICAgfVxuICAgIC5wYi0xMCB7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgICBjb2xvcjogIzM0MzQzNDtcbiAgICAtLXBhZGRpbmctdG9wOiAxNXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDE1cHg7XG4gICAgaW9uLWxpc3Q6Zmlyc3QtY2hpbGQge1xuICAgICAgICBtYXJnaW4tdG9wOiAwO1xuICAgIH1cbiAgICBpb24tbGlzdCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgIG1hcmdpbjogMTVweCAwO1xuICAgICAgICBpb24taXRlbSB7XG4gICAgICAgICAgICAuaXRlbS1pbm5lciB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzg0ODQ4NDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEyMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB1bC5pbWctbGlzdCB7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDE1cHggMDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDEyMHB4KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPiBkaXYge1xuICAgICAgICAgICAgICAgICAgICAvLyB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgPiBkaXYge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDEyMHB4KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5pdGVtLWlubmVyLnRleHQge1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxhYmVsIHtcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogNDVweDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDQzLCA0MywgNDMpO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5mb3JtLXZhbGlkIHtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmMDA7XG4gICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsaSB7XG4gICAgICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsaS5pbWFnZS1saXN0IHtcbiAgICAgICAgICAgICAgICB3aWR0aDogNjhweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5wb3MtYSB7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMSwgMSwgMSwgMC41KTtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICByaWdodDogLTE1cHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgICAgICAgICB0b3A6IC0xNXB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHVsOmFmdGVyIHtcbiAgICAgICAgICAgICAgICBjb250ZW50OiAnJztcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgICAgICBjbGVhcjogYm90aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbmlvbi1pdGVtOmxhc3QtY2hpbGQge1xuICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xufVxuXG5pb24taXRlbS5uby1ib3JkZXIge1xuICAgIC5pdGVtLW5hdGl2ZSB7XG4gICAgICAgIGJvcmRlcjogMCAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuLnJlYWRvbmx5IHtcbiAgICBib3JkZXI6IDA7XG4gICAgYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgICBwYWRkaW5nOiAzcHg7XG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG4ucXVlcyB7XG4gICAgbGFiZWwge1xuICAgICAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gICAgaW9uLXNlbGVjdCB7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgfVxufVxuXG5pb24taW5wdXQge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAtLWNvbG9yOiAjNzk3OTc577ybO1xufVxuXG5pb24tc2VsZWN0IHtcbiAgICAtLWNvbG9yOiAjNzk3OTc5O1xufVxuLm5leHQge1xuICAgIHBhZGRpbmc6IDIwcHggMDtcbiAgICAubmV4dC1idG4ge1xuICAgICAgICBtYXJnaW46IDAgYXV0bztcbiAgICAgICAgd2lkdGg6IDU2cHg7XG4gICAgICAgIGhlaWdodDogNTZweDtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBsaW5lLWhlaWdodDogNjZweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDEyLCAyMDksIDIzMik7XG4gICAgfVxufVxuXG4ubXItMCB7XG4gICAgbWFyZ2luLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG5cbi5zbWFsbCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZWRlZGU7XG4gICAgbGFiZWwge1xuICAgICAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuLnNtYWxsOmxhc3QtY2hpbGQge1xuICAgIGJvcmRlcjogMDtcbn1cblxuLmxhYmVsLXJpZ2h0IHtcbiAgICB3aWR0aDogY2FsYygxMDAlIC0gMTIwcHgpO1xuICAgIHBhZGRpbmc6IDEwcHggMCAhaW1wb3J0YW50O1xufVxuXG5zZWxlY3Qge1xuICAgIGJvcmRlcjogMDtcbiAgICBiYWNrZ3JvdW5kOiAwO1xufVxuXG5pb24tZGF0ZXRpbWV7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLm11c3QtdGV4dHtcbiAgICBjb2xvcjogcmVkO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: InspectFactoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectFactoryComponent", function() { return InspectFactoryComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/implement-inspect.service */ "./src/app/services/implement-inspect.service.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");












var InspectFactoryComponent = /** @class */ (function () {
    function InspectFactoryComponent(fb, ec, camera, router, ac, storage, implementInspect, uQueue) {
        this.fb = fb;
        this.ec = ec;
        this.camera = camera;
        this.router = router;
        this.ac = ac;
        this.storage = storage;
        this.implementInspect = implementInspect;
        this.uQueue = uQueue;
        this.imageReady = {
            environments: false,
            sampleRoom: false,
            factoryOther: false,
        };
        this.imgOrigin = src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].usFileUrl;
        this.start_time = String(new Date('').getTime());
        this.data = {
            factory_name: '',
            factory_contacts: '',
        };
        this.factoryModel = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            environments: this.fb.array([]),
            sampleRoom: this.fb.array([]),
            factoryOther: this.fb.array([]),
            factoryAddress: this.fb.group({
                text: this.fb.control(this.data.factoryAddress),
                isTrue: this.fb.control('1'),
            }),
            worksNum: this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            receptionist: this.fb.group({
                name: this.fb.control(this.data.factory_contacts),
                post: this.fb.control(''),
                tel: this.fb.control(''),
                isTrue: this.fb.control('1'),
            }),
            equipment: this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            trulyInspectionDate: this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]),
            remarks: this.fb.array(['']),
        });
        this.options = {
            quality: 100,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE,
        };
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
    }
    Object.defineProperty(InspectFactoryComponent.prototype, "environments", {
        get: function () {
            return this.factoryModel.get('environments');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InspectFactoryComponent.prototype, "sampleRoom", {
        get: function () {
            return this.factoryModel.get('sampleRoom');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InspectFactoryComponent.prototype, "factoryOther", {
        get: function () {
            return this.factoryModel.get('factoryOther');
        },
        enumerable: true,
        configurable: true
    });
    InspectFactoryComponent.prototype.getListByTime = function () { };
    InspectFactoryComponent.prototype.regValid = function (e) {
        if (!/^(?!0+(?:\0+)?$)(?:[1-9]\d*|0)(?:\\d{1,2})?$/.test(e.detail.value)) {
            e.target.value = null;
        }
    };
    InspectFactoryComponent.prototype.ngOnInit = function () {
        var _this = this;
        var IMPLEMENT_META_DATA = this.storage.get('IMPLEMENT-INSPECTION-META-DATA');
        this.ac.params.subscribe(function (res) {
            _this.apply_inspect_no = res.fid;
            _this.inspection_group_id = res.apply_group_id;
            IMPLEMENT_META_DATA.forEach(function (elem) {
                elem.sku_data.forEach(function (element) {
                    if (element.apply_inspection_no == res.fid) {
                        _this.data = elem;
                        _this.currentApplyInsData = _this.data.sku_data.find(function (res) { return res.apply_inspection_no == _this.apply_inspect_no; });
                    }
                });
            });
        });
        this.getData();
    };
    InspectFactoryComponent.prototype.setPhoto = function (e, type) {
        if (e && e.length) {
            this.factoryModel.get(type).clear();
            for (var i = 0; i < e.length; i++) {
                this.factoryModel.get(type).push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
            }
        }
        else {
            this.factoryModel.get(type).clear();
        }
        this.factoryModel.get(type).setValue(e);
    };
    InspectFactoryComponent.prototype.remove = function (type, i) {
        this[type].controls.splice(i, 1);
    };
    InspectFactoryComponent.prototype.addRemarks = function () {
        this.factoryModel.get('remarks').push(this.fb.control(''));
        console.log(this.factoryModel.get('remarks'));
    };
    InspectFactoryComponent.prototype.showModal = function () {
        this.ec.showModal({
            component: _queue_queue_component__WEBPACK_IMPORTED_MODULE_9__["QueueComponent"],
        });
        this.uQueue.alreadyUpProgress = true;
    };
    InspectFactoryComponent.prototype.getData = function () {
        var _this = this;
        this.implementInspect.getInspectData(this.apply_inspect_no, this.inspection_group_id).subscribe(function (res) {
            _this.examineDetail = res.review_content;
            _this.review_status = res.review_status;
            if ((res.factory_data.environments && res.factory_data.environments.length) ||
                (res.factory_data.sampleRoom && res.factory_data.sampleRoom.length) ||
                (res.factory_data.factoryOther && res.factory_data.factoryOther.length)) {
                _this.ec.showLoad({
                    message: '加载中……',
                    backdropDismiss: false,
                });
            }
            if (res.factory_data.remarks) {
                res.factory_data.remarks.forEach(function (element, i) {
                    element && _this.factoryModel.get('remarks').push(_this.fb.control(''));
                });
            }
            _this.factoryModel.patchValue({
                factoryAddress: {
                    text: res.factory_data.factoryAddress.text,
                    isTrue: res.factory_data.factoryAddress.isTrue,
                },
                worksNum: res.factory_data.worksNum,
                receptionist: {
                    name: res.factory_data.receptionist.name,
                    post: res.factory_data.receptionist.post,
                    tel: res.factory_data.receptionist.tel,
                    isTrue: res.factory_data.receptionist.isTrue,
                },
                trulyInspectionDate: res.factory_data.trulyInspectionDate,
                equipment: res.factory_data.equipment,
                remarks: res.factory_data.remarks ? res.factory_data.remarks : [],
            });
            setTimeout(function () {
                if (res.factory_data.environments && res.factory_data.environments.length) {
                    for (var i = 0; i < res.factory_data.environments.length; i++) {
                        _this.factoryModel.get('environments').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
                    }
                    _this.factoryModel.get('environments').setValue(res.factory_data.environments);
                }
                if (res.factory_data.sampleRoom && res.factory_data.sampleRoom.length) {
                    // tslint:disable-next-line: prefer-for-of
                    for (var i = 0; i < res.factory_data.sampleRoom.length; i++) {
                        _this.factoryModel.get('sampleRoom').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
                    }
                    _this.factoryModel.get('sampleRoom').setValue(res.factory_data.sampleRoom);
                }
                if (res.factory_data.factoryOther && res.factory_data.factoryOther.length) {
                    // tslint:disable-next-line: prefer-for-of
                    for (var i = 0; i < res.factory_data.factoryOther.length; i++) {
                        _this.factoryModel.get('factoryOther').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
                    }
                    _this.factoryModel.get('factoryOther').setValue(res.factory_data.factoryOther);
                }
                _this.imageReady.environments = _this.imageReady.sampleRoom = _this.imageReady.factoryOther = true;
                _this.imageSetReady();
            }, 2000);
        });
    };
    InspectFactoryComponent.prototype.imageSetReady = function () {
        if (this.imageReady.environments && this.imageReady.sampleRoom && this.imageReady.factoryOther) {
            this.ec.clearEffectCtrl();
        }
    };
    InspectFactoryComponent.prototype.toInspectPo = function () {
        var _this = this;
        if (!this.factoryModel.valid) {
            this.ec.showToast({
                message: '请输入必选项',
                color: 'danger',
            });
            return;
        }
        this.ec.showLoad({
            message: ' 正在上传 ',
            backdropDismiss: false,
        });
        this.implementInspect
            .inspectFactory({
            factory_data: this.factoryModel.value,
            apply_inspection_no: this.apply_inspect_no,
            inspection_group_id: this.inspection_group_id,
        })
            .subscribe(function (res) {
            _this.ec.showToast({
                message: res.message,
                position: 'top',
                color: res.status == 1 ? 'success' : 'danger',
            });
            if (res.status === 1) {
                setTimeout(function () {
                    _this.router.navigate(['inspect-po', _this.apply_inspect_no]);
                }, 1000);
            }
        });
    };
    InspectFactoryComponent.prototype.descEnter = function (p) {
        this.factoryModel.get('remarks').clear();
        for (var i = 0; i < p.length; i++) {
            this.factoryModel.get('remarks').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](''));
        }
        this.factoryModel.get('remarks').setValue(p);
        console.log(this.factoryModel.value);
    };
    InspectFactoryComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] },
        { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] },
        { type: src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__["ImplementInspectService"] },
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_10__["UploadQueueService"] }
    ]; };
    InspectFactoryComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-inspect-factory',
            template: __webpack_require__(/*! raw-loader!./inspect-factory.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.html"),
            styles: [__webpack_require__(/*! ./inspect-factory.component.scss */ "./src/app/pages/implement-inspection/inspect-factory/inspect-factory.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"],
            src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__["ImplementInspectService"],
            _upload_queue_service__WEBPACK_IMPORTED_MODULE_10__["UploadQueueService"]])
    ], InspectFactoryComponent);
    return InspectFactoryComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.scss":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #f2f2f2;\n  --padding-top: 15px;\n  --padding-bottom: 15px;\n  --padding-start: 10px;\n  --padding-end: 10px;\n}\nion-content .out-box {\n  padding: 5px;\n}\n.global-inspect-title {\n  font-size: 14px;\n  color: #3880fc;\n  font-weight: bold;\n  margin: 5px 0 !important;\n}\n.global-inspect-title p {\n  margin: 0;\n}\n.desc-box {\n  width: 100%;\n  padding-bottom: 10px;\n}\nion-item:last-child {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\n.label {\n  color: #434343;\n}\nion-input,\ninput {\n  height: 30px;\n  margin-right: 40px;\n  border: 1px solid #e3e3e3;\n  width: 100px;\n  font-size: 14px;\n  text-align: center;\n  border-radius: 5px;\n  --padding-top: 5px;\n  --padding-bottom: 5px;\n}\nion-list {\n  margin: 10px 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LXBhcnRzL2luc3BlY3QtcGFydHMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtcGFydHMvaW5zcGVjdC1wYXJ0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUNDSjtBREFJO0VBQ0ksWUFBQTtBQ0VSO0FER0E7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUNBSjtBRENJO0VBQ0ksU0FBQTtBQ0NSO0FER0E7RUFDSSxXQUFBO0VBQ0Esb0JBQUE7QUNBSjtBREdBO0VBQ0ksaUJBQUE7RUFDQSx1QkFBQTtBQ0FKO0FER0E7RUFDSSxjQUFBO0FDQUo7QURHQTs7RUFFSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNBSjtBREdBO0VBQ0ksY0FBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1wYXJ0cy9pbnNwZWN0LXBhcnRzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgICAtLXBhZGRpbmctdG9wOiAxNXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gICAgLm91dC1ib3gge1xuICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgfVxufVxuIFxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBjb2xvcjogIzM4ODBmYztcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG4gICAgcCB7XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICB9XG59XG5cbi5kZXNjLWJveCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1pdGVtOmxhc3QtY2hpbGQge1xuICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xufVxuXG4ubGFiZWwge1xuICAgIGNvbG9yOiAjNDM0MzQzO1xufVxuXG5pb24taW5wdXQsXG5pbnB1dCB7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIG1hcmdpbi1yaWdodDogNDBweDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTNlM2UzO1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAtLXBhZGRpbmctdG9wOiA1cHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG5pb24tbGlzdCB7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG4gIC0tcGFkZGluZy10b3A6IDE1cHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbn1cbmlvbi1jb250ZW50IC5vdXQtYm94IHtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMzg4MGZjO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiA1cHggMCAhaW1wb3J0YW50O1xufVxuLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHAge1xuICBtYXJnaW46IDA7XG59XG5cbi5kZXNjLWJveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWl0ZW06bGFzdC1jaGlsZCB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcbn1cblxuLmxhYmVsIHtcbiAgY29sb3I6ICM0MzQzNDM7XG59XG5cbmlvbi1pbnB1dCxcbmlucHV0IHtcbiAgaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDQwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XG4gIHdpZHRoOiAxMDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgLS1wYWRkaW5nLXRvcDogNXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbmlvbi1saXN0IHtcbiAgbWFyZ2luOiAxMHB4IDA7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.ts ***!
  \*************************************************************************************/
/*! exports provided: InspectPartsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectPartsComponent", function() { return InspectPartsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");





var InspectPartsComponent = /** @class */ (function () {
    function InspectPartsComponent(uQueue, es) {
        this.uQueue = uQueue;
        this.es = es;
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
    }
    InspectPartsComponent.prototype.showModal = function () {
        this.es.showModal({
            component: _queue_queue_component__WEBPACK_IMPORTED_MODULE_4__["QueueComponent"],
        });
        this.uQueue.alreadyUpProgress = true;
    };
    InspectPartsComponent.prototype.ngOnInit = function () { };
    InspectPartsComponent.prototype.descEnter = function (e, type, boxType) {
    };
    InspectPartsComponent.ctorParameters = function () { return [
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_2__["UploadQueueService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"] }
    ]; };
    InspectPartsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-inspect-parts',
            template: __webpack_require__(/*! raw-loader!./inspect-parts.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.html"),
            styles: [__webpack_require__(/*! ./inspect-parts.component.scss */ "./src/app/pages/implement-inspection/inspect-parts/inspect-parts.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_upload_queue_service__WEBPACK_IMPORTED_MODULE_2__["UploadQueueService"], src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_3__["PageEffectService"]])
    ], InspectPartsComponent);
    return InspectPartsComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-po/inspect-po.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-po/inspect-po.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #f2f2f2;\n  font-size: 14px;\n}\nion-content .po-list {\n  padding: 15px;\n}\nion-content .po-list .po h4,\nion-content .po-list .po label {\n  font-weight: bold;\n  font-size: 14px;\n}\nion-content .wd-100 {\n  width: 100%;\n}\nion-content ion-list {\n  background: transparent;\n}\nion-content ion-list ion-item {\n  margin-bottom: 15px;\n  border-radius: 10px;\n}\nion-content .sku-list {\n  color: #333333;\n  padding: 10px;\n  font-size: 14px;\n}\nion-content .sku-list h4 {\n  font-size: 14px;\n}\nion-content .sku-list > li {\n  padding-bottom: 15px;\n}\nion-content .sku-list > li img.head {\n  width: 50px;\n  box-sizing: border-box;\n  border-radius: 5px;\n  border: 2px solid #ccc;\n  height: 50px;\n  display: block;\n}\nion-content .sku-list > li {\n  margin-bottom: 15px;\n  border-bottom: 1px solid #e6e6e6;\n}\nion-content .sku-list > li:last-child {\n  margin-bottom: 0;\n  border-bottom: 0;\n}\nion-content .sku-list .span-box {\n  margin-left: 15px;\n  margin-top: 5px;\n}\nion-content .sku-list .span-box span:first-child {\n  margin-bottom: 5px;\n}\nion-content .input-item {\n  margin-left: 50px;\n}\nion-content .input-item > div {\n  margin-left: 15px;\n}\n.label {\n  color: #848484;\n}\nion-input {\n  border: 1px solid #e3e3e3;\n  width: 60px;\n  text-align: center;\n  border-radius: 5px;\n  --padding-top: 5px;\n  --padding-bottom: 5px;\n  margin: 0 10px;\n}\n.add-img {\n  margin-left: 65px;\n  margin-top: 10px;\n}\n.lh-10 {\n  line-height: 0px;\n}\n.add-img > li {\n  float: left;\n  margin-right: 10px;\n}\n.add-img .image {\n  width: 50px;\n  height: 50px;\n}\n.add-img .image img {\n  width: 100%;\n  height: 100%;\n  display: block;\n}\n.add-img::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\nion-item {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\n.mt-5 {\n  margin-top: 5px;\n}\nselect {\n  background: 0;\n  border: 0;\n}\n.f-r {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LXBvL2luc3BlY3QtcG8uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtcG8vaW5zcGVjdC1wby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0VBQ0EsZUFBQTtBQ0NKO0FEQUk7RUFDSSxhQUFBO0FDRVI7QURBWTs7RUFFSSxpQkFBQTtFQUNBLGVBQUE7QUNFaEI7QURFSTtFQUNJLFdBQUE7QUNBUjtBREdJO0VBQ0ksdUJBQUE7QUNEUjtBREVRO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtBQ0FaO0FER0k7RUFDSSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUNEUjtBREVRO0VBQ0ksZUFBQTtBQ0FaO0FERVE7RUFDSSxvQkFBQTtBQ0FaO0FEQ1k7RUFDSSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUNDaEI7QURFUTtFQUNJLG1CQUFBO0VBQ0EsZ0NBQUE7QUNBWjtBREVRO0VBQ0ksZ0JBQUE7RUFDQSxnQkFBQTtBQ0FaO0FERVE7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUNBWjtBRENZO0VBQ0ksa0JBQUE7QUNDaEI7QURHSTtFQUNJLGlCQUFBO0FDRFI7QURFUTtFQUNJLGlCQUFBO0FDQVo7QURLQTtFQUNJLGNBQUE7QUNGSjtBREtBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FDRko7QURLQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNGSjtBREtBO0VBQ0ksZ0JBQUE7QUNGSjtBRE1JO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0FDSFI7QURNSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDSlI7QURLUTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQ0haO0FET0E7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNKSjtBRE9BO0VBQ0ksaUJBQUE7RUFDQSx1QkFBQTtBQ0pKO0FET0E7RUFDRSxlQUFBO0FDSkY7QURPQTtFQUNFLGFBQUE7RUFDQSxTQUFBO0FDSkY7QURPQTtFQUNJLFlBQUE7QUNKSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL2luc3BlY3QtcG8vaW5zcGVjdC1wby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIC5wby1saXN0IHtcbiAgICAgICAgcGFkZGluZzogMTVweDtcbiAgICAgICAgLnBvIHtcbiAgICAgICAgICAgIGg0LFxuICAgICAgICAgICAgbGFiZWwge1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAud2QtMTAwIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxuXG4gICAgaW9uLWxpc3Qge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgaW9uLWl0ZW0ge1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLnNrdS1saXN0IHtcbiAgICAgICAgY29sb3I6ICMzMzMzMzM7XG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgaDQge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICB9XG4gICAgICAgID4gbGkge1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDE1cHg7XG4gICAgICAgICAgICBpbWcuaGVhZCB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgI2NjYztcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgPiBsaSB7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlNmU2ZTY7XG4gICAgICAgIH1cbiAgICAgICAgPiBsaTpsYXN0LWNoaWxkIHtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAwO1xuICAgICAgICB9XG4gICAgICAgIC5zcGFuLWJveCB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgICAgIHNwYW46Zmlyc3QtY2hpbGQge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAuaW5wdXQtaXRlbSB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xuICAgICAgICA+IGRpdiB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmxhYmVsIHtcbiAgICBjb2xvcjogIzg0ODQ4NDtcbn1cblxuaW9uLWlucHV0IHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTNlM2UzO1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgLS1wYWRkaW5nLXRvcDogNXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDVweDtcbiAgICBtYXJnaW46IDAgMTBweDtcbn1cblxuLmFkZC1pbWcge1xuICAgIG1hcmdpbi1sZWZ0OiA2NXB4O1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5saC0xMCB7XG4gICAgbGluZS1oZWlnaHQ6IDBweDtcbn1cblxuLmFkZC1pbWcge1xuICAgID4gbGkge1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIH1cblxuICAgIC5pbWFnZSB7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIGltZyB7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICB9XG4gICAgfVxufVxuLmFkZC1pbWc6OmFmdGVyIHtcbiAgICBjb250ZW50OiAnJztcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjbGVhcjogYm90aDtcbn1cblxuaW9uLWl0ZW0ge1xuICAgIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAgIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xufVxuXG4ubXQtNXtcbiAgbWFyZ2luLXRvcDo1cHhcbn1cblxuc2VsZWN0e1xuICBiYWNrZ3JvdW5kOiAwO1xuICBib3JkZXI6IDA7XG59XG5cbi5mLXJ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5pb24tY29udGVudCAucG8tbGlzdCB7XG4gIHBhZGRpbmc6IDE1cHg7XG59XG5pb24tY29udGVudCAucG8tbGlzdCAucG8gaDQsXG5pb24tY29udGVudCAucG8tbGlzdCAucG8gbGFiZWwge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuaW9uLWNvbnRlbnQgLndkLTEwMCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuaW9uLWNvbnRlbnQgaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1jb250ZW50IC5za3UtbGlzdCB7XG4gIGNvbG9yOiAjMzMzMzMzO1xuICBwYWRkaW5nOiAxMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5pb24tY29udGVudCAuc2t1LWxpc3QgaDQge1xuICBmb250LXNpemU6IDE0cHg7XG59XG5pb24tY29udGVudCAuc2t1LWxpc3QgPiBsaSB7XG4gIHBhZGRpbmctYm90dG9tOiAxNXB4O1xufVxuaW9uLWNvbnRlbnQgLnNrdS1saXN0ID4gbGkgaW1nLmhlYWQge1xuICB3aWR0aDogNTBweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBib3JkZXI6IDJweCBzb2xpZCAjY2NjO1xuICBoZWlnaHQ6IDUwcHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuaW9uLWNvbnRlbnQgLnNrdS1saXN0ID4gbGkge1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U2ZTZlNjtcbn1cbmlvbi1jb250ZW50IC5za3UtbGlzdCA+IGxpOmxhc3QtY2hpbGQge1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICBib3JkZXItYm90dG9tOiAwO1xufVxuaW9uLWNvbnRlbnQgLnNrdS1saXN0IC5zcGFuLWJveCB7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG5pb24tY29udGVudCAuc2t1LWxpc3QgLnNwYW4tYm94IHNwYW46Zmlyc3QtY2hpbGQge1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5pb24tY29udGVudCAuaW5wdXQtaXRlbSB7XG4gIG1hcmdpbi1sZWZ0OiA1MHB4O1xufVxuaW9uLWNvbnRlbnQgLmlucHV0LWl0ZW0gPiBkaXYge1xuICBtYXJnaW4tbGVmdDogMTVweDtcbn1cblxuLmxhYmVsIHtcbiAgY29sb3I6ICM4NDg0ODQ7XG59XG5cbmlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XG4gIHdpZHRoOiA2MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgLS1wYWRkaW5nLXRvcDogNXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiA1cHg7XG4gIG1hcmdpbjogMCAxMHB4O1xufVxuXG4uYWRkLWltZyB7XG4gIG1hcmdpbi1sZWZ0OiA2NXB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4ubGgtMTAge1xuICBsaW5lLWhlaWdodDogMHB4O1xufVxuXG4uYWRkLWltZyA+IGxpIHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5hZGQtaW1nIC5pbWFnZSB7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG59XG4uYWRkLWltZyAuaW1hZ2UgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5hZGQtaW1nOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjbGVhcjogYm90aDtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJvcmRlci13aWR0aDogMDtcbiAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XG59XG5cbi5tdC01IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG5zZWxlY3Qge1xuICBiYWNrZ3JvdW5kOiAwO1xuICBib3JkZXI6IDA7XG59XG5cbi5mLXIge1xuICBmbG9hdDogcmlnaHQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-po/inspect-po.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-po/inspect-po.component.ts ***!
  \*******************************************************************************/
/*! exports provided: InspectPoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectPoComponent", function() { return InspectPoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/implement-inspect.service */ "./src/app/services/implement-inspect.service.ts");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");
/* harmony import */ var _rework_inspect_feedback_feedback_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../rework-inspect/feedback/feedback.component */ "./src/app/pages/rework-inspect/feedback/feedback.component.ts");











var InspectPoComponent = /** @class */ (function () {
    function InspectPoComponent(storage, activeRouter, camera, ec, implementInspect, router, uQueue, es) {
        this.storage = storage;
        this.activeRouter = activeRouter;
        this.camera = camera;
        this.ec = ec;
        this.implementInspect = implementInspect;
        this.router = router;
        this.uQueue = uQueue;
        this.es = es;
        this.imgOrigin = src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].fileUrlPath;
        this.metaData = this.storage.get('IMPLEMENT-INSPECTION-META-DATA');
        this.currentSku = null;
        this.apply_inspect_no = '';
        this.data = {
            contract: {
                manufacturer: '',
            },
        };
        this.options = {
            quality: 100,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE,
        };
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
    }
    InspectPoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activeRouter.params.subscribe(function (params) {
            _this.apply_inspect_no = params.fid;
            _this.metaData.forEach(function (elem) {
                elem.sku_data.forEach(function (element) {
                    if (element.apply_inspection_no == params.fid) {
                        _this.data = elem;
                        _this.currentApplyInsData = _this.data.sku_data.find(function (res) { return res.apply_inspection_no == _this.apply_inspect_no; });
                        _this.storage.set('currentApplyInsData', _this.currentApplyInsData);
                    }
                });
            });
            _this.implementInspect.getInspectData(_this.apply_inspect_no).subscribe(function (res) {
                _this.data.sku_data.forEach(function (element) {
                    element.contract_data.forEach(function (item) {
                        if (res.contract_data) {
                            res.contract_data.forEach(function (sItem) {
                                if (item.contract_no == sItem.contract_no) {
                                    item.inspection_complete_no = sItem.sku_package_complete_num_total;
                                    item.inspection_complete_num = sItem.inspection_complete_num;
                                    item.data.forEach(function (sku) {
                                        sItem.contract_sku_desc.forEach(function (element) {
                                            if (sku.sku === element.sku) {
                                                sku.sku_package_complete_num = element.sku_package_complete_num;
                                                sku.sku_production_complete_num = element.sku_production_complete_num;
                                                sku.rate_res = element.rate_res;
                                                sku.made_in_china_res = element.made_in_china_res;
                                                sku.implement_photo = element.pic;
                                                sku.desc = element.desc;
                                            }
                                        });
                                    });
                                }
                            });
                        }
                    });
                });
            });
        });
    };
    InspectPoComponent.prototype.showModal = function () {
        this.ec.showModal({
            component: _queue_queue_component__WEBPACK_IMPORTED_MODULE_8__["QueueComponent"],
        });
        this.uQueue.alreadyUpProgress = true;
    };
    InspectPoComponent.prototype.photograph = function (p) {
        var _this = this;
        this.camera.getPicture(this.options).then(function (imageData) {
            if (!p.photo) {
                p.photo = [];
            }
            var base64Image = 'data:image/jpeg;base64,' + imageData;
            p.photo.push(base64Image);
        }, function (err) {
            _this.ec.showToast({
                message: '请重新拍照',
                color: 'danger',
            });
        });
    };
    InspectPoComponent.prototype.regValid = function (e) {
        if (!/^(?!0+(?:\0+)?$)(?:[1-9]\d*|0)(?:\\d{1,2})?$/.test(e.detail.value)) {
            e.target.value = null;
        }
    };
    InspectPoComponent.prototype.calcMust = function (e, n, p) {
        if (e.detail.value > n.quantity) {
            n[p] = null;
            this.ec.showToast({
                message: '不能大于申请验货数量',
                color: 'danger',
            });
        }
    };
    InspectPoComponent.prototype.copy = function (p, sku) {
        var _this = this;
        var params = {
            apply_inspection_no: this.apply_inspect_no,
            sku: sku.sku,
            contract_no: p.contract_no,
        };
        this.implementInspect.copySku(params).subscribe(function (res) {
            console.log(res);
            _this.ec.showToast({
                message: res.message,
                color: 'success',
            });
        });
    };
    InspectPoComponent.prototype.toInspectSku = function (p, sku, type) {
        var _this = this;
        if (sku.is_appraise) {
            this.es.showToast({
                message: '已评价不能验货！',
                color: 'danger'
            });
            return;
        }
        this.currentSku = this.currentApplyInsData.data.find(function (res) { return res.sku === sku.sku; });
        if (this.verifyIpt(p, sku)) {
            var param = {
                apply_inspection_no: this.apply_inspect_no,
                contract_data: {
                    inspection_complete_no: p.inspection_complete_no,
                    contract_no: p.contract_no,
                    contract_sku_desc: {
                        sku_package_complete_num: sku.sku_package_complete_num,
                        photo: sku.photo,
                        sku: sku.sku,
                        sku_production_complete_num: sku.sku_production_complete_num,
                        rate_res: sku.rate_res,
                        made_in_china_res: sku.made_in_china_res,
                        desc: sku.desc,
                    },
                },
            };
            this.implementInspect.inspectFactory(param).subscribe(function (res) {
                _this.ec.showToast({
                    message: res.message,
                    position: 'top',
                    color: res.status === 1 ? 'success' : 'danger',
                });
                if (res.status && type == 'go') {
                    _this.storage.set('CURRENT_IMPLEMENT_SKU', _this.currentSku);
                    _this.storage.set('CURRENT_FACTORY_DATA', _this.data);
                    setTimeout(function () {
                        _this.router.navigate(['/inspect-sku', p.contract_no]);
                    }, 1000);
                }
            });
        }
    };
    InspectPoComponent.prototype.descEnter = function (e, sku) {
        sku.desc = [];
        sku.desc = sku.desc.concat(e);
        console.log(sku);
    };
    InspectPoComponent.prototype.verifyIpt = function (p, sku) {
        var val = true;
        // if (!sku.sku_package_complete_num) {
        //     this.ec.showToast({
        //         message: '请输入sku验货数量',
        //         color: 'danger',
        //     });
        //     val = false;
        // } else if (!sku.sku_production_complete_num) {
        //     this.ec.showToast({
        //         message: '请输入sku生产完成数量',
        //         color: 'danger',
        //     });
        //     val = false;
        // } else if (!sku.photo) {
        // }
        return val;
    };
    InspectPoComponent.prototype.calcContractNum = function (p, e) {
        p.inspection_complete_no = p.inspection_complete_no = 0;
        p.data.forEach(function (element) {
            p.inspection_complete_num += element.sku_package_complete_num ? element.sku_package_complete_num : 0;
            p.inspection_complete_no += element.sku_package_complete_num ? element.sku_package_complete_num : 0;
        });
    };
    InspectPoComponent.prototype.feedback = function (p, sku) {
        this.es.showModal({
            component: _rework_inspect_feedback_feedback_component__WEBPACK_IMPORTED_MODULE_10__["FeedbackComponent"],
            componentProps: { apply_inspection_no: this.apply_inspect_no, sku: sku.sku, contract_no: p.contract_no },
        });
    };
    InspectPoComponent.ctorParameters = function () { return [
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
        { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
        { type: src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__["ImplementInspectService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_9__["UploadQueueService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    InspectPoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-inspect-po',
            template: __webpack_require__(/*! raw-loader!./inspect-po.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-po/inspect-po.component.html"),
            styles: [__webpack_require__(/*! ./inspect-po.component.scss */ "./src/app/pages/implement-inspection/inspect-po/inspect-po.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
            src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_7__["ImplementInspectService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _upload_queue_service__WEBPACK_IMPORTED_MODULE_9__["UploadQueueService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], InspectPoComponent);
    return InspectPoComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: #f2f2f2;\n  --padding-top: 15px;\n  --padding-bottom: 15px;\n  --padding-start: 10px;\n  --padding-end: 10px;\n}\nion-content .out-box {\n  padding: 5px;\n}\n.tops {\n  font-size: 12px;\n}\n.tops select {\n  margin-left: 15px;\n  margin-right: 15px;\n  color: #fff;\n  background: none;\n  border: 0;\n}\n.inspect-basic-style {\n  margin: 10px 0;\n  background: #fff;\n}\nion-list {\n  margin: 10px 0;\n}\n.w30 {\n  width: 30% !important;\n}\n.border-0 {\n  border: 0 !important;\n}\n.header-input {\n  font-size: 14px;\n}\n.header-input ion-input {\n  margin-left: 4px;\n  border: 1px solid #e3e3e3;\n  width: 80px;\n  text-align: center;\n  border-radius: 5px;\n  --padding-top: 5px;\n  --padding-bottom: 5px;\n}\n.header-input:last-child ion-input {\n  width: 120px;\n}\nion-item:last-child {\n  --border-width: 0;\n  --inner-border-width: 0;\n}\n.label {\n  color: #434343;\n}\n.global-inspect-title {\n  font-size: 14px;\n  color: #3880fc;\n  font-weight: bold;\n  margin: 5px 0 !important;\n}\n.global-inspect-title p {\n  margin: 0;\n}\n.gray-color {\n  color: #a2a2a2;\n}\n.w100 {\n  width: 100% !important;\n}\n.global-inspect-title + div {\n  margin-top: 10px;\n}\n.h-30 {\n  height: 30px;\n}\nion-input,\ninput {\n  height: 30px;\n  margin-right: 40px;\n  border: 1px solid #e3e3e3;\n  width: 100px;\n  font-size: 14px;\n  text-align: center;\n  border-radius: 5px;\n  --padding-top: 5px;\n  --padding-bottom: 5px;\n}\n.size {\n  margin-top: 10px;\n}\n.bar-code {\n  margin-bottom: 10px;\n}\n.bar-code input {\n  width: 150px;\n}\n.maozhong ion-input {\n  width: 100px;\n}\n.packing-info {\n  margin-bottom: 10px;\n  width: 100%;\n  font-size: 12px;\n  color: #a5a5a5;\n  background: #ededed;\n  border-radius: 6px;\n  padding: 8px;\n  text-align: justify;\n  text-indent: 2rem;\n  line-height: 18px;\n}\np.desc-tips {\n  margin: 0 !important;\n}\n.select {\n  color: #434343;\n  background: none;\n  font-size: 14px;\n  border: 0;\n}\n.test-feedback {\n  margin-bottom: 10px;\n}\n.toggle-box {\n  padding: 0.5rem;\n  position: -webkit-sticky;\n  position: sticky;\n  top: -22px;\n  z-index: 999;\n}\n.toggle-box ion-segment {\n  background: #fff;\n}\n.label-item {\n  background: #f7f7f7;\n  font-size: 14px;\n  padding: 0.3rem;\n}\n.label-item ion-grid {\n  background: #fff;\n  padding: 0;\n}\n.label-item ion-grid ion-col:first-child {\n  border-right: 1px solid #f0f0f0;\n}\n.label-item ion-grid ion-col {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n}\n.desc-box {\n  width: 100%;\n  padding-bottom: 10px;\n}\n.size-grid {\n  font-size: 12px;\n  border: 1px solid #f0f0f0;\n}\n.size-grid ion-row {\n  border-bottom: 1px solid #f0f0f0;\n}\n.w-100 {\n  width: 100% !important;\n}\n.w180 {\n  width: 180px !important;\n}\n.ml-10 {\n  margin-left: 10px !important;\n}\n.pb-10 {\n  padding-bottom: 10px !important;\n}\n.inspection_require {\n  background: #fff;\n}\n.inspection_require,\n.sku-desc {\n  padding: 0;\n  margin-top: 10px;\n}\n.inspection_require ion-row,\n.sku-desc ion-row {\n  border-top: 1px solid #f0f0f0;\n  border-left: 1px solid #f0f0f0;\n}\n.inspection_require ion-col,\n.sku-desc ion-col {\n  color: #323232;\n  font-size: 14px;\n  border-right: 1px solid #f0f0f0;\n}\n.inspection_require ion-col.content,\n.sku-desc ion-col.content {\n  color: #5e5e5e;\n}\n.ml-15 {\n  margin-left: 15px !important;\n}\nion-item:not(:first-child) .global-inspect-title {\n  margin-top: 10px !important;\n}\n.w150 {\n  width: 150px !important;\n}\n.mt-10 {\n  margin-top: 10px !important;\n}\n.mf {\n  font-size: 14px;\n  margin-right: 5px;\n}\n.schedule-container {\n  box-sizing: border-box;\n  width: 100%;\n}\n.mt-10 {\n  margin-top: 10px !important;\n}\n.schedule-item {\n  width: 50%;\n  float: left;\n  box-sizing: border-box;\n  color: #434343;\n  display: flex;\n  font-size: 12px;\n  border-bottom: 1px solid #efefef;\n  justify-content: space-between;\n  padding: 6px 0;\n}\n.schedule-item ion-label {\n  font-size: 14px;\n  color: #434343;\n}\n.schedule-item select,\n.schedule-item option {\n  background: 0;\n  border: 0;\n  color: #434343;\n  font-size: 14px;\n}\n.schedule-container:after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n.accord-box {\n  border: 1px solid #f00;\n}\n.fs-14 {\n  font-size: 14px !important;\n}\n.mt-20 {\n  margin-top: 20px !important;\n}\napp-queue {\n  background: white;\n}\nul.segment {\n  width: 100%;\n  border: 1px solid #2c6aff;\n  height: 24px;\n  color: #2c6aff;\n  border-radius: 4px;\n  overflow: hidden;\n}\nul.segment li {\n  cursor: pointer;\n  text-align: center;\n  line-height: 24px;\n  width: 33.33%;\n  float: left;\n  font-size: 13px;\n  background: #fff;\n  border-right: 1px solid #2c6aff;\n}\nul.segment li:last-child {\n  border: 0;\n}\nul.segment li.active {\n  background: #2c6aff;\n  color: #fff;\n}\n.pl-10 {\n  padding-left: 10px !important;\n}\n.w50 {\n  width: 50% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9pbnNwZWN0LXNrdS9pbnNwZWN0LXNrdS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1za3UvaW5zcGVjdC1za3UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FDQ0o7QURBSTtFQUNJLFlBQUE7QUNFUjtBREVBO0VBQ0ksZUFBQTtBQ0NKO0FEQUk7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQ0VSO0FERUE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7QUNDSjtBREVBO0VBQ0ksY0FBQTtBQ0NKO0FEQ0E7RUFDSSxxQkFBQTtBQ0VKO0FEQUE7RUFDSSxvQkFBQTtBQ0dKO0FEREE7RUFDSSxlQUFBO0FDSUo7QURISTtFQUNJLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNLUjtBRERJO0VBQ0ksWUFBQTtBQ0lSO0FEQUE7RUFDSSxpQkFBQTtFQUNBLHVCQUFBO0FDR0o7QURBQTtFQUNJLGNBQUE7QUNHSjtBREFBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHdCQUFBO0FDR0o7QURGSTtFQUNJLFNBQUE7QUNJUjtBREFBO0VBQ0ksY0FBQTtBQ0dKO0FEQUE7RUFDSSxzQkFBQTtBQ0dKO0FEQUE7RUFDSSxnQkFBQTtBQ0dKO0FEQUE7RUFDSSxZQUFBO0FDR0o7QURBQTs7RUFFSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNHSjtBREFBO0VBQ0ksZ0JBQUE7QUNHSjtBREFBO0VBQ0ksbUJBQUE7QUNHSjtBREZJO0VBQ0ksWUFBQTtBQ0lSO0FEQ0k7RUFDSSxZQUFBO0FDRVI7QURFQTtFQUNJLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUNDSjtBREVBO0VBQ0ksb0JBQUE7QUNDSjtBREVBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7QUNDSjtBREVBO0VBQ0ksbUJBQUE7QUNDSjtBREdBO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0VBQUEsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQ0FKO0FEQ0k7RUFDSSxnQkFBQTtBQ0NSO0FER0E7RUFDSSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDQUo7QURDSTtFQUNJLGdCQUFBO0VBQ0EsVUFBQTtBQ0NSO0FEQVE7RUFDSSwrQkFBQTtBQ0VaO0FEQVE7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0FDRVo7QURHQTtFQUNJLFdBQUE7RUFDQSxvQkFBQTtBQ0FKO0FER0E7RUFDSSxlQUFBO0VBQ0EseUJBQUE7QUNBSjtBRENJO0VBQ0ksZ0NBQUE7QUNDUjtBREdBO0VBQ0ksc0JBQUE7QUNBSjtBREVBO0VBQ0ksdUJBQUE7QUNDSjtBRENBO0VBQ0ksNEJBQUE7QUNFSjtBREFBO0VBQ0ksK0JBQUE7QUNHSjtBREFBO0VBQ0ksZ0JBQUE7QUNHSjtBREFBOztFQUVJLFVBQUE7RUFDQSxnQkFBQTtBQ0dKO0FERkk7O0VBQ0ksNkJBQUE7RUFDQSw4QkFBQTtBQ0tSO0FERkk7O0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSwrQkFBQTtBQ0tSO0FESEk7O0VBQ0ksY0FBQTtBQ01SO0FERkE7RUFDSSw0QkFBQTtBQ0tKO0FERkE7RUFDSSwyQkFBQTtBQ0tKO0FERkE7RUFDSSx1QkFBQTtBQ0tKO0FERkE7RUFDSSwyQkFBQTtBQ0tKO0FERkE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUNLSjtBREZBO0VBQ0ksc0JBQUE7RUFDQSxXQUFBO0FDS0o7QURGQTtFQUNJLDJCQUFBO0FDS0o7QURGQTtFQUNJLFVBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxnQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsY0FBQTtBQ0tKO0FESkk7RUFFSSxlQUFBO0VBQ0EsY0FBQTtBQ0tSO0FESEk7O0VBRUksYUFBQTtFQUNBLFNBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0tSO0FERkE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNLSjtBREZBO0VBQ0ksc0JBQUE7QUNLSjtBREZBO0VBQ0ksMEJBQUE7QUNLSjtBREZBO0VBQ0ksMkJBQUE7QUNLSjtBREZBO0VBQ0ksaUJBQUE7QUNLSjtBREZBO0VBQ0ksV0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDS0o7QURKSTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtBQ01SO0FESkk7RUFDSSxTQUFBO0FDTVI7QURKSTtFQUNJLG1CQUFBO0VBQ0EsV0FBQTtBQ01SO0FERkE7RUFDSSw2QkFBQTtBQ0tKO0FERkE7RUFDSSxxQkFBQTtBQ0tKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vaW5zcGVjdC1za3UvaW5zcGVjdC1za3UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICAgIC0tcGFkZGluZy10b3A6IDE1cHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMTVweDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgICAub3V0LWJveCB7XG4gICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICB9XG59XG5cbi50b3BzIHtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgc2VsZWN0IHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTVweDtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgIGJvcmRlcjogMDtcbiAgICB9XG59XG5cbi5pbnNwZWN0LWJhc2ljLXN0eWxlIHtcbiAgICBtYXJnaW46IDEwcHggMDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG5pb24tbGlzdCB7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG59XG4udzMwIHtcbiAgICB3aWR0aDogMzAlICFpbXBvcnRhbnQ7XG59XG4uYm9yZGVyLTAge1xuICAgIGJvcmRlcjogMCAhaW1wb3J0YW50O1xufVxuLmhlYWRlci1pbnB1dCB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGlvbi1pbnB1dCB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA0cHg7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XG4gICAgICAgIHdpZHRoOiA4MHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgLS1wYWRkaW5nLXRvcDogNXB4O1xuICAgICAgICAtLXBhZGRpbmctYm90dG9tOiA1cHg7XG4gICAgfVxufVxuLmhlYWRlci1pbnB1dDpsYXN0LWNoaWxkIHtcbiAgICBpb24taW5wdXQge1xuICAgICAgICB3aWR0aDogMTIwcHg7XG4gICAgfVxufVxuXG5pb24taXRlbTpsYXN0LWNoaWxkIHtcbiAgICAtLWJvcmRlci13aWR0aDogMDtcbiAgICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcbn1cblxuLmxhYmVsIHtcbiAgICBjb2xvcjogIzQzNDM0Mztcbn1cblxuLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgY29sb3I6ICMzODgwZmM7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luOiA1cHggMCAhaW1wb3J0YW50O1xuICAgIHAge1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgfVxufVxuXG4uZ3JheS1jb2xvciB7XG4gICAgY29sb3I6ICNhMmEyYTI7XG59XG5cbi53MTAwIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUgKyBkaXYge1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5oLTMwIHtcbiAgICBoZWlnaHQ6IDMwcHg7XG59XG5cbmlvbi1pbnB1dCxcbmlucHV0IHtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlM2UzZTM7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIC0tcGFkZGluZy10b3A6IDVweDtcbiAgICAtLXBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbi5zaXplIHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uYmFyLWNvZGUge1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgaW5wdXQge1xuICAgICAgICB3aWR0aDogMTUwcHg7XG4gICAgfVxufVxuXG4ubWFvemhvbmcge1xuICAgIGlvbi1pbnB1dCB7XG4gICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICB9XG59XG5cbi5wYWNraW5nLWluZm8ge1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIGNvbG9yOiAjYTVhNWE1O1xuICAgIGJhY2tncm91bmQ6ICNlZGVkZWQ7XG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xuICAgIHBhZGRpbmc6IDhweDtcbiAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgIHRleHQtaW5kZW50OiAycmVtO1xuICAgIGxpbmUtaGVpZ2h0OiAxOHB4O1xufVxuXG5wLmRlc2MtdGlwcyB7XG4gICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5zZWxlY3Qge1xuICAgIGNvbG9yOiAjNDM0MzQzO1xuICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGJvcmRlcjogMDtcbn1cblxuLnRlc3QtZmVlZGJhY2sge1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgLy8gYm9yZGVyOiAxcHggc29saWQgI2VmZWZlZjtcbn1cblxuLnRvZ2dsZS1ib3gge1xuICAgIHBhZGRpbmc6IDAuNXJlbTtcbiAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgIHRvcDogLTIycHg7XG4gICAgei1pbmRleDogOTk5O1xuICAgIGlvbi1zZWdtZW50IHtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICB9XG59XG5cbi5sYWJlbC1pdGVtIHtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBwYWRkaW5nOiAwLjNyZW07XG4gICAgaW9uLWdyaWQge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBpb24tY29sOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLWNvbCB7XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMC41cmVtO1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDAuNXJlbTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmRlc2MtYm94IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuLnNpemUtZ3JpZCB7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgaW9uLXJvdyB7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjBmMGYwO1xuICAgIH1cbn1cblxuLnctMTAwIHtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xufVxuLncxODAge1xuICAgIHdpZHRoOiAxODBweCAhaW1wb3J0YW50O1xufVxuLm1sLTEwIHtcbiAgICBtYXJnaW4tbGVmdDogMTBweCAhaW1wb3J0YW50O1xufVxuLnBiLTEwIHtcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uaW5zcGVjdGlvbl9yZXF1aXJlIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG4uaW5zcGVjdGlvbl9yZXF1aXJlLFxuLnNrdS1kZXNjIHtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgaW9uLXJvdyB7XG4gICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZjBmMGYwO1xuICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgfVxuXG4gICAgaW9uLWNvbCB7XG4gICAgICAgIGNvbG9yOiAjMzIzMjMyO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgfVxuICAgIGlvbi1jb2wuY29udGVudCB7XG4gICAgICAgIGNvbG9yOiAjNWU1ZTVlO1xuICAgIH1cbn1cblxuLm1sLTE1IHtcbiAgICBtYXJnaW4tbGVmdDogMTVweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbTpub3QoOmZpcnN0LWNoaWxkKSAuZ2xvYmFsLWluc3BlY3QtdGl0bGUge1xuICAgIG1hcmdpbi10b3A6IDEwcHggIWltcG9ydGFudDtcbn1cblxuLncxNTAge1xuICAgIHdpZHRoOiAxNTBweCAhaW1wb3J0YW50O1xufVxuXG4ubXQtMTAge1xuICAgIG1hcmdpbi10b3A6IDEwcHggIWltcG9ydGFudDtcbn1cblxuLm1mIHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5zY2hlZHVsZS1jb250YWluZXIge1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgd2lkdGg6IDEwMCU7XG59XG5cbi5tdC0xMHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5zY2hlZHVsZS1pdGVtIHtcbiAgICB3aWR0aDogNTAlO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgY29sb3I6ICM0MzQzNDM7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlZmVmZWY7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHBhZGRpbmc6IDZweCAwO1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIGNvbG9yOiAjNDM0MzQzO1xuICAgIH1cbiAgICBzZWxlY3QsXG4gICAgb3B0aW9uIHtcbiAgICAgICAgYmFja2dyb3VuZDogMDtcbiAgICAgICAgYm9yZGVyOiAwO1xuICAgICAgICBjb2xvcjogIzQzNDM0MztcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgIH1cbn1cbi5zY2hlZHVsZS1jb250YWluZXI6YWZ0ZXIge1xuICAgIGNvbnRlbnQ6ICcnO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGNsZWFyOiBib3RoO1xufVxuXG4uYWNjb3JkLWJveCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2YwMDtcbn1cblxuLmZzLTE0IHtcbiAgICBmb250LXNpemU6IDE0cHggIWltcG9ydGFudDtcbn1cblxuLm10LTIwIHtcbiAgICBtYXJnaW4tdG9wOiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmFwcC1xdWV1ZSB7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbnVsLnNlZ21lbnQge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICMyYzZhZmY7XG4gICAgaGVpZ2h0OiAyNHB4O1xuICAgIGNvbG9yOiAjMmM2YWZmO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIGxpIHtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICAgICAgICB3aWR0aDogMzMuMzMlO1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjMmM2YWZmO1xuICAgIH1cbiAgICBsaTpsYXN0LWNoaWxkIHtcbiAgICAgICAgYm9yZGVyOiAwO1xuICAgIH1cbiAgICBsaS5hY3RpdmUge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjMmM2YWZmO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG59XG5cbi5wbC0xMCB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi53NTAge1xuICAgIHdpZHRoOiA1MCUgIWltcG9ydGFudDtcbn1cbiIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjJmMmYyO1xuICAtLXBhZGRpbmctdG9wOiAxNXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiAxNXB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG59XG5pb24tY29udGVudCAub3V0LWJveCB7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLnRvcHMge1xuICBmb250LXNpemU6IDEycHg7XG59XG4udG9wcyBzZWxlY3Qge1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgYm9yZGVyOiAwO1xufVxuXG4uaW5zcGVjdC1iYXNpYy1zdHlsZSB7XG4gIG1hcmdpbjogMTBweCAwO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG5pb24tbGlzdCB7XG4gIG1hcmdpbjogMTBweCAwO1xufVxuXG4udzMwIHtcbiAgd2lkdGg6IDMwJSAhaW1wb3J0YW50O1xufVxuXG4uYm9yZGVyLTAge1xuICBib3JkZXI6IDAgIWltcG9ydGFudDtcbn1cblxuLmhlYWRlci1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5oZWFkZXItaW5wdXQgaW9uLWlucHV0IHtcbiAgbWFyZ2luLWxlZnQ6IDRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UzZTNlMztcbiAgd2lkdGg6IDgwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAtLXBhZGRpbmctdG9wOiA1cHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDVweDtcbn1cblxuLmhlYWRlci1pbnB1dDpsYXN0LWNoaWxkIGlvbi1pbnB1dCB7XG4gIHdpZHRoOiAxMjBweDtcbn1cblxuaW9uLWl0ZW06bGFzdC1jaGlsZCB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwO1xuICAtLWlubmVyLWJvcmRlci13aWR0aDogMDtcbn1cblxuLmxhYmVsIHtcbiAgY29sb3I6ICM0MzQzNDM7XG59XG5cbi5nbG9iYWwtaW5zcGVjdC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzODgwZmM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW46IDVweCAwICFpbXBvcnRhbnQ7XG59XG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUgcCB7XG4gIG1hcmdpbjogMDtcbn1cblxuLmdyYXktY29sb3Ige1xuICBjb2xvcjogI2EyYTJhMjtcbn1cblxuLncxMDAge1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xufVxuXG4uZ2xvYmFsLWluc3BlY3QtdGl0bGUgKyBkaXYge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uaC0zMCB7XG4gIGhlaWdodDogMzBweDtcbn1cblxuaW9uLWlucHV0LFxuaW5wdXQge1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1hcmdpbi1yaWdodDogNDBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UzZTNlMztcbiAgd2lkdGg6IDEwMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAtLXBhZGRpbmctdG9wOiA1cHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDVweDtcbn1cblxuLnNpemUge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uYmFyLWNvZGUge1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLmJhci1jb2RlIGlucHV0IHtcbiAgd2lkdGg6IDE1MHB4O1xufVxuXG4ubWFvemhvbmcgaW9uLWlucHV0IHtcbiAgd2lkdGg6IDEwMHB4O1xufVxuXG4ucGFja2luZy1pbmZvIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNhNWE1YTU7XG4gIGJhY2tncm91bmQ6ICNlZGVkZWQ7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgcGFkZGluZzogOHB4O1xuICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICB0ZXh0LWluZGVudDogMnJlbTtcbiAgbGluZS1oZWlnaHQ6IDE4cHg7XG59XG5cbnAuZGVzYy10aXBzIHtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5zZWxlY3Qge1xuICBjb2xvcjogIzQzNDM0MztcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBib3JkZXI6IDA7XG59XG5cbi50ZXN0LWZlZWRiYWNrIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLnRvZ2dsZS1ib3gge1xuICBwYWRkaW5nOiAwLjVyZW07XG4gIHBvc2l0aW9uOiBzdGlja3k7XG4gIHRvcDogLTIycHg7XG4gIHotaW5kZXg6IDk5OTtcbn1cbi50b2dnbGUtYm94IGlvbi1zZWdtZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cblxuLmxhYmVsLWl0ZW0ge1xuICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmc6IDAuM3JlbTtcbn1cbi5sYWJlbC1pdGVtIGlvbi1ncmlkIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMDtcbn1cbi5sYWJlbC1pdGVtIGlvbi1ncmlkIGlvbi1jb2w6Zmlyc3QtY2hpbGQge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZjBmMGYwO1xufVxuLmxhYmVsLWl0ZW0gaW9uLWdyaWQgaW9uLWNvbCB7XG4gIHBhZGRpbmctdG9wOiAwLjVyZW07XG4gIHBhZGRpbmctYm90dG9tOiAwLjVyZW07XG59XG5cbi5kZXNjLWJveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuLnNpemUtZ3JpZCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2YwZjBmMDtcbn1cbi5zaXplLWdyaWQgaW9uLXJvdyB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjBmMGYwO1xufVxuXG4udy0xMDAge1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xufVxuXG4udzE4MCB7XG4gIHdpZHRoOiAxODBweCAhaW1wb3J0YW50O1xufVxuXG4ubWwtMTAge1xuICBtYXJnaW4tbGVmdDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4ucGItMTAge1xuICBwYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uaW5zcGVjdGlvbl9yZXF1aXJlIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbn1cblxuLmluc3BlY3Rpb25fcmVxdWlyZSxcbi5za3UtZGVzYyB7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4uaW5zcGVjdGlvbl9yZXF1aXJlIGlvbi1yb3csXG4uc2t1LWRlc2MgaW9uLXJvdyB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZjBmMGYwO1xuICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNmMGYwZjA7XG59XG4uaW5zcGVjdGlvbl9yZXF1aXJlIGlvbi1jb2wsXG4uc2t1LWRlc2MgaW9uLWNvbCB7XG4gIGNvbG9yOiAjMzIzMjMyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG59XG4uaW5zcGVjdGlvbl9yZXF1aXJlIGlvbi1jb2wuY29udGVudCxcbi5za3UtZGVzYyBpb24tY29sLmNvbnRlbnQge1xuICBjb2xvcjogIzVlNWU1ZTtcbn1cblxuLm1sLTE1IHtcbiAgbWFyZ2luLWxlZnQ6IDE1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW06bm90KDpmaXJzdC1jaGlsZCkgLmdsb2JhbC1pbnNwZWN0LXRpdGxlIHtcbiAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4udzE1MCB7XG4gIHdpZHRoOiAxNTBweCAhaW1wb3J0YW50O1xufVxuXG4ubXQtMTAge1xuICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tZiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5zY2hlZHVsZS1jb250YWluZXIge1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLm10LTEwIHtcbiAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uc2NoZWR1bGUtaXRlbSB7XG4gIHdpZHRoOiA1MCU7XG4gIGZsb2F0OiBsZWZ0O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBjb2xvcjogIzQzNDM0MztcbiAgZGlzcGxheTogZmxleDtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VmZWZlZjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiA2cHggMDtcbn1cbi5zY2hlZHVsZS1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM0MzQzNDM7XG59XG4uc2NoZWR1bGUtaXRlbSBzZWxlY3QsXG4uc2NoZWR1bGUtaXRlbSBvcHRpb24ge1xuICBiYWNrZ3JvdW5kOiAwO1xuICBib3JkZXI6IDA7XG4gIGNvbG9yOiAjNDM0MzQzO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5zY2hlZHVsZS1jb250YWluZXI6YWZ0ZXIge1xuICBjb250ZW50OiBcIlwiO1xuICBkaXNwbGF5OiBibG9jaztcbiAgY2xlYXI6IGJvdGg7XG59XG5cbi5hY2NvcmQtYm94IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2YwMDtcbn1cblxuLmZzLTE0IHtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tdC0yMCB7XG4gIG1hcmdpbi10b3A6IDIwcHggIWltcG9ydGFudDtcbn1cblxuYXBwLXF1ZXVlIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbnVsLnNlZ21lbnQge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyOiAxcHggc29saWQgIzJjNmFmZjtcbiAgaGVpZ2h0OiAyNHB4O1xuICBjb2xvcjogIzJjNmFmZjtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxudWwuc2VnbWVudCBsaSB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgd2lkdGg6IDMzLjMzJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzJjNmFmZjtcbn1cbnVsLnNlZ21lbnQgbGk6bGFzdC1jaGlsZCB7XG4gIGJvcmRlcjogMDtcbn1cbnVsLnNlZ21lbnQgbGkuYWN0aXZlIHtcbiAgYmFja2dyb3VuZDogIzJjNmFmZjtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5wbC0xMCB7XG4gIHBhZGRpbmctbGVmdDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4udzUwIHtcbiAgd2lkdGg6IDUwJSAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.ts ***!
  \*********************************************************************************/
/*! exports provided: ToggleItem, InspectSkuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToggleItem", function() { return ToggleItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectSkuComponent", function() { return InspectSkuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/implement-inspect.service */ "./src/app/services/implement-inspect.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../widget/scan/scan.component */ "./src/app/widget/scan/scan.component.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _queue_queue_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _inspect_cache_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../inspect-cache.service */ "./src/app/pages/implement-inspection/inspect-cache.service.ts");














var ToggleItem = [
    {
        key: 'beforeUnpacking',
        value: '开箱前',
    },
    {
        key: 'afterUnpacking',
        value: '开箱后',
    },
    {
        key: 'requirement',
        value: '验货要求',
    },
];
var InspectSkuComponent = /** @class */ (function () {
    function InspectSkuComponent(es, fb, storage, activeRouter, implementService, uQueue, inspectCache) {
        this.es = es;
        this.fb = fb;
        this.storage = storage;
        this.activeRouter = activeRouter;
        this.implementService = implementService;
        this.uQueue = uQueue;
        this.inspectCache = inspectCache;
        this.speed = false;
        this.otherGrossWeight = false;
        this.data = null;
        this.factory = null;
        this.barCode = '';
        this.outerBarCode = '';
        this.rateStatus = 'inner';
        this.toggleItem = ToggleItem;
        this.currentToggle = ToggleItem[0];
        this.imgOrigin = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].fileUrlPath;
        this.inspectionRequire = {};
        this.currentSegment = 'beforeUnpacking';
        this.inspectRequireSegment = false;
        this.productSize = [];
        this.size = [];
        this.showProgress = false;
        this.customTestArray = [];
        this.customOuterSize = [];
        this.alreadyUpProgress = this.uQueue.alreadyUpProgress;
        this.innerCode = null;
        this.outerCode = null;
    }
    InspectSkuComponent.prototype.showModal = function () {
        this.es.showModal({
            component: _queue_queue_component__WEBPACK_IMPORTED_MODULE_10__["QueueComponent"],
        });
        this.uQueue.alreadyUpProgress = true;
    };
    InspectSkuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.data = this.storage.get('CURRENT_IMPLEMENT_SKU');
        this.factory = this.storage.get('CURRENT_FACTORY_DATA');
        this.currentApplyInsData = this.storage.get('currentApplyInsData');
        this.rateStatus = this.data.rate_container > 1 ? 'outer' : 'inner';
        this.activeRouter.params.subscribe(function (res) {
            _this.contractNo = res.contract_no;
        });
        var sizeModel = null;
        if (this.data.rate_container == 1) {
            //如果是单箱率,内箱变为外箱
            sizeModel = this.fb.group({
                length: this.fb.group({
                    text: this.fb.control(''),
                    pic: this.fb.array([]),
                    num: this.fb.control(''),
                }),
                width: this.fb.group({
                    text: this.fb.control(''),
                    pic: this.fb.array([]),
                    num: this.fb.control(''),
                }),
                height: this.fb.group({
                    text: this.fb.control(''),
                    pic: this.fb.array([]),
                    num: this.fb.control(''),
                }),
                desc: this.fb.array([]),
            });
        }
        else {
            sizeModel = [];
        }
        this.SkuInspectModel = this.fb.group({
            spotCheckNum: this.fb.control(''),
            poNo: this.fb.control(''),
            poNoRes: this.fb.control('accord'),
            inner_box_data: this.fb.group({
                shippingMarks: this.fb.group({
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                size: sizeModel,
                barCode: this.fb.group({
                    isTrue: this.fb.control(''),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                    text: this.fb.control(''),
                    agreement: this.fb.control(''),
                }),
                grossWeight: this.fb.group({
                    text1: this.fb.control(''),
                    text2: this.fb.control(''),
                    text3: this.fb.control(''),
                    text4: this.fb.control(''),
                    text5: this.fb.control(''),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                sizeDesc: this.fb.group({
                    desc: this.fb.array([]),
                }),
                throwBox: this.fb.group({
                    text: this.fb.control(''),
                    isPass: this.fb.control('1'),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                    videos: this.fb.array([]),
                }),
                packing: this.fb.group({
                    isTrue: this.fb.control('none'),
                    desc: this.fb.array([]),
                    is_double_carton: this.fb.control('1'),
                    packingType: this.fb.control('none'),
                    photos: this.fb.array([]),
                    packingBelt: this.fb.control('undetermined'),
                    rateWeightMark: this.fb.control('undetermined'),
                    swelling: this.fb.control('none'),
                }),
                layout: this.fb.group({
                    desc: this.fb.array(['']),
                    photos: this.fb.array([]),
                }),
                productDetail: this.fb.group({
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                productSize: [],
                productSizeDesc: this.fb.group({
                    desc: this.fb.array([]),
                }),
                instructions: this.fb.group({
                    isHas: this.fb.control('1'),
                    type: this.fb.control(''),
                    desc: this.fb.array(['']),
                    photos: this.fb.array([]),
                    instructionsType: this.fb.control('1'),
                }),
                crews: this.fb.group({
                    isTrue: this.fb.control(''),
                    photos: this.fb.array([]),
                    desc: this.fb.array([]),
                }),
                whole: this.fb.group({
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                disputes: this.fb.group({
                    text: this.fb.control(''),
                    photos: this.fb.array([]),
                }),
                netWeight: this.fb.group({
                    textOne: this.fb.control(''),
                    textTwo: this.fb.control(''),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                // appearance: this.fb.group({
                //     desc: this.fb.array([]),
                //     photos: this.fb.array([]),
                //     videos: this.fb.array([]),
                // }),
                function: this.fb.group({
                    desc: this.fb.array([]),
                    videos: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
                bearing: this.fb.group({
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                    videos: this.fb.array([]),
                }),
                // waterContent: this.fb.group({
                //     desc: this.fb.array([]),
                //     photos: this.fb.array([]),
                //     videos: this.fb.array([]),
                // }),
                sumUp: this.fb.group({
                    textOne: this.fb.control(''),
                    textTwo: this.fb.control(''),
                    prodSchedule: this.fb.control('undetermined'),
                    package: this.fb.control('undetermined'),
                    marksAndCode: this.fb.control('undetermined'),
                    prodInfo: this.fb.control('undetermined'),
                    qualityTechnology: this.fb.control('undetermined'),
                    fieldTest: this.fb.control('undetermined'),
                    videos: this.fb.array([]),
                }),
                desc: this.fb.group({
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                }),
            }),
            outer_box_data: this.fb.group({
                shippingMarks: this.fb.group({
                    photos: this.fb.array([]),
                    desc: this.fb.array([]),
                }),
                size: this.fb.group({
                    length: this.fb.group({
                        text: this.fb.control(''),
                        num: this.fb.control(''),
                        pic: this.fb.array([]),
                    }),
                    width: this.fb.group({
                        text: this.fb.control(''),
                        pic: this.fb.array([]),
                        num: this.fb.control(''),
                    }),
                    height: this.fb.group({
                        text: this.fb.control(''),
                        num: this.fb.control(''),
                        pic: this.fb.array([]),
                    }),
                    desc: this.fb.array([]),
                }),
                barCode: this.fb.group({
                    isTrue: this.fb.control(''),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                    text: this.fb.control(''),
                    agreement: this.fb.control(''),
                }),
                grossWeight: this.fb.group({
                    text1: this.fb.control(''),
                    text2: this.fb.control(''),
                    text3: this.fb.control(''),
                    text4: this.fb.control(''),
                    photos: this.fb.array([]),
                    text5: this.fb.control(''),
                    desc: this.fb.array([]),
                }),
                packing: this.fb.group({
                    isTrue: this.fb.control('none'),
                    type: this.fb.control('1'),
                    desc: this.fb.array([]),
                    photos: this.fb.array([]),
                    packingType: this.fb.control('none'),
                    is_double_carton: this.fb.control('none'),
                    packingBelt: this.fb.control('undetermined'),
                    rateWeightMark: this.fb.control('undetermined'),
                    swelling: this.fb.control('none'),
                }),
                layout: this.fb.group({
                    desc: this.fb.array(['']),
                    photos: this.fb.array([]),
                }),
            }),
        });
        this.SkuInspectModel.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_12__["debounceTime"])(900)).subscribe(function (res) {
            //此处存入缓存
            _this.inspectCache.cacheInspectText(res);
        });
    };
    /**
     * 上传状态改变
     */
    InspectSkuComponent.prototype.speedChange = function (e) {
        var html = document.getElementsByTagName('html')[0];
        if (this.speed)
            html.setAttribute('style', '0');
        else
            html.setAttribute('style', '-webkit-filter: saturate(0.5);');
    };
    InspectSkuComponent.prototype.ionViewWillEnter = function () {
        //如果有缓存 则patch 防止闪退
        if (this.inspectCache.getInspectText()) {
            // this.SkuInspectModel.patchValue(this.inspectCache.getInspectText());
        }
        //再获取数据
        this.getBeforeBoxData();
    };
    /**
     * 计算毛重
     */
    InspectSkuComponent.prototype.calcGrossWeight = function () {
        var doms = this.grossWeight.nativeElement.querySelectorAll('input'), ary = [], compare = [];
        for (var i = 0; i < doms.length; i++) {
            if (!doms[i].value)
                return;
            ary.push(doms[i].value);
        }
        compare = ary.sort(function (a, b) { return a - b; });
        this.otherGrossWeight = compare[0] * 1.2 < compare[compare.length - 1];
    };
    InspectSkuComponent.prototype.scan = function (p) {
        var _this = this;
        var modal = this.es.showModal({
            component: _widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_5__["ScanComponent"],
        }, function (res) {
            _this[p == 'inner' ? 'barCode' : 'outerBarCode'] = res.value;
            if (p == 'inner') {
                _this.innerCode = _this.SkuInspectModel.value.inner_box_data.barCode.text == _this.barCode ? '1' : '0';
            }
            else {
                _this.outerCode =
                    _this.SkuInspectModel.value.outer_box_data.barCode.text == _this.outerBarCode ? '1' : '0';
            }
        });
    };
    /**
     * app-item-by-item-desc callback
     * @param e     description array
     * @param type  formGroup item
     * @param boxType   'inner' | 'outer'
     */
    InspectSkuComponent.prototype.descEnter = function (e, type, boxType) {
        this.SkuInspectModel.get(boxType + '_box_data').get(type).get('desc').clear();
        for (var i = 0; i < e.length; i++) {
            this.SkuInspectModel.get(boxType + '_box_data').get(type).get('desc').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''));
        }
        this.SkuInspectModel.get(boxType + '_box_data').get(type).get('desc').setValue(e);
    };
    InspectSkuComponent.prototype.toggleBoxRate = function () {
        //切换内外箱
        this.currentToggle.key == 'beforeUnpacking' ? this.getBeforeBoxData() : this.getAfterBoxData();
    };
    InspectSkuComponent.prototype.setEmptyPhotos = function (obj) {
        var e = obj['inner_box_data'];
        for (var key in e) {
            if (e[key] && e[key].photos) {
                e[key].photos = [];
            }
            if (key == 'productSize' && e['productSize'] && e['productSize'].length) {
                for (var i = 0; i < e['productSize'].length; i++) {
                    e['productSize'][i].pic = [];
                }
            }
        }
        return obj;
    };
    /**
     * 保存
     */
    InspectSkuComponent.prototype.save = function () {
        var _this = this;
        var saved = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
            //条码逻辑
            _this.SkuInspectModel.value.inner_box_data.barCode.isTrue =
                _this.SkuInspectModel.value.inner_box_data.barCode.text ===
                    (_this.barCode && _this.barCode.length ? '1' : '0');
            _this.SkuInspectModel.value.outer_box_data.barCode.isTrue =
                _this.SkuInspectModel.value.outer_box_data.barCode.text ===
                    (_this.outerBarCode && _this.outerBarCode.length ? '1' : '0');
            var postData = JSON.parse(JSON.stringify(_this.SkuInspectModel.value));
            //自定义外箱额外尺寸     //考虑单箱率时内箱就是外箱
            if (_this.data.rate_container > 1) {
                postData.outer_box_data &&
                    (postData.outer_box_data.size_other = JSON.parse(JSON.stringify(_this.customOuterSize)));
            }
            else {
                postData.inner_box_data &&
                    (postData.inner_box_data.size_other = JSON.parse(JSON.stringify(_this.customOuterSize)));
            }
            _this.rateStatus == 'inner' ? delete postData.outer_box_data : delete postData.inner_box_data;
            //内箱自定义尺寸
            postData.inner_box_data &&
                (postData.inner_box_data.productSize = _this.productSize ? JSON.parse(JSON.stringify(_this.productSize)) : []);
            //内向自定义测试字段
            postData.inner_box_data &&
                (postData.inner_box_data.custom_test = _this.customTestArray ? JSON.parse(JSON.stringify(_this.customTestArray)) : []);
            postData.inner_box_data && _this.data.rate_container != 1 && (postData.inner_box_data.size = _this.size);
            //此处将深拷贝的元数据的photos置空 ，影响速度
            postData = _this.setEmptyPhotos(postData);
            _this.es.showAlert({
                message: '正在保存……',
                backdropDismiss: false,
            });
            if (_this.currentToggle.key == 'requirement') {
                observer.next(1);
                return;
            }
            _this.implementService
                .submitSkuData(postData, _this.data.sku, _this.currentApplyInsData.apply_inspection_no, _this.currentToggle.key == 'beforeUnpacking' ? 'before' : 'after', _this.rateStatus == 'inner' ? 1 : 2, _this.contractNo)
                .subscribe(function (res) {
                _this.es.showToast({
                    message: res.message,
                    color: res.status ? 'success' : 'danger',
                });
                _this.es.clearEffectCtrl();
                observer.next(res.status);
            });
        });
        return saved;
    };
    /**
     * video callback
     */
    InspectSkuComponent.prototype.videoOver = function (e, type) { };
    /**
     * 切换 开箱前后 验货要求
     * @param ev  event
     */
    InspectSkuComponent.prototype.selectSegment = function (s) {
        var _this = this;
        this.es.showAlert({
            message: '确定要保存吗？',
            buttons: [
                {
                    text: '取消',
                },
                {
                    text: '确定',
                    handler: function () {
                        _this.save().subscribe(function (res) {
                            if (!res) {
                                return;
                            }
                            switch (s) {
                                case 'beforeUnpacking':
                                    _this.getBeforeBoxData(s);
                                    // this.save()
                                    break;
                                case 'afterUnpacking':
                                    _this.getAfterBoxData(s);
                                    // this.save()
                                    break;
                                default: {
                                }
                            }
                            _this.currentToggle = _this.toggleItem.find(function (res) { return res.key == s; });
                        });
                    },
                },
            ],
        });
    };
    InspectSkuComponent.prototype.segmentChanged = function (ev) {
        var _this = this;
        console.log(ev);
        this.inspectRequireSegment = ev.detail.value == 'requirement';
        // return
        this.es.showAlert({
            message: '确定要保存吗？',
            buttons: [
                {
                    text: '取消',
                },
                {
                    text: '确定',
                    handler: function () {
                        _this.save().subscribe(function (res) {
                            if (!res) {
                                return;
                            }
                            switch (ev.detail.value) {
                                case 'beforeUnpacking':
                                    _this.getBeforeBoxData();
                                    // this.save()
                                    break;
                                case 'afterUnpacking':
                                    _this.getAfterBoxData();
                                    // this.save()
                                    break;
                                default: {
                                }
                            }
                            _this.currentToggle = _this.toggleItem.find(function (res) { return res.key == ev.detail.value; });
                        });
                    },
                },
            ],
        });
    };
    /**
     * 动态生成FormControl
     * @param ary       desc||videos||photos
     * @param boxType   inner_box_data | 'outer_box_data
     * @param item      formGroup item
     * @param type      'desc' | 'videos' | 'photos'
     * @param sItem     size
     */
    InspectSkuComponent.prototype.dynamicBuildFC = function (ary, boxType, item, type, sItem) {
        if (item !== 'spotCheckNum' && item !== 'poNo' && item !== 'poNoRes' && item !== 'inspection_require' && item !== 'custom_test') {
            var box_1 = this.SkuInspectModel.get(boxType);
            if (!box_1.get(item))
                console.log(ary, boxType, item, type, sItem); //打印出错
            var formAry_1 = box_1.get(item).get(type);
            //先清空
            if (item != 'size' || (item == 'size' && type == 'desc')) {
                formAry_1 && formAry_1.clear();
            }
            else {
                formAry_1 = formAry_1.get(sItem);
                formAry_1 && formAry_1.clear();
            }
            if (!ary || !(ary instanceof Array))
                return;
            ary.forEach(function (res) {
                formAry_1 && formAry_1.push(new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''));
                box_1 = null;
            });
        }
        return;
        try {
            if (item != 'spotCheckNum' && item != 'poNo' && item != 'poNoRes') {
                var box_2 = this.SkuInspectModel.get(boxType), formAry_2 = box_2.get(item).get(type);
                //先清空
                if (item != 'size' || (item == 'size' && type == 'desc')) {
                    formAry_2 && formAry_2.clear();
                }
                else {
                    formAry_2 = formAry_2.get(sItem);
                    formAry_2 && formAry_2.clear();
                }
                if (!ary || !(ary instanceof Array))
                    return;
                ary.forEach(function (res) {
                    formAry_2 && formAry_2.push(new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''));
                    box_2 = null;
                });
            }
        }
        catch (e) {
            console.log(e);
        }
    };
    InspectSkuComponent.prototype.regValid = function (e) {
        if (!/^(?!0+(?:\.0+)?$)(?:[1-9]\d*|0)(?:\.\d{1,2})?$/.test(e.detail.value)) {
            e.target.value = null;
        }
    };
    /**
     * 获取开箱前数据
     */
    InspectSkuComponent.prototype.getBeforeBoxData = function (s) {
        var _this = this;
        this.implementService
            .getBeforeBoxData({
            apply_inspection_no: this.currentApplyInsData.apply_inspection_no,
            sku: this.data.sku,
            is_inner_box: this.rateStatus == 'inner' ? 1 : 2,
            contract_no: this.contractNo,
        })
            .subscribe(function (res) {
            s && (_this.currentSegment = s);
            if (!res)
                return;
            var box = res[_this.rateStatus + '_box_data'];
            _this.SkuInspectModel.reset();
            _this.inspectionRequire = res[_this.rateStatus + '_box_data']
                ? res[_this.rateStatus + '_box_data'].inspection_require
                : {};
            //外箱尺寸逻辑（单箱率时 内箱为外箱）
            if (_this.data.rate_container > 1) {
                _this.rateStatus === 'outer' &&
                    (_this.customOuterSize =
                        res.outer_box_data.size_other && res.outer_box_data.size_other.length
                            ? res.outer_box_data.size_other
                            : []);
            }
            else {
                _this.customOuterSize =
                    res.inner_box_data.size_other && res.inner_box_data.size_other.length
                        ? res.inner_box_data.size_other
                        : [];
            }
            for (var key in box) {
                var element = box[key];
                if (box.hasOwnProperty(key) &&
                    key != 'inspection_require' &&
                    key != 'size' &&
                    key != 'size_other') {
                    if (!!element) {
                        _this.dynamicBuildFC(element.desc, _this.rateStatus + '_box_data', key, 'desc');
                        _this.dynamicBuildFC(element.videos, _this.rateStatus + '_box_data', key, 'videos');
                        _this.dynamicBuildFC(element.photos, _this.rateStatus + '_box_data', key, 'photos');
                    }
                }
                //多箱率的外箱和单向率的内箱是有size的
                if (key == 'size' && (_this.rateStatus == 'outer' || _this.data.rate_container == 1)) {
                    if (!!element) {
                        var element_1 = box[key];
                        _this.dynamicBuildFC(element_1.desc, _this.rateStatus + '_box_data', key, 'desc');
                        _this.dynamicBuildFC(element_1['length'].pic, _this.rateStatus + '_box_data', key, 'length', 'pic');
                        _this.dynamicBuildFC(element_1['width'].pic, _this.rateStatus + '_box_data', key, 'width', 'pic');
                        _this.dynamicBuildFC(element_1['height'].pic, _this.rateStatus + '_box_data', key, 'height', 'pic');
                    }
                    else
                        _this.dynamicBuildFC(element.desc, _this.rateStatus + '_box_data', key, 'desc');
                }
            }
            var sizeModel = null;
            //patch value to formGroup
            if (_this.rateStatus == 'inner') {
                if (_this.data.rate_container == 1) {
                    sizeModel = {
                        //尺寸
                        height: {
                            text: res.inner_box_data.size.height.text,
                            num: res.inner_box_data.size.height.num,
                            pic: res.inner_box_data.size.height.pic ? res.inner_box_data.size.height.pic : [],
                        },
                        length: {
                            text: res.inner_box_data.size.length.text,
                            num: res.inner_box_data.size.length.num,
                            pic: res.inner_box_data.size.length.pic ? res.inner_box_data.size.length.pic : [],
                        },
                        width: {
                            text: res.inner_box_data.size.width.text,
                            num: res.inner_box_data.size.width.num,
                            pic: res.inner_box_data.size.width.pic ? res.inner_box_data.size.width.pic : [],
                        },
                        desc: res.inner_box_data.size.desc ? res.inner_box_data.size.desc : [],
                    };
                }
                else {
                    sizeModel =
                        res.inner_box_data.size && res.inner_box_data.size.length
                            ? res.inner_box_data.size
                            : [
                                {
                                    size_width: null,
                                    size_height: null,
                                    size_length: null,
                                    size_type: null,
                                    pic: [],
                                },
                            ];
                }
                _this.SkuInspectModel.patchValue({
                    spotCheckNum: res.inner_box_data.spotCheckNum,
                    poNo: res.inner_box_data.poNo,
                    poNoRes: res.inner_box_data.poNoRes ? res.inner_box_data.poNoRes : 'accord',
                    inner_box_data: {
                        barCode: {
                            //条码
                            isTrue: res.inner_box_data.barCode.isTrue,
                            desc: res.inner_box_data.barCode.desc ? res.inner_box_data.barCode.desc : [],
                            text: res.inner_box_data.barCode.text,
                            photos: res.inner_box_data.barCode.photos ? res.inner_box_data.barCode.photos : [],
                            agreement: res.inner_box_data.barCode.agreement
                                ? res.inner_box_data.barCode.agreement
                                : '0',
                        },
                        grossWeight: {
                            //毛重
                            text1: res.inner_box_data.grossWeight.text1,
                            text2: res.inner_box_data.grossWeight.text2,
                            text3: res.inner_box_data.grossWeight.text3,
                            text4: res.inner_box_data.grossWeight.text4,
                            text5: res.inner_box_data.grossWeight.text5,
                            desc: res.inner_box_data.grossWeight.desc ? res.inner_box_data.grossWeight.desc : [],
                            photos: res.inner_box_data.grossWeight.photos
                                ? res.inner_box_data.grossWeight.photos
                                : [],
                        },
                        size: sizeModel,
                        sizeDesc: {
                            desc: res.inner_box_data.sizeDesc && res.inner_box_data.sizeDesc.desc
                                ? res.inner_box_data.sizeDesc.desc
                                : [],
                        },
                        shippingMarks: {
                            //唛头
                            desc: res.inner_box_data.shippingMarks.desc
                                ? res.inner_box_data.shippingMarks.desc
                                : [],
                            photos: res.inner_box_data.shippingMarks.photos
                                ? res.inner_box_data.shippingMarks.photos
                                : [],
                        },
                        throwBox: {
                            //摔箱
                            desc: res.inner_box_data.throwBox.desc ? res.inner_box_data.throwBox.desc : [],
                            isPass: res.inner_box_data.throwBox.isPass,
                            photos: res.inner_box_data.throwBox.photos ? res.inner_box_data.throwBox.photos : [],
                            text: res.inner_box_data.throwBox.text,
                            videos: res.inner_box_data.throwBox.videos ? res.inner_box_data.throwBox.videos : [],
                        },
                    },
                });
            }
            else {
                _this.SkuInspectModel.patchValue({
                    spotCheckNum: res.outer_box_data.spotCheckNum,
                    poNo: res.outer_box_data.poNo,
                    poNoRes: res.outer_box_data.poNoRes ? res.outer_box_data.poNoRes : 'accord',
                    outer_box_data: {
                        barCode: {
                            //条码
                            isTrue: res.outer_box_data.barCode.isTrue,
                            desc: res.outer_box_data.barCode.desc ? res.outer_box_data.barCode.desc : [],
                            text: res.outer_box_data.barCode.text,
                            photos: res.outer_box_data.barCode.photos ? res.outer_box_data.barCode.photos : [],
                            agreement: res.outer_box_data.barCode.agreement
                                ? res.outer_box_data.barCode.agreement
                                : '0',
                        },
                        grossWeight: {
                            //毛重
                            text1: res.outer_box_data.grossWeight.text1,
                            text2: res.outer_box_data.grossWeight.text2,
                            text3: res.outer_box_data.grossWeight.text3,
                            text4: res.outer_box_data.grossWeight.text4,
                            text5: res.outer_box_data.grossWeight.text5,
                            desc: res.outer_box_data.grossWeight.desc ? res.outer_box_data.grossWeight.desc : [],
                            photos: res.outer_box_data.grossWeight.photos
                                ? res.outer_box_data.grossWeight.photos
                                : [],
                        },
                        shippingMarks: {
                            //唛头
                            desc: res.outer_box_data.shippingMarks.desc
                                ? res.outer_box_data.shippingMarks.desc
                                : [],
                            photos: res.outer_box_data.shippingMarks.photos
                                ? res.outer_box_data.shippingMarks.photos
                                : [],
                        },
                        size: {
                            //尺寸
                            height: {
                                text: res.outer_box_data.size.height.text,
                                num: res.outer_box_data.size.height.num,
                                pic: res.outer_box_data.size.height.pic ? res.outer_box_data.size.height.pic : [],
                            },
                            length: {
                                text: res.outer_box_data.size.length.text,
                                num: res.outer_box_data.size.length.num,
                                pic: res.outer_box_data.size.length.pic ? res.outer_box_data.size.length.pic : [],
                            },
                            width: {
                                text: res.outer_box_data.size.width.text,
                                num: res.outer_box_data.size.width.num,
                                pic: res.outer_box_data.size.width.pic ? res.outer_box_data.size.width.pic : [],
                            },
                            desc: res.outer_box_data.size.desc ? res.outer_box_data.size.desc : [],
                        },
                    },
                });
            }
            //毛重 显示五个值
            _this.otherGrossWeight =
                _this.SkuInspectModel.value[_this.rateStatus + '_box_data'].grossWeight.text4 &&
                    _this.SkuInspectModel.value[_this.rateStatus + '_box_data'].grossWeight.text5;
        });
    };
    /**
     * 获取开箱后数据
     */
    InspectSkuComponent.prototype.getAfterBoxData = function (s) {
        var _this = this;
        this.implementService
            .getAfterBoxData({
            apply_inspection_no: this.currentApplyInsData.apply_inspection_no,
            sku: this.data.sku,
            is_inner_box: this.rateStatus == 'inner' ? 1 : 2,
            contract_no: this.contractNo,
        })
            .subscribe(function (res) {
            if (!res)
                return;
            s && (_this.currentSegment = s);
            _this.SkuInspectModel.reset();
            var box = res[_this.rateStatus + '_box_data'];
            _this.inspectionRequire = res[_this.rateStatus + '_box_data']
                ? res[_this.rateStatus + '_box_data'].inspection_require
                : {};
            _this.rateStatus === 'inner' &&
                (_this.customTestArray =
                    res.inner_box_data.custom_test && res.inner_box_data.custom_test.length
                        ? res.inner_box_data.custom_test
                        : undefined);
            for (var key in box) {
                var element = box[key];
                if ((box.hasOwnProperty(key) && key !== 'inspection_require') || key !== 'custom_test') {
                    if (!!element && key != 'productSize') {
                        _this.dynamicBuildFC(element.desc, _this.rateStatus + '_box_data', key, 'desc');
                        _this.dynamicBuildFC(element.videos, _this.rateStatus + '_box_data', key, 'videos');
                        _this.dynamicBuildFC(element.photos, _this.rateStatus + '_box_data', key, 'photos');
                    }
                }
                if (key == 'size') {
                    if (!!element) {
                        var element_2 = box[key];
                        _this.dynamicBuildFC(element_2.desc, _this.rateStatus + '_box_data', key, 'desc');
                        _this.dynamicBuildFC(element_2['length'].pic, _this.rateStatus + '_box_data', key, 'length', 'pic');
                        _this.dynamicBuildFC(element_2['width'].pic, _this.rateStatus + '_box_data', key, 'width', 'pic');
                        _this.dynamicBuildFC(element_2['height'].pic, _this.rateStatus + '_box_data', key, 'height', 'pic');
                    }
                }
            }
            if (_this.rateStatus == 'inner') {
                _this.SkuInspectModel.patchValue({
                    spotCheckNum: res.inner_box_data.spotCheckNum,
                    poNo: res.inner_box_data.poNo,
                    poNoRes: res.inner_box_data.poNoRes ? res.inner_box_data.poNoRes : 'accord',
                    inner_box_data: {
                        packing: {
                            //包装
                            is_double_carton: res.inner_box_data.packing.is_double_carton,
                            desc: res.inner_box_data.packing.desc ? res.inner_box_data.packing.desc : [],
                            isTrue: res.inner_box_data.packing.isTrue,
                            packingType: res.inner_box_data.packing.packingType,
                            photos: res.inner_box_data.packing.photos ? res.inner_box_data.packing.photos : [],
                            packingBelt: res.inner_box_data.packing.packingBelt
                                ? res.inner_box_data.packing.packingBelt
                                : 'undetermined',
                            rateWeightMark: res.inner_box_data.packing.rateWeightMark
                                ? res.inner_box_data.packing.rateWeightMark
                                : 'undetermined',
                            swelling: res.inner_box_data.packing.swelling
                                ? res.inner_box_data.packing.swelling
                                : 'none',
                        },
                        layout: {
                            //摆放图
                            photos: res.inner_box_data.layout.photos ? res.inner_box_data.layout.photos : [],
                            desc: res.inner_box_data.layout.desc ? res.inner_box_data.layout.desc : [],
                        },
                        productDetail: {
                            //产品
                            desc: res.inner_box_data.productDetail.desc
                                ? res.inner_box_data.productDetail.desc
                                : [],
                            photos: res.inner_box_data.productDetail.photos
                                ? res.inner_box_data.productDetail.photos
                                : [],
                        },
                        instructions: {
                            //说明书
                            isHas: res.inner_box_data.instructions.isHas,
                            type: res.inner_box_data.instructions.type,
                            desc: res.inner_box_data.instructions.desc ? res.inner_box_data.instructions.desc : [],
                            photos: res.inner_box_data.instructions.photos
                                ? res.inner_box_data.instructions.photos
                                : [],
                            instructionsType: res.inner_box_data.instructions.instructionsType,
                        },
                        crews: {
                            //螺丝包
                            isTrue: res.inner_box_data.crews.isTrue,
                            desc: res.inner_box_data.crews.desc ? res.inner_box_data.crews.desc : [],
                            photos: res.inner_box_data.crews.photos ? res.inner_box_data.crews.photos : [],
                        },
                        whole: {
                            //组装后整体
                            desc: res.inner_box_data.whole.desc ? res.inner_box_data.whole.desc : [],
                            photos: res.inner_box_data.whole.photos ? res.inner_box_data.whole.photos : [],
                        },
                        disputes: {
                            //sku争议
                            text: res.inner_box_data.disputes.text ? res.inner_box_data.disputes.text : [],
                            photos: res.inner_box_data.disputes.photos ? res.inner_box_data.disputes.photos : [],
                        },
                        productSize: res.inner_box_data.productSize && res.inner_box_data.productSize.length
                            ? res.inner_box_data.productSize
                            : [
                                {
                                    size_width: null,
                                    size_height: null,
                                    size_length: null,
                                    size_type: null,
                                    size_weight: null,
                                    pic: [],
                                },
                            ],
                        productSizeDesc: {
                            desc: res.inner_box_data.productSizeDesc.desc
                                ? res.inner_box_data.productSizeDesc.desc
                                : [],
                        },
                        netWeight: {
                            //净重
                            textOne: res.inner_box_data.netWeight.textOne,
                            textTwo: res.inner_box_data.netWeight.textTwo,
                            desc: res.inner_box_data.netWeight.desc ? res.inner_box_data.netWeight.desc : [],
                            photos: res.inner_box_data.netWeight.photos ? res.inner_box_data.netWeight.photos : [],
                        },
                        // appearance: {
                        //     //外观检测
                        //     desc: res.inner_box_data.appearance.desc ? res.inner_box_data.appearance.desc : [],
                        //     photos: res.inner_box_data.appearance.photos
                        //         ? res.inner_box_data.appearance.photos
                        //         : [],
                        //     videos: res.inner_box_data.appearance.videos
                        //         ? res.inner_box_data.appearance.videos
                        //         : [],
                        // },
                        function: {
                            //功能检测
                            desc: res.inner_box_data.function.desc ? res.inner_box_data.function.desc : [],
                            photos: res.inner_box_data.function.photos ? res.inner_box_data.function.photos : [],
                            videos: res.inner_box_data.function.videos ? res.inner_box_data.function.videos : [],
                        },
                        bearing: {
                            //承重检测
                            desc: res.inner_box_data.bearing.desc ? res.inner_box_data.bearing.desc : [],
                            photos: res.inner_box_data.bearing.photos ? res.inner_box_data.bearing.photos : [],
                            videos: res.inner_box_data.bearing.videos ? res.inner_box_data.bearing.videos : [],
                        },
                        // waterContent: {
                        //     //含水量检测
                        //     desc: res.inner_box_data.waterContent.desc ? res.inner_box_data.waterContent.desc : [],
                        //     photos: res.inner_box_data.waterContent.photos
                        //         ? res.inner_box_data.waterContent.photos
                        //         : [],
                        //     videos: res.inner_box_data.waterContent.videos
                        //         ? res.inner_box_data.waterContent.videos
                        //         : [],
                        // },
                        // custom_test:
                        //     res.inner_box_data.custom_test && res.inner_box_data.custom_test.length
                        //         ? res.inner_box_data.custom_test
                        //         : null,
                        sumUp: {
                            //总结
                            textOne: res.inner_box_data.sumUp.textOne,
                            textTwo: res.inner_box_data.sumUp.textTwo,
                            prodSchedule: res.inner_box_data.sumUp.prodSchedule
                                ? res.inner_box_data.sumUp.prodSchedule
                                : 'undetermined',
                            package: res.inner_box_data.sumUp.package
                                ? res.inner_box_data.sumUp.package
                                : 'undetermined',
                            marksAndCode: res.inner_box_data.sumUp.marksAndCode
                                ? res.inner_box_data.sumUp.marksAndCode
                                : 'undetermined',
                            prodInfo: res.inner_box_data.sumUp.prodInfo
                                ? res.inner_box_data.sumUp.prodInfo
                                : 'undetermined',
                            qualityTechnology: res.inner_box_data.sumUp.qualityTechnology
                                ? res.inner_box_data.sumUp.qualityTechnology
                                : 'undetermined',
                            fieldTest: res.inner_box_data.sumUp.fieldTest
                                ? res.inner_box_data.sumUp.fieldTest
                                : 'undetermined',
                            videos: res.inner_box_data.sumUp.videos ? res.inner_box_data.sumUp.videos : [],
                        },
                        desc: {
                            //整体描述
                            desc: res.inner_box_data.desc.desc ? res.inner_box_data.desc.desc : [],
                            photos: res.inner_box_data.desc.photos ? res.inner_box_data.desc.photos : [],
                        },
                    },
                });
            }
            else {
                _this.SkuInspectModel.patchValue({
                    spotCheckNum: res.outer_box_data.spotCheckNum,
                    poNo: res.outer_box_data.poNo,
                    poNoRes: res.outer_box_data.poNoRes ? res.outer_box_data.poNoRes : 'accord',
                    outer_box_data: {
                        packing: {
                            is_double_carton: res.outer_box_data.packing.is_double_carton,
                            desc: res.outer_box_data.packing.desc ? res.outer_box_data.packing.desc : [],
                            isTrue: res.outer_box_data.packing.isTrue,
                            packingType: res.outer_box_data.packing.packingType,
                            photos: res.outer_box_data.packing.photos ? res.outer_box_data.packing.photos : [],
                            packingBelt: res.outer_box_data.packing.packingBelt
                                ? res.outer_box_data.packing.packingBelt
                                : 'undetermined',
                            rateWeightMark: res.outer_box_data.packing.rateWeightMark
                                ? res.outer_box_data.packing.rateWeightMark
                                : 'undetermined',
                            swelling: res.outer_box_data.packing.swelling
                                ? res.outer_box_data.packing.swelling
                                : 'none',
                        },
                        layout: {
                            //摆放图 
                            photos: res.outer_box_data.layout.photos ? res.outer_box_data.layout.photos : [],
                            desc: res.outer_box_data.layout.desc ? res.outer_box_data.layout.desc : [],
                        },
                    },
                });
            }
        });
    };
    InspectSkuComponent.prototype.productSizeChange = function (e) {
        this.productSize = e;
    };
    InspectSkuComponent.prototype.sizeChange = function (e) {
        this.size = e;
    };
    InspectSkuComponent.prototype.outerSizeChange = function (e) {
        console.log(e);
        this.customOuterSize = e;
    };
    InspectSkuComponent.prototype.ionViewDidLeave = function () {
        // document.getElementsByTagName('html')[0].setAttribute('style','-webkit-filter: 0;')
    };
    InspectSkuComponent.prototype.customTestChange = function (e) {
        console.log(e);
        this.customTestArray = e;
    };
    InspectSkuComponent.prototype.upload = function () {
    };
    InspectSkuComponent.ctorParameters = function () { return [
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"] },
        { type: src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_2__["ImplementInspectService"] },
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_11__["UploadQueueService"] },
        { type: _inspect_cache_service__WEBPACK_IMPORTED_MODULE_13__["InspectCacheService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ViewChild"])('grossWeight', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ElementRef"])
    ], InspectSkuComponent.prototype, "grossWeight", void 0);
    InspectSkuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_7__["Component"])({
            selector: 'app-inspect-sku',
            template: __webpack_require__(/*! raw-loader!./inspect-sku.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.html"),
            styles: [__webpack_require__(/*! ./inspect-sku.component.scss */ "./src/app/pages/implement-inspection/inspect-sku/inspect-sku.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"],
            src_app_services_implement_inspect_service__WEBPACK_IMPORTED_MODULE_2__["ImplementInspectService"],
            _upload_queue_service__WEBPACK_IMPORTED_MODULE_11__["UploadQueueService"],
            _inspect_cache_service__WEBPACK_IMPORTED_MODULE_13__["InspectCacheService"]])
    ], InspectSkuComponent);
    return InspectSkuComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/sku.guard.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/implement-inspection/sku.guard.ts ***!
  \*********************************************************/
/*! exports provided: SkuGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuGuard", function() { return SkuGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SkuGuard = /** @class */ (function () {
    function SkuGuard() {
    }
    SkuGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        return true;
        // return window.confirm('请注意保存数据，一旦返回未保存的数据会丢失！')
    };
    SkuGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        })
    ], SkuGuard);
    return SkuGuard;
}());



/***/ }),

/***/ "./src/app/pipe/contract.pipe.ts":
/*!***************************************!*\
  !*** ./src/app/pipe/contract.pipe.ts ***!
  \***************************************/
/*! exports provided: ContractPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContractPipe", function() { return ContractPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ContractPipe = /** @class */ (function () {
    function ContractPipe() {
    }
    ContractPipe.prototype.transform = function (value, factory) {
        if (!value)
            return;
        var some = [];
        value.forEach(function (element) {
            if (element.factory_code == factory) {
                some = element.sku_data;
            }
        });
        return some;
    };
    ContractPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'contract',
        })
    ], ContractPipe);
    return ContractPipe;
}());



/***/ }),

/***/ "./src/app/pipe/sku-list.pipe.ts":
/*!***************************************!*\
  !*** ./src/app/pipe/sku-list.pipe.ts ***!
  \***************************************/
/*! exports provided: SkuListPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuListPipe", function() { return SkuListPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SkuListPipe = /** @class */ (function () {
    function SkuListPipe() {
    }
    SkuListPipe.prototype.transform = function (value) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        if (!value)
            return;
        var some = [];
        value.forEach(function (element) {
            some = some.concat(element.contract.sku_lists);
        });
        return some;
    };
    SkuListPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'skuList',
        })
    ], SkuListPipe);
    return SkuListPipe;
}());



/***/ }),

/***/ "./src/app/pipe/test.pipe.ts":
/*!***********************************!*\
  !*** ./src/app/pipe/test.pipe.ts ***!
  \***********************************/
/*! exports provided: TestPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestPipe", function() { return TestPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TestPipe = /** @class */ (function () {
    function TestPipe() {
    }
    TestPipe.prototype.transform = function (value) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        console.log(value);
        return value;
    };
    TestPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'test',
        })
    ], TestPipe);
    return TestPipe;
}());



/***/ })

}]);
//# sourceMappingURL=pages-implement-inspection-implement-inspection-module-es5.js.map