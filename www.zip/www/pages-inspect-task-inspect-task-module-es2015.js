(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-inspect-task-inspect-task-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <!-- <ion-buttons slot=\"end\">\n      <ion-button color=\"light\" fill=\"clear\" (click)=\"inspectOp()\" size=\"small\"\n        >验货员操作</ion-button\n      >\n    </ion-buttons> -->\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/inspect-task\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>验货任务</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card mode=\"ios\" class=\"factory\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">工厂信息</ion-card-title>\n        </ion-card-header>\n        <ion-item class=\"activated\">\n            <ion-icon name=\"bookmark\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>工厂名</ion-label>\n            <ion-text>{{ data[0].factory_name }}</ion-text>\n        </ion-item>\n\n        <ion-item class=\"activated\">\n            <ion-icon name=\"pin\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>工厂地址</ion-label>\n            <ion-text>{{ data[0].factory_address }}</ion-text>\n        </ion-item>\n\n        <ion-item class=\"activated\">\n            <ion-icon name=\"information-circle\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>工厂备注</ion-label>\n            <ion-text>{{ data[0].factory_desc ? data[0].factory_desc : \"暂无\" }}</ion-text>\n        </ion-item>\n\n        <ion-item class=\"activated\">\n            <ion-item class=\"inner\">\n                <ion-icon name=\"contact\" slot=\"start\" mode=\"ios\"></ion-icon>\n                <ion-label>联系人</ion-label>\n                <ion-text>{{ data[0].factory_contacts }}</ion-text>\n            </ion-item>\n            <ion-item class=\"inner\">\n                <ion-icon name=\"call\" slot=\"start\" mode=\"ios\"></ion-icon>\n                <ion-label>联系方式</ion-label>\n                <ion-text>{{ data[0].mobil_phone ? data[0].mobil_phone : \"暂无\" }}</ion-text>\n            </ion-item>\n        </ion-item>\n\n        <ion-item class=\"activated\">\n            <ion-item class=\"inner\">\n                <ion-icon name=\"menu\" slot=\"start\" mode=\"ios\"></ion-icon>\n                <ion-label>验货SKU数</ion-label>\n                <ion-text>{{ data.quantity }}</ion-text>\n            </ion-item>\n            <ion-item class=\"inner\">\n                <ion-icon name=\"hammer\" slot=\"start\" mode=\"ios\"></ion-icon>\n                <ion-label>操作</ion-label>\n                <ion-button fill=\"clear\" size=\"small\" [routerLink]=\"['/inspector-setting', data[0].id]\"\n                    >验货员操作</ion-button\n                >\n            </ion-item>\n        </ion-item>\n        <ion-item class=\"activated\">\n            <ion-icon name=\"menu\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>合同详情</ion-label>\n            <ion-button fill=\"clear\" size=\"small\" (click)=\"toSkuDesc(data[0])\">详情</ion-button>\n        </ion-item>\n    </ion-card>\n\n    <ion-card class=\"contract\" mode=\"ios\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">任务</ion-card-title>\n        </ion-card-header>\n        <ion-grid>\n            <ion-row>\n                <ion-col align-self-center>合同号</ion-col>\n                <ion-col align-self-center>合同SKU数</ion-col>\n            </ion-row>\n\n            <ion-row *ngFor=\"let item of data[0].contract_info_arr\">\n                <ion-col align-self-center>{{ item.contract_no }}</ion-col>\n                <ion-col align-self-center>{{ item.total_quantity }}</ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/inspect-task.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspect-task/inspect-task.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>验货任务</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content> \n    <ion-searchbar \n        animated\n        clearInput\n        mode=\"ios\"\n        placeholder=\"输入工厂名检索\"\n        (ionChange)=\"factoryChange()\"\n        [(ngModel)]=\"getListParams.value\"\n    ></ion-searchbar>\n\n    <ion-button fill='clear' expand=\"full\" *ngIf=\"!inspectGroup || !inspectGroup.length\" (click)=\"ionViewWillEnter()\">重新获取</ion-button>\n\n    <ion-card *ngFor=\"let item of inspectGroup\" mode=\"ios\">\n        <ion-item class=\"card-header\">\n            <ion-icon name=\"people\" slot=\"start\" color=\"primary\"></ion-icon>\n            <ion-label><span>质检员：</span>{{ item.user.join(\",\") }}</ion-label>\n            <ion-label class=\"text-c\"><span>验货批次号：</span>{{ item.inspection_group_no }}</ion-label>\n        </ion-item>\n\n        <ion-card-content>\n            <ion-label class=\"text-r pl-5\"\n                >时间段： {{ (item.probable_inspection_date_range.start | date: \"MM月-dd日\") + \" — \" +\n                (item.probable_inspection_date_range.end ? (item.probable_inspection_date_range.end | date: \"MM月-dd日\")\n                : \"\") }}\n            </ion-label>\n            <ion-grid *ngIf=\"screenType == 'Vertical'\">\n                <ion-row class=\"title\">\n                    <ion-col align-self-center [size]=\"3.4\">\n                        验货流水号\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"4.5\">\n                        验货工厂\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"2.2\">\n                        验货SKU数\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"1.7\">\n                        操作\n                    </ion-col>\n                </ion-row>\n\n                <ion-row *ngFor=\"let sItem of item.apply_inspections\">\n                    <ion-col align-self-center [size]=\"3.4\">\n                        {{ sItem.data[0].apply_inspection_no }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"4.5\">\n                        {{ sItem.factory_name }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"2.2\">\n                        {{ sItem.sku_count }}\n                    </ion-col>\n                    <ion-col\n                        align-self-center\n                        [size]=\"1.7\"\n                        class=\"ion-col-no-pad\"\n                        fxLayout=\"row\"\n                        fxLayoutAlign=\"start center\"\n                    >\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"toContract(sItem.data)\">详情</ion-button>\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"inspectOp(sItem,item)\">验货员</ion-button>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n\n            <ion-grid *ngIf=\"screenType == 'Horizontal'\">\n                <ion-row class=\"title\">\n                    <ion-col align-self-center [size]=\"1.6\">\n                        验货流水号\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"2.7\">\n                        验货工厂\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"1.3\">\n                        工厂地址\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"0.9\">\n                        最早时间\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"1.3\">\n                        计划验货\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\".9\">\n                        最晚验货\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"0.8\">\n                        联系人\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"1.35\">\n                        联系电话\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"0.95\">\n                        操作\n                    </ion-col>\n                </ion-row>\n\n                <ion-row *ngFor=\"let sItem of item.apply_inspections\">\n                    <ion-col align-self-center [size]=\"1.6\">\n                        {{ sItem.data[0].apply_inspection_no }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"2.7\">\n                        {{ sItem.factory_name }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"1.3\">\n                        {{ sItem.factory_address }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"0.9\">\n                        {{ sItem.inspection_date.inspection_date | date: \"MM-dd\" }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"1.3\">\n                        {{ (sItem.info.date.probable_inspection_date_start | date: \"MM-dd\") + \" — \" +\n                        (sItem.info.date.probable_inspection_date_end ? (sItem.info.date.probable_inspection_date_end |\n                        date: \"MM-dd\") : \"\") }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\".9\">\n                        {{ sItem.early_estimated_loading_time | date: \"MM-dd\" }}\n                    </ion-col>\n\n                    <ion-col align-self-center [size]=\"0.8\">\n                        {{ sItem.data[0].factory_contacts }}\n                    </ion-col>\n                    <ion-col align-self-center [size]=\"1.35\">\n                        {{ sItem.data[0].mobil_phone ? sItem.data[0].mobil_phone : \"暂无\" }}\n                    </ion-col>\n                    <ion-col\n                        align-self-center\n                        [size]=\"0.95\"\n                        class=\"ion-col-no-pad\"\n                        fxLayout=\"row\"\n                        fxLayoutAlign=\"start start\"\n                    >\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"toContract(sItem.data)\">详情</ion-button>\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"inspectOp(sItem,item)\">验货员</ion-button>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-card-content>\n    </ion-card>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n        <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"正在加载\"> </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n    <p *ngIf=\"!inspectGroup.length\" class=\"text-c \">暂无数据</p>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/sku-description/sku-description.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspect-task/sku-description/sku-description.component.html ***!
  \*************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/inspect-contract\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>SKU描述</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card mode=\"ios\" class=\"factory\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">任务信息</ion-card-title>\n        </ion-card-header>\n        <ion-item class=\"activated\">\n            <ion-icon name=\"contract\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>采购合同号</ion-label>\n            <ion-text>{{ data.contract_no }}</ion-text>\n        </ion-item>\n    </ion-card>\n\n    <ion-card class=\"contract\" mode=\"ios\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">SKU列表</ion-card-title>\n        </ion-card-header>\n\n        <ion-grid class=\"list\">\n            <ion-row>\n                <ion-col align-self-center size=\"1.5\">货号</ion-col>\n                <ion-col size=\"1\">缩略图</ion-col>\n                <ion-col align-self-center size=\"2.5\">中文名称</ion-col>\n                <ion-col align-self-center size=\"1.4\">验货数</ion-col>\n                <ion-col align-self-center size=\"1.4\">必验数</ion-col>\n                <ion-col align-self-center size=\"1.4\">箱数</ion-col>\n                <ion-col align-self-center size=\"1.4\">箱率</ion-col>\n                <ion-col align-self-center size=\"1.4\">操作</ion-col>\n            </ion-row>\n\n            <ion-row *ngFor=\"let item of data.sku_desc; let i = index\">\n                <ion-col align-self-center size=\"1.5\">{{ item.sku }}</ion-col>\n                <ion-col imgGallery align-self-center size=\"1\">\n                    <img class=\"thumbnail\" [src]=\"imgOrigin + item.pic[0]\" alt=\"\" />\n                </ion-col>\n                <ion-col align-self-center size=\"2.5\">{{ item.sku_chinese_name }}</ion-col>\n                <ion-col align-self-center size=\"1.4\">{{ item.quantity }}</ion-col>\n                <ion-col align-self-center size=\"1.4\">{{ item.must_quantity ? item.must_quantity : '暂无' }}</ion-col>\n                <ion-col align-self-center size=\"1.4\">{{ item.container_num }}</ion-col>\n                <ion-col align-self-center size=\"1.4\">{{ item.rate_container }}</ion-col>\n                <!-- <ion-col size=\"2.5\" align-self-center>{{\n            item.description ? item.description : \"暂无\"\n          }}</ion-col> -->\n                <ion-col align-self-center class=\"ion-col-no-pad\" size=\"1.4\">\n                    <ion-button color=\"primary\" fill=\"clear\" size=\"small\" (click)=\"toSkuDetail(item)\">详情</ion-button>\n                    <ion-button color=\"primary\" fill=\"clear\" size=\"small\" (click)=\"inspectOp(item, i)\"\n                        >验货员</ion-button\n                    >\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/sku-detail/sku-detail.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspect-task/sku-detail/sku-detail.page.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-button color=\"light\" fill=\"clear\" (click)=\"inspectOp()\" size=\"small\">\n                验货员操作\n            </ion-button>\n            <ion-back-button defaultHref=\"/sku-desc\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n\n        <ion-title>SKU:{{ data.sku }}</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <app-sku-info [sku]=\"data\">\n        <ion-grid class=\"inspect-description\">\n            <ion-row *ngFor=\"let item of data.inspection_task_desc;let i =index\">\n                <ion-col size=\"1.8\" align-self-center>\n                    {{ '质检备注.' + (i + 1) }}\n                </ion-col>\n                <ion-col\n                    size=\"8.72\"\n                    align-self-left\n                    [ngClass]=\"{'no-border-right':i != data.inspection_task_desc.length}\"\n                >\n                    <input type=\"text\" [value]=\"item\" placeholder=\"请输入质检备注\" />\n                    <!-- [(ngModel)]=\"item\"    TODO-->\n                </ion-col>\n                <ion-col size=\"1.46\" align-self-center>\n                    <ion-button\n                        *ngIf=\"(i+1) == data.inspection_task_desc.length\"\n                        color=\"primary\"\n                        size=\"small\"\n                        (click)=\"data.inspection_task_desc.push('')\"\n                    >\n                        <ion-icon\n                            name=\"add-circle-outline\"\n                            *ngIf=\"(i+1) == data.inspection_task_desc.length\"\n                            mode=\"ios\"\n                            (click)=\"data.inspection_task_desc.push('')\"\n                        ></ion-icon>\n                    </ion-button>\n                    <ion-button\n                        *ngIf=\"(i+1) == data.inspection_task_desc.length\"\n                        color=\"primary\"\n                        size=\"small\"\n                        (click)=\"addInspectDesc()\"\n                        >提交</ion-button\n                    >\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </app-sku-info>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspector-setting/inspector-setting.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspector-setting/inspector-setting.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-button color=\"light\" fill=\"clear\" (click)=\"inspectOp()\" size=\"small\">验货员操作</ion-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"home\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>验货员操作</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card mode=\"ios\">\n        <ion-item class=\"activated\">\n            <ion-icon name=\"contract\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>采购合同号</ion-label>\n            <ion-text>{{ data.contract_no }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-icon name=\"list\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>验货SKU数</ion-label>\n            <ion-text>{{ data.quantity }}</ion-text>\n        </ion-item>\n\n        <ion-item class=\"activated\">\n            <ion-icon name=\"at\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>是否与工厂联系</ion-label>\n            <ion-text>{{ data.is_contacked_factory ? '是' : '否' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-icon name=\"radio-button-off\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>是否购买车票</ion-label>\n            <ion-text>{{ data.is_bought_ticket ? '是' : '否' }}</ion-text>\n        </ion-item>\n\n        <ion-item>\n            <ion-icon name=\"map\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>验货工厂是否曾经验过 </ion-label>\n            <ion-text>{{ data.is_inspected_factory ? '是' : '否' }}</ion-text>\n        </ion-item>\n\n        <!-- <ion-item>\n      <ion-icon name=\"paper-plane\" slot=\"start\" mode=\"ios\"></ion-icon>\n      <ion-label>验货产品是否曾经验过 </ion-label>\n      <ion-text>{{ data.is_inspected_product ? \"是\" : \"否\" }}</ion-text>\n    </ion-item> -->\n\n        <ion-item>\n            <ion-icon name=\"pin\" slot=\"start\" mode=\"ios\"></ion-icon>\n            <ion-label>是否规范好时间路线 </ion-label>\n            <ion-text>{{ data.is_plan_date ? '是' : '否' }}</ion-text>\n        </ion-item>\n\n        <!-- <ion-item>\n      <ion-icon name=\"trending-down\" slot=\"start\" mode=\"ios\"></ion-icon>\n      <ion-label>是否熟悉要求 </ion-label>\n      <ion-text>{{ data.is_know_demand ? \"是\" : \"否\" }}</ion-text>\n    </ion-item> -->\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  position: relative;\n  --background: #f2f2f2;\n}\n\n.sku-info {\n  background: #f2f2f2;\n  padding: 0 2vh 2vh 2vh;\n  position: -webkit-sticky;\n  position: sticky;\n  top: 200px;\n  left: 0;\n  height: 100%;\n  overflow-x: hidden;\n}\n\n.ml-1 {\n  margin-left: 0.5%;\n}\n\n.mr-1 {\n  margin-right: 0.5%;\n}\n\n.title-panel ion-card {\n  background: #fff;\n  text-align: center;\n}\n\n.title-panel ion-card ion-card-title {\n  font-size: 18px;\n}\n\n.title {\n  padding: 15px;\n  width: 100%;\n  background: #fff;\n  color: #666666;\n}\n\nion-grid {\n  background: #fff;\n  font-size: 14px;\n}\n\n.ion-col-no-pad {\n  padding: 0 !important;\n  padding-right: 0 !important;\n}\n\nion-row {\n  border-top: 1px solid #f0f0f0;\n  border-left: 1px solid #f0f0f0;\n}\n\nion-row:last-child {\n  border-bottom: 1px solid #f0f0f0;\n}\n\nion-col {\n  border-right: 1px solid #f0f0f0;\n}\n\nion-row ion-button {\n  margin: 0 !important;\n  --padding-start: 0;\n  --padding-end: 5px;\n}\n\n.factory ion-card-header,\n.contract ion-card-header {\n  background: #fafafa;\n}\n\n.factory ion-card-header ion-card-title,\n.contract ion-card-header ion-card-title {\n  font-weight: bold;\n}\n\n.factory ion-grid,\n.contract ion-grid {\n  padding-bottom: 10px;\n}\n\n.factory ion-item {\n  --color: #2b2b2b;\n}\n\n.inner {\n  width: 50%;\n  --inner-padding-end: 0;\n  --inner-padding-start: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  --border-color: transparent;\n}\n\nion-item .inner:last-child {\n  --padding-start: 40px;\n}\n\nion-item .inner:first-child {\n  --padding-end: 40px;\n}\n\n:host ::ng-deep .item-inner {\n  border: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbnNwZWN0LXRhc2svaW5zcGVjdC1jb250cmFjdC9pbnNwZWN0LWNvbnRyYWN0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW5zcGVjdC10YXNrL2luc3BlY3QtY29udHJhY3QvaW5zcGVjdC1jb250cmFjdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLHFCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0JBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxPQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDRUo7O0FEQUE7RUFDSSxpQkFBQTtBQ0dKOztBRERBO0VBQ0ksa0JBQUE7QUNJSjs7QURBSTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNHUjs7QURGUTtFQUNJLGVBQUE7QUNJWjs7QURBQTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDR0o7O0FEQUE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUNHSjs7QURBQTtFQUNJLHFCQUFBO0VBQ0EsMkJBQUE7QUNHSjs7QURBQTtFQUNJLDZCQUFBO0VBQ0EsOEJBQUE7QUNHSjs7QUREQTtFQUNJLGdDQUFBO0FDSUo7O0FERkE7RUFDSSwrQkFBQTtBQ0tKOztBREZJO0VBQ0ksb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDS1I7O0FEQ0k7O0VBQ0ksbUJBQUE7QUNHUjs7QURGUTs7RUFDSSxpQkFBQTtBQ0taOztBREZJOztFQUNJLG9CQUFBO0FDS1I7O0FEQUk7RUFDSSxnQkFBQTtBQ0dSOztBRENBO0VBQ0ksVUFBQTtFQUNBLHNCQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7QUNFSjs7QURFSTtFQUNJLHFCQUFBO0FDQ1I7O0FEQ0k7RUFDSSxtQkFBQTtBQ0NSOztBREdBO0VBQ0ksb0JBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luc3BlY3QtdGFzay9pbnNwZWN0LWNvbnRyYWN0L2luc3BlY3QtY29udHJhY3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG59XG4uc2t1LWluZm8ge1xuICAgIGJhY2tncm91bmQ6ICNmMmYyZjI7XG4gICAgcGFkZGluZzogMCAydmggMnZoIDJ2aDtcbiAgICBwb3NpdGlvbjogLXdlYmtpdC1zdGlja3k7XG4gICAgcG9zaXRpb246IHN0aWNreTtcbiAgICB0b3A6IDIwMHB4O1xuICAgIGxlZnQ6IDA7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbn1cbi5tbC0xIHtcbiAgICBtYXJnaW4tbGVmdDogMC41JTtcbn1cbi5tci0xIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDAuNSU7XG59XG5cbi50aXRsZS1wYW5lbCB7XG4gICAgaW9uLWNhcmQge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGlvbi1jYXJkLXRpdGxlIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgfVxuICAgIH1cbn1cbi50aXRsZSB7XG4gICAgcGFkZGluZzogMTVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGNvbG9yOiByZ2IoMTAyLCAxMDIsIDEwMik7XG59XG5cbmlvbi1ncmlkIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tcm93IHtcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2YwZjBmMDtcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNmMGYwZjA7XG59XG5pb24tcm93Omxhc3QtY2hpbGQge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjBmMGYwO1xufVxuaW9uLWNvbCB7XG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2YwZjBmMDtcbn1cbmlvbi1yb3cge1xuICAgIGlvbi1idXR0b24ge1xuICAgICAgICBtYXJnaW46IDAgIWltcG9ydGFudDtcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgICAgICAtLXBhZGRpbmctZW5kOiA1cHg7XG4gICAgfVxufVxuXG4uZmFjdG9yeSxcbi5jb250cmFjdCB7XG4gICAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZhZmFmYTtcbiAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaW9uLWdyaWQge1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICB9XG59XG5cbi5mYWN0b3J5IHtcbiAgICBpb24taXRlbSB7XG4gICAgICAgIC0tY29sb3I6ICMyYjJiMmI7XG4gICAgfVxufVxuXG4uaW5uZXIge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbiAgICAtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDA7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgIC0tcGFkZGluZy1lbmQ6IDA7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG5pb24taXRlbSB7XG4gICAgLmlubmVyOmxhc3QtY2hpbGQge1xuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDQwcHg7XG4gICAgfVxuICAgIC5pbm5lcjpmaXJzdC1jaGlsZCB7XG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDQwcHg7XG4gICAgfVxufVxuXG46aG9zdCA6Om5nLWRlZXAgLml0ZW0taW5uZXIge1xuICAgIGJvcmRlcjogMCAhaW1wb3J0YW50O1xufVxuIiwiaW9uLWNvbnRlbnQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbn1cblxuLnNrdS1pbmZvIHtcbiAgYmFja2dyb3VuZDogI2YyZjJmMjtcbiAgcGFkZGluZzogMCAydmggMnZoIDJ2aDtcbiAgcG9zaXRpb246IC13ZWJraXQtc3RpY2t5O1xuICBwb3NpdGlvbjogc3RpY2t5O1xuICB0b3A6IDIwMHB4O1xuICBsZWZ0OiAwO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbn1cblxuLm1sLTEge1xuICBtYXJnaW4tbGVmdDogMC41JTtcbn1cblxuLm1yLTEge1xuICBtYXJnaW4tcmlnaHQ6IDAuNSU7XG59XG5cbi50aXRsZS1wYW5lbCBpb24tY2FyZCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi50aXRsZS1wYW5lbCBpb24tY2FyZCBpb24tY2FyZC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLnRpdGxlIHtcbiAgcGFkZGluZzogMTVweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGNvbG9yOiAjNjY2NjY2O1xufVxuXG5pb24tZ3JpZCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1yb3cge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgI2YwZjBmMDtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZjBmMGYwO1xufVxuXG5pb24tcm93Omxhc3QtY2hpbGQge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2YwZjBmMDtcbn1cblxuaW9uLWNvbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG59XG5cbmlvbi1yb3cgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gIC0tcGFkZGluZy1lbmQ6IDVweDtcbn1cblxuLmZhY3RvcnkgaW9uLWNhcmQtaGVhZGVyLFxuLmNvbnRyYWN0IGlvbi1jYXJkLWhlYWRlciB7XG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XG59XG4uZmFjdG9yeSBpb24tY2FyZC1oZWFkZXIgaW9uLWNhcmQtdGl0bGUsXG4uY29udHJhY3QgaW9uLWNhcmQtaGVhZGVyIGlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4uZmFjdG9yeSBpb24tZ3JpZCxcbi5jb250cmFjdCBpb24tZ3JpZCB7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4uZmFjdG9yeSBpb24taXRlbSB7XG4gIC0tY29sb3I6ICMyYjJiMmI7XG59XG5cbi5pbm5lciB7XG4gIHdpZHRoOiA1MCU7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAtLXBhZGRpbmctZW5kOiAwO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1pdGVtIC5pbm5lcjpsYXN0LWNoaWxkIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA0MHB4O1xufVxuaW9uLWl0ZW0gLmlubmVyOmZpcnN0LWNoaWxkIHtcbiAgLS1wYWRkaW5nLWVuZDogNDBweDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5pdGVtLWlubmVyIHtcbiAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.ts ***!
  \******************************************************************************/
/*! exports provided: InspectContractPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectContractPage", function() { return InspectContractPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_screen_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/screen.service */ "./src/app/services/screen.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let InspectContractPage = class InspectContractPage {
    constructor(storage, screen, router) {
        this.storage = storage;
        this.screen = screen;
        this.router = router;
        this.data = {
            contract_id: null,
            contract_no: '',
            id: null,
        };
        this.screenAngle = this.screen.screenAngle;
    }
    ngOnInit() {
        this.screen.onResize.subscribe(res => (this.screenAngle = res));
        this.data = this.storage.get('CURRENT_INSPECT_GROUP');
        console.log(this.data);
    }
    ionViewWillEnter() {
        this.data = this.storage.get('CURRENT_INSPECT_GROUP');
    }
    toSkuDesc(p) {
        this.storage.set('CURRENT_INSPECT_CONTRACT', p);
        this.router.navigate(['sku-desc']);
    }
};
InspectContractPage.ctorParameters = () => [
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"] },
    { type: _services_screen_service__WEBPACK_IMPORTED_MODULE_1__["ScreenService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
InspectContractPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-inspect-contract',
        template: __webpack_require__(/*! raw-loader!./inspect-contract.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.html"),
        styles: [__webpack_require__(/*! ./inspect-contract.page.scss */ "./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"], _services_screen_service__WEBPACK_IMPORTED_MODULE_1__["ScreenService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
], InspectContractPage);



/***/ }),

/***/ "./src/app/pages/inspect-task/inspect-task.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/inspect-task/inspect-task.module.ts ***!
  \***********************************************************/
/*! exports provided: InspectTaskPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectTaskPageModule", function() { return InspectTaskPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _directives_directive_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../directives/directive.module */ "./src/app/directives/directive.module.ts");
/* harmony import */ var _widget_widget_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../widget/widget.module */ "./src/app/widget/widget.module.ts");
/* harmony import */ var _pipe_show_factory_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../pipe/show-factory.pipe */ "./src/app/pipe/show-factory.pipe.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _inspect_task_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./inspect-task.page */ "./src/app/pages/inspect-task/inspect-task.page.ts");
/* harmony import */ var _sku_detail_sku_detail_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./sku-detail/sku-detail.page */ "./src/app/pages/inspect-task/sku-detail/sku-detail.page.ts");
/* harmony import */ var _inspect_contract_inspect_contract_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./inspect-contract/inspect-contract.page */ "./src/app/pages/inspect-task/inspect-contract/inspect-contract.page.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm2015/flex-layout.js");
/* harmony import */ var _inspector_setting_inspector_setting_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../inspector-setting/inspector-setting.component */ "./src/app/pages/inspector-setting/inspector-setting.component.ts");
/* harmony import */ var _sku_description_sku_description_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./sku-description/sku-description.component */ "./src/app/pages/inspect-task/sku-description/sku-description.component.ts");















const routes = [
    {
        path: 'inspect-task',
        component: _inspect_task_page__WEBPACK_IMPORTED_MODULE_9__["InspectTaskPage"],
    },
    {
        path: 'inspect-contract',
        component: _inspect_contract_inspect_contract_page__WEBPACK_IMPORTED_MODULE_11__["InspectContractPage"],
    },
    {
        path: 'sku-detail',
        component: _sku_detail_sku_detail_page__WEBPACK_IMPORTED_MODULE_10__["SkuDetailPage"],
    },
    {
        path: 'sku-desc',
        component: _sku_description_sku_description_component__WEBPACK_IMPORTED_MODULE_14__["SkuDescriptionComponent"],
    },
    {
        path: 'inspector-setting/:cid',
        component: _inspector_setting_inspector_setting_component__WEBPACK_IMPORTED_MODULE_13__["InspectorSettingComponent"],
    },
];
let InspectTaskPageModule = class InspectTaskPageModule {
};
InspectTaskPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"],
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_12__["FlexLayoutModule"],
            _widget_widget_module__WEBPACK_IMPORTED_MODULE_2__["WidgetModule"],
            _directives_directive_module__WEBPACK_IMPORTED_MODULE_1__["DirectiveModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterModule"].forChild(routes),
        ],
        declarations: [
            _inspect_task_page__WEBPACK_IMPORTED_MODULE_9__["InspectTaskPage"],
            _pipe_show_factory_pipe__WEBPACK_IMPORTED_MODULE_3__["ShowFactoryPipe"],
            _sku_detail_sku_detail_page__WEBPACK_IMPORTED_MODULE_10__["SkuDetailPage"],
            _inspect_contract_inspect_contract_page__WEBPACK_IMPORTED_MODULE_11__["InspectContractPage"],
            _inspector_setting_inspector_setting_component__WEBPACK_IMPORTED_MODULE_13__["InspectorSettingComponent"],
            _sku_description_sku_description_component__WEBPACK_IMPORTED_MODULE_14__["SkuDescriptionComponent"],
        ],
    })
], InspectTaskPageModule);

/**
 * session description
 * CURRENT_INSPECT_GROUP           =>       inspect group of current  first level data
 * CURRENT_INSPECT_CONTRACT        =>       inspect contract of current  second level data
 * SKU_INFO                        =>       inspect sku of contract  three level data
 */


/***/ }),

/***/ "./src/app/pages/inspect-task/inspect-task.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/inspect-task/inspect-task.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-col {\n  height: 100%;\n}\n\n.ion-col-no-pad {\n  padding: 0 !important;\n  padding-right: 0 !important;\n}\n\nion-row.title {\n  font-weight: bold;\n  background: #f7f7f7;\n}\n\n.card-header {\n  font-size: 14px !important;\n}\n\n.card-header span {\n  color: #636363;\n}\n\nion-card {\n  background: #f5f6f9;\n}\n\nion-card > ion-item {\n  --background: #ebecee;\n}\n\nion-card .card-content-md {\n  padding-right: 0 !important;\n  padding-left: 0 !important;\n}\n\nion-card ion-grid {\n  padding: 0 !important;\n}\n\n.text-r {\n  text-align: right !important;\n}\n\n.text-c {\n  text-align: center !important;\n}\n\n.pl-5 {\n  font-weight: bold;\n  padding-left: 5px !important;\n}\n\nion-button {\n  margin: 0 !important;\n  --padding-start: 5px;\n  --padding-end: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbnNwZWN0LXRhc2svaW5zcGVjdC10YXNrLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW5zcGVjdC10YXNrL2luc3BlY3QtdGFzay5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FDQ0o7O0FER0E7RUFDSSxxQkFBQTtFQUNBLDJCQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSwwQkFBQTtBQ0FKOztBRENJO0VBQ0ksY0FBQTtBQ0NSOztBREdBO0VBQ0ksbUJBQUE7QUNBSjs7QURDSTtFQUNJLHFCQUFBO0FDQ1I7O0FEQ0k7RUFDSSwyQkFBQTtFQUNBLDBCQUFBO0FDQ1I7O0FEQ0k7RUFDSSxxQkFBQTtBQ0NSOztBREdBO0VBQ0ksNEJBQUE7QUNBSjs7QURHQTtFQUNJLDZCQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLDRCQUFBO0FDQUo7O0FER0E7RUFDSSxvQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luc3BlY3QtdGFzay9pbnNwZWN0LXRhc2sucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICNlYmViZWJcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xufVxuXG5pb24tcm93LnRpdGxlIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xufVxuXG4uY2FyZC1oZWFkZXJ7XG4gICAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG4gICAgc3BhbntcbiAgICAgICAgY29sb3I6ICM2MzYzNjM7XG4gICAgfVxufVxuXG5pb24tY2FyZCB7XG4gICAgYmFja2dyb3VuZDogI2Y1ZjZmOTtcbiAgICA+IGlvbi1pdGVtIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZWJlY2VlO1xuICAgIH1cbiAgICAuY2FyZC1jb250ZW50LW1kIHtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDAgIWltcG9ydGFudDtcbiAgICB9XG4gICAgaW9uLWdyaWQge1xuICAgICAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgfVxufVxuXG4udGV4dC1yIHtcbiAgICB0ZXh0LWFsaWduOiByaWdodCAhaW1wb3J0YW50O1xufVxuXG4udGV4dC1jIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuLnBsLTV7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogNXB4O1xufVxuXG5pb24tY2FyZC1jb250ZW50e1xuICAgIC8vIHBhZGRpbmctdG9wOiAwICFpbXBvcnRhbnQ7XG59IiwiaW9uLWNvbCB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLXJpZ2h0OiAwICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1yb3cudGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbn1cblxuLmNhcmQtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG59XG4uY2FyZC1oZWFkZXIgc3BhbiB7XG4gIGNvbG9yOiAjNjM2MzYzO1xufVxuXG5pb24tY2FyZCB7XG4gIGJhY2tncm91bmQ6ICNmNWY2Zjk7XG59XG5pb24tY2FyZCA+IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZWJlY2VlO1xufVxuaW9uLWNhcmQgLmNhcmQtY29udGVudC1tZCB7XG4gIHBhZGRpbmctcmlnaHQ6IDAgIWltcG9ydGFudDtcbiAgcGFkZGluZy1sZWZ0OiAwICFpbXBvcnRhbnQ7XG59XG5pb24tY2FyZCBpb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbn1cblxuLnRleHQtciB7XG4gIHRleHQtYWxpZ246IHJpZ2h0ICFpbXBvcnRhbnQ7XG59XG5cbi50ZXh0LWMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuLnBsLTUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctc3RhcnQ6IDVweDtcbiAgLS1wYWRkaW5nLWVuZDogNXB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/inspect-task/inspect-task.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/inspect-task/inspect-task.page.ts ***!
  \*********************************************************/
/*! exports provided: InspectTaskPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectTaskPage", function() { return InspectTaskPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_screen_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/screen.service */ "./src/app/services/screen.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/widget/inspect-setting-box/inspect-setting-box.component */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts");








let InspectTaskPage = class InspectTaskPage {
    constructor(inspectService, effectCtrl, screen, storage, router) {
        this.inspectService = inspectService;
        this.effectCtrl = effectCtrl;
        this.screen = screen;
        this.storage = storage;
        this.router = router;
        this.inspectGroup = [];
        this.getListParams = {
            keywords: 'factory_name',
            value: '',
            page: 1,
        };
        this.screenType = this.screen.screenAngle;
        this.screen.onResize.subscribe(res => (this.screenType = res));
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getListParams.page = 1;
        this.inspectService.getTaskList(this.getListParams).subscribe(res => {
            this.inspectGroup = res.data;
            this.getListParams.page = res.current_page + 1;
        });
        this.storage.remove('CURRENT_INSPECT_GROUP');
    }
    toContract(p) {
        this.storage.set('CURRENT_INSPECT_GROUP', p);
        this.router.navigate(['inspect-contract']);
    }
    inspectOp(p, e) {
        let option = {
            component: src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_7__["InspectSettingBoxComponent"],
            cssClass: 'custom-modal-sku',
            mode: 'ios',
            componentProps: { contract: p.data[0], type: 'group', apply_id: p.data[0].id },
        };
        this.effectCtrl.showModal(option, (data) => {
            p.data[0] = data.refresh;
        });
    }
    getList() {
        this.inspectService.getTaskList(this.getListParams).subscribe(res => {
            this.inspectGroup = this.inspectGroup.concat(res.data);
            this.getListParams.page = res.current_page + 1;
        });
    }
    loadData(event) {
        this.inspectService.getTaskList(this.getListParams).subscribe(res => {
            if (res.data && res.data.length) {
                this.inspectGroup = this.inspectGroup.concat(res.data);
                this.getListParams.page = res.current_page + 1;
            }
            else {
                this.effectCtrl.showToast({
                    message: '别刷了，没有数据啦！',
                    color: 'danger',
                });
            }
            event.target.complete();
        });
    }
    factoryChange() {
        this.getListParams.page = 1;
        this.inspectService.getTaskList(this.getListParams).subscribe(res => {
            if (res.data && res.data.length) {
                this.inspectGroup = res.data;
                this.getListParams.page = res.current_page + 1;
            }
            else {
                this.inspectGroup = [];
            }
        });
    }
};
InspectTaskPage.ctorParameters = () => [
    { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"] },
    { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
    { type: _services_screen_service__WEBPACK_IMPORTED_MODULE_3__["ScreenService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
InspectTaskPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-inspect-task',
        template: __webpack_require__(/*! raw-loader!./inspect-task.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/inspect-task.page.html"),
        styles: [__webpack_require__(/*! ./inspect-task.page.scss */ "./src/app/pages/inspect-task/inspect-task.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"],
        _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
        _services_screen_service__WEBPACK_IMPORTED_MODULE_3__["ScreenService"],
        _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]])
], InspectTaskPage);



/***/ }),

/***/ "./src/app/pages/inspect-task/sku-description/sku-description.component.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/inspect-task/sku-description/sku-description.component.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".list {\n  color: #666666;\n  padding: 0 15px 15px 15px;\n}\n.list ion-row:first-child {\n  border-top: 1px solid #f3f3f3;\n}\n.list ion-row {\n  border-left: 1px solid #f3f3f3;\n  border-bottom: 1px solid #f3f3f3;\n}\n.list ion-col {\n  border-right: 1px solid #f3f3f3;\n}\n.list ion-col ion-button {\n  --padding-start: 5px;\n  margin: 0 !important;\n}\n.ion-col-no-pad {\n  padding: 0 !important;\n  padding-right: 0 !important;\n}\n.factory ion-card-header,\n.contract ion-card-header {\n  background: #fafafa;\n}\n.factory ion-card-header ion-card-title,\n.contract ion-card-header ion-card-title {\n  font-weight: bold;\n}\n.factory ion-grid,\n.contract ion-grid {\n  padding-bottom: 10px;\n}\n.thumbnail {\n  width: 30px;\n  height: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbnNwZWN0LXRhc2svc2t1LWRlc2NyaXB0aW9uL3NrdS1kZXNjcmlwdGlvbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW5zcGVjdC10YXNrL3NrdS1kZXNjcmlwdGlvbi9za3UtZGVzY3JpcHRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EseUJBQUE7QUNDSjtBREFJO0VBQ0ksNkJBQUE7QUNFUjtBREFJO0VBQ0ksOEJBQUE7RUFDQSxnQ0FBQTtBQ0VSO0FEQUk7RUFFSSwrQkFBQTtBQ0NSO0FEQVE7RUFDSSxvQkFBQTtFQUNBLG9CQUFBO0FDRVo7QURHQTtFQUNJLHFCQUFBO0VBQ0EsMkJBQUE7QUNBSjtBREtJOztFQUNJLG1CQUFBO0FDRFI7QURFUTs7RUFDSSxpQkFBQTtBQ0NaO0FERUk7O0VBQ0ksb0JBQUE7QUNDUjtBREdBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luc3BlY3QtdGFzay9za3UtZGVzY3JpcHRpb24vc2t1LWRlc2NyaXB0aW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxpc3Qge1xuICAgIGNvbG9yOiByZ2IoMTAyLCAxMDIsIDEwMik7XG4gICAgcGFkZGluZzogMCAxNXB4IDE1cHggMTVweDtcbiAgICBpb24tcm93OmZpcnN0LWNoaWxkIHtcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNmM2YzZjM7XG4gICAgfVxuICAgIGlvbi1yb3cge1xuICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNmM2YzZjM7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjNmM2YzO1xuICAgIH1cbiAgICBpb24tY29sIHtcbiAgICAgICAgLy8gYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmM2YzZjM7XG4gICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmM2YzZjM7XG4gICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XG4gICAgICAgICAgICBtYXJnaW46IDAgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmlvbi1jb2wtbm8tcGFkIHtcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1yaWdodDogMCAhaW1wb3J0YW50O1xufVxuXG4uZmFjdG9yeSxcbi5jb250cmFjdCB7XG4gICAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZhZmFmYTtcbiAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaW9uLWdyaWQge1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICB9XG59XG5cbi50aHVtYm5haWwge1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogMzBweDtcbn1cbiIsIi5saXN0IHtcbiAgY29sb3I6ICM2NjY2NjY7XG4gIHBhZGRpbmc6IDAgMTVweCAxNXB4IDE1cHg7XG59XG4ubGlzdCBpb24tcm93OmZpcnN0LWNoaWxkIHtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNmM2YzZjM7XG59XG4ubGlzdCBpb24tcm93IHtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZjNmM2YzO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2YzZjNmMztcbn1cbi5saXN0IGlvbi1jb2wge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZjNmM2YzO1xufVxuLmxpc3QgaW9uLWNvbCBpb24tYnV0dG9uIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4uaW9uLWNvbC1uby1wYWQge1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctcmlnaHQ6IDAgIWltcG9ydGFudDtcbn1cblxuLmZhY3RvcnkgaW9uLWNhcmQtaGVhZGVyLFxuLmNvbnRyYWN0IGlvbi1jYXJkLWhlYWRlciB7XG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XG59XG4uZmFjdG9yeSBpb24tY2FyZC1oZWFkZXIgaW9uLWNhcmQtdGl0bGUsXG4uY29udHJhY3QgaW9uLWNhcmQtaGVhZGVyIGlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4uZmFjdG9yeSBpb24tZ3JpZCxcbi5jb250cmFjdCBpb24tZ3JpZCB7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4udGh1bWJuYWlsIHtcbiAgd2lkdGg6IDMwcHg7XG4gIGhlaWdodDogMzBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/inspect-task/sku-description/sku-description.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/inspect-task/sku-description/sku-description.component.ts ***!
  \*********************************************************************************/
/*! exports provided: SkuDescriptionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuDescriptionComponent", function() { return SkuDescriptionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/widget/inspect-setting-box/inspect-setting-box.component */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");







let SkuDescriptionComponent = class SkuDescriptionComponent {
    constructor(storage, router, effectCtrl) {
        this.storage = storage;
        this.router = router;
        this.effectCtrl = effectCtrl;
        this.imgOrigin = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].fileUrlPath;
    }
    ngOnInit() {
        this.data = this.storage.get('CURRENT_INSPECT_CONTRACT');
        console.log(this.data, '111111');
    }
    toSkuDetail(p) {
        this.storage.set('SKU_INFO', p);
        this.router.navigate(['sku-detail']);
    }
    inspectOp(p, i) {
        let option = {
            component: src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_5__["InspectSettingBoxComponent"],
            cssClass: 'custom-modal-sku',
            mode: 'ios',
            componentProps: { contract: p, type: 'skuList' },
        };
        this.effectCtrl.showModal(option, (data) => {
            this.data.sku_desc[i] = data.refresh;
            console.log(data);
        });
    }
};
SkuDescriptionComponent.ctorParameters = () => [
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
];
SkuDescriptionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-sku-description',
        template: __webpack_require__(/*! raw-loader!./sku-description.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/sku-description/sku-description.component.html"),
        styles: [__webpack_require__(/*! ./sku-description.component.scss */ "./src/app/pages/inspect-task/sku-description/sku-description.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
], SkuDescriptionComponent);



/***/ }),

/***/ "./src/app/pages/inspect-task/sku-detail/sku-detail.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/pages/inspect-task/sku-detail/sku-detail.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  padding-bottom: 20px;\n}\n\n.inspect-description {\n  background: #fff;\n  margin-top: 1vh;\n  font-size: 14px;\n}\n\n.inspect-description label {\n  margin-left: 5px;\n  margin-right: 10px;\n}\n\n.inspect-description textarea {\n  flex-grow: 1;\n  border-radius: 5px;\n  padding-left: 3px;\n  border-color: #f3f3f3;\n  height: 100px;\n  outline: none;\n  line-height: 16px;\n  color: #5e5e5e;\n  margin-right: 10px;\n}\n\nion-grid {\n  padding: 0;\n  border-bottom: 1px solid #f0f0f0;\n}\n\nion-grid ion-row {\n  border-top: 1px solid #f0f0f0;\n  border-left: 1px solid #f0f0f0;\n}\n\nion-grid ion-col {\n  color: #323232;\n  font-size: 14px;\n  border-right: 1px solid #f0f0f0;\n}\n\nion-grid ion-col input {\n  width: 100%;\n  border-radius: 5px;\n  outline: none;\n  line-height: 16px;\n  color: #5e5e5e;\n  padding: 3px;\n  height: 32px;\n  background: #f7f7f7;\n  border: 1px solid #f0f0f0;\n}\n\nion-grid ion-icon {\n  padding: 0;\n  font-size: 18px;\n}\n\nion-grid ion-col.content {\n  color: #5e5e5e;\n}\n\n.no-border-right {\n  border-right: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbnNwZWN0LXRhc2svc2t1LWRldGFpbC9za3UtZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW5zcGVjdC10YXNrL3NrdS1kZXRhaWwvc2t1LWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ0VKOztBRERJO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQ0dSOztBRERJO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNHUjs7QURDQTtFQUNJLFVBQUE7RUFDQSxnQ0FBQTtBQ0VKOztBRERJO0VBQ0ksNkJBQUE7RUFDQSw4QkFBQTtBQ0dSOztBREFJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSwrQkFBQTtBQ0VSOztBREFRO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQ0VaOztBREVJO0VBQ0ksVUFBQTtFQUNBLGVBQUE7QUNBUjs7QURFSTtFQUNJLGNBQUE7QUNBUjs7QURJQTtFQUNJLDZCQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9pbnNwZWN0LXRhc2svc2t1LWRldGFpbC9za3UtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cbi5pbnNwZWN0LWRlc2NyaXB0aW9uIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIG1hcmdpbi10b3A6IDF2aDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgbGFiZWwge1xuICAgICAgICBtYXJnaW4tbGVmdDogNXB4O1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgfVxuICAgIHRleHRhcmVhIHtcbiAgICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgIHBhZGRpbmctbGVmdDogM3B4O1xuICAgICAgICBib3JkZXItY29sb3I6ICNmM2YzZjM7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xuICAgICAgICBjb2xvcjogIzVlNWU1ZTtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIH1cbn1cblxuaW9uLWdyaWQge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgaW9uLXJvdyB7XG4gICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZjBmMGYwO1xuICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNmMGYwZjA7XG4gICAgfVxuXG4gICAgaW9uLWNvbCB7XG4gICAgICAgIGNvbG9yOiAjMzIzMjMyO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG5cbiAgICAgICAgaW5wdXQge1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICBvdXRsaW5lOiBub25lO1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE2cHg7XG4gICAgICAgICAgICBjb2xvcjogIzVlNWU1ZTtcbiAgICAgICAgICAgIHBhZGRpbmc6IDNweDtcbiAgICAgICAgICAgIGhlaWdodDogMzJweDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmN2Y3Zjc7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZjBmMGYwO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaW9uLWljb24ge1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgfVxuICAgIGlvbi1jb2wuY29udGVudCB7XG4gICAgICAgIGNvbG9yOiAjNWU1ZTVlO1xuICAgIH1cbn1cblxuLm5vLWJvcmRlci1yaWdodCB7XG4gICAgYm9yZGVyLXJpZ2h0OiBub25lICFpbXBvcnRhbnQ7XG59XG4iLCJpb24tY29udGVudCB7XG4gIHBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG4uaW5zcGVjdC1kZXNjcmlwdGlvbiB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIG1hcmdpbi10b3A6IDF2aDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLmluc3BlY3QtZGVzY3JpcHRpb24gbGFiZWwge1xuICBtYXJnaW4tbGVmdDogNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4uaW5zcGVjdC1kZXNjcmlwdGlvbiB0ZXh0YXJlYSB7XG4gIGZsZXgtZ3JvdzogMTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDNweDtcbiAgYm9yZGVyLWNvbG9yOiAjZjNmM2YzO1xuICBoZWlnaHQ6IDEwMHB4O1xuICBvdXRsaW5lOiBub25lO1xuICBsaW5lLWhlaWdodDogMTZweDtcbiAgY29sb3I6ICM1ZTVlNWU7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuaW9uLWdyaWQge1xuICBwYWRkaW5nOiAwO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2YwZjBmMDtcbn1cbmlvbi1ncmlkIGlvbi1yb3cge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgI2YwZjBmMDtcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZjBmMGYwO1xufVxuaW9uLWdyaWQgaW9uLWNvbCB7XG4gIGNvbG9yOiAjMzIzMjMyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNmMGYwZjA7XG59XG5pb24tZ3JpZCBpb24tY29sIGlucHV0IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgb3V0bGluZTogbm9uZTtcbiAgbGluZS1oZWlnaHQ6IDE2cHg7XG4gIGNvbG9yOiAjNWU1ZTVlO1xuICBwYWRkaW5nOiAzcHg7XG4gIGhlaWdodDogMzJweDtcbiAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbiAgYm9yZGVyOiAxcHggc29saWQgI2YwZjBmMDtcbn1cbmlvbi1ncmlkIGlvbi1pY29uIHtcbiAgcGFkZGluZzogMDtcbiAgZm9udC1zaXplOiAxOHB4O1xufVxuaW9uLWdyaWQgaW9uLWNvbC5jb250ZW50IHtcbiAgY29sb3I6ICM1ZTVlNWU7XG59XG5cbi5uby1ib3JkZXItcmlnaHQge1xuICBib3JkZXItcmlnaHQ6IG5vbmUgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/inspect-task/sku-detail/sku-detail.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/inspect-task/sku-detail/sku-detail.page.ts ***!
  \******************************************************************/
/*! exports provided: SkuDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuDetailPage", function() { return SkuDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/widget/inspect-setting-box/inspect-setting-box.component */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");






let SkuDetailPage = class SkuDetailPage {
    constructor(storage, inspectCtrl, pageEffect, el) {
        this.storage = storage;
        this.inspectCtrl = inspectCtrl;
        this.pageEffect = pageEffect;
        this.el = el;
        this.addDescParams = {
            apply_id: null,
            inspection_task_desc: [],
            sku: '',
        };
        this.addDescParams.apply_id = this.storage.get('CURRENT_INSPECT_CONTRACT').id;
    }
    ngOnInit() {
        this.data = this.storage.get('SKU_INFO');
    }
    ionViewWillEnter() {
        this.data.inspection_task_desc = this.data.inspection_task_desc ? this.data.inspection_task_desc : [''];
    }
    ionViewWillLeave() {
        this.storage.remove('SKU_INFO');
    }
    addInspectDesc() {
        let val = [];
        this.el.nativeElement.querySelectorAll('input').forEach(element => {
            val.push(element.value);
        });
        // this.addDescParams.inspection_task_desc = this.data.inspection_task_desc
        this.addDescParams.inspection_task_desc = val;
        this.addDescParams.sku = this.data.sku;
        this.inspectCtrl.addInspectionTaskDesc(this.addDescParams).subscribe(res => {
            this.pageEffect.showToast({
                message: res.message,
                color: 'success',
            });
            /**
             * because data is previous page not get meta data , so let meta data resize Assemble
             */
            let inspectContract = this.storage.get('CURRENT_INSPECT_CONTRACT');
            inspectContract.sku_desc.forEach((sku, i) => {
                if (sku.sku == this.data.sku) {
                    sku.inspection_task_desc = this.addDescParams.inspection_task_desc;
                }
            });
            this.storage.set('CURRENT_INSPECT_CONTRACT', inspectContract);
            this.storage.set('SKU_INFO', this.data);
        });
    }
    inputChange(p, i) {
        console.log(this.data.inspection_task_desc, p, i);
    }
    inspectOp() {
        let option = {
            component: src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_4__["InspectSettingBoxComponent"],
            cssClass: 'custom-modal-sku',
            mode: 'ios',
            componentProps: { contract: this.data, type: 'skuDetail' },
        };
        this.pageEffect.showModal(option, (data) => {
            this.data = data.refresh;
            console.log(data);
        });
    }
};
SkuDetailPage.ctorParameters = () => [
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"] },
    { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"] },
    { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }
];
SkuDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sku-detail',
        template: __webpack_require__(/*! raw-loader!./sku-detail.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspect-task/sku-detail/sku-detail.page.html"),
        styles: [__webpack_require__(/*! ./sku-detail.page.scss */ "./src/app/pages/inspect-task/sku-detail/sku-detail.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"],
        src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"],
        src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])
], SkuDetailPage);



/***/ }),

/***/ "./src/app/pages/inspector-setting/inspector-setting.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/inspector-setting/inspector-setting.component.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luc3BlY3Rvci1zZXR0aW5nL2luc3BlY3Rvci1zZXR0aW5nLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/inspector-setting/inspector-setting.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/inspector-setting/inspector-setting.component.ts ***!
  \************************************************************************/
/*! exports provided: InspectorSettingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectorSettingComponent", function() { return InspectorSettingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/widget/inspect-setting-box/inspect-setting-box.component */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts");






let InspectorSettingComponent = class InspectorSettingComponent {
    constructor(inspectCtrl, activeRoute, effectCtrl) {
        this.inspectCtrl = inspectCtrl;
        this.activeRoute = activeRoute;
        this.effectCtrl = effectCtrl;
        this.data = {
            contract_id: null,
            contract_no: '',
            id: null,
        };
        this.apply_id = null;
    }
    ngOnInit() {
        this.activeRoute.params.subscribe(params => {
            this.apply_id = params.cid;
            this.inspectCtrl.getInspectTaskById(params.cid).subscribe(res => (this.data = res.data));
        });
    }
    inspectOp() {
        let option = {
            component: src_app_widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_5__["InspectSettingBoxComponent"],
            cssClass: 'custom-modal-sku',
            mode: 'ios',
            componentProps: { contract: this.data, type: 'task', apply_id: this.apply_id },
        };
        this.effectCtrl.showModal(option, (data) => {
            this.data = data.refresh;
            console.log(data);
        });
    }
};
InspectorSettingComponent.ctorParameters = () => [
    { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
];
InspectorSettingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-inspector-setting',
        template: __webpack_require__(/*! raw-loader!./inspector-setting.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspector-setting/inspector-setting.component.html"),
        styles: [__webpack_require__(/*! ./inspector-setting.component.scss */ "./src/app/pages/inspector-setting/inspector-setting.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
], InspectorSettingComponent);



/***/ }),

/***/ "./src/app/pipe/show-factory.pipe.ts":
/*!*******************************************!*\
  !*** ./src/app/pipe/show-factory.pipe.ts ***!
  \*******************************************/
/*! exports provided: ShowFactoryPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShowFactoryPipe", function() { return ShowFactoryPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ShowFactoryPipe = class ShowFactoryPipe {
    transform(value, ...args) {
        let rval = '';
        value.info.forEach(factory => (rval += factory.factory_name + '、'));
        return rval;
    }
};
ShowFactoryPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'showFactory',
    })
], ShowFactoryPipe);



/***/ })

}]);
//# sourceMappingURL=pages-inspect-task-inspect-task-module-es2015.js.map