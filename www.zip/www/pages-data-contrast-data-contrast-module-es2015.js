(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-data-contrast-data-contrast-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/data-contrast/data-contrast.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/data-contrast/data-contrast.page.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>数据对比</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card mode=\"ios\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">SKU</ion-card-title>\n        </ion-card-header>\n        <ion-item class=\"high\">\n            <ion-label>选择工厂</ion-label>\n            <select class=\"select\" [(ngModel)]=\"currentFactory\">\n                <option value=\"\">全部</option>\n                <option *ngFor=\"let item of data\" [value]=\"item.apply_inspection_no\">{{item.factory_name}}</option>\n            </select>\n        </ion-item>\n\n        <ion-button fill='clear' expand=\"full\" *ngIf=\"!data || !data.length\" (click)=\"ionViewWillEnter()\">重新获取</ion-button>\n\n        <ion-item *ngFor=\"let item of (data | dataCompare:currentFactory)\" (click)=\"toDetail(item)\">\n            <ion-label>{{item.sku_chinese_name}}</ion-label>\n            <ion-note slot=\"end\">{{item.sku}}</ion-note>\n        </ion-item>\n        <p *ngIf=\"!data.length\" class=\"text-c \">暂无数据</p>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/data-contrast/detail/detail.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/data-contrast/detail/detail.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>对比详情</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-back-button defaultHref=\"/data-contrast\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card mode=\"ios\">\n        <ion-grid>\n            <ion-row class=\"header\">\n                <ion-col align-self-center size=\"4\">对比项</ion-col>\n                <ion-col align-self-center size=\"4\">系统</ion-col>\n                <ion-col align-self-center size=\"4\">数据</ion-col>\n            </ion-row>\n\n            <ion-row\n                *ngFor=\"let item of compareData; let i = index\"\n                [ngClass]=\"{ success: $any(item.compare_res) == 1, danger: $any(item.compare_res) == 2 }\"\n            >\n                <ion-col align-self-center size=\"4\">{{ item.chinese_name }}</ion-col>\n                <ion-col align-self-center size=\"4\">{{ item.system ? item.system : '暂无' }}</ion-col>\n                <ion-col class=\"align-self-center\" size=\"4\">\n                    <ng-container *ngIf=\"item.type == 'pic'\">\n                        <img\n                            *ngFor=\"let sItem of item.posted\"\n                            imgGallery\n                            [defaultImage]=\"'../assets/img/image-loading.jpg'\"\n                            [lazyLoad]=\"imgOrigin + sItem + '?random=' + random\"\n                        />\n                    </ng-container>\n                    <ng-container *ngIf=\"item.type == 'video'\">\n                        <video *ngFor=\"let sItem of item.posted\" [src]=\"imgOrigin + sItem\"></video>\n                    </ng-container>\n                    <div class=\"remark-box\" *ngIf=\"item.type == 'desc'\">\n                        <p *ngFor=\"let sItem of item.posted\">{{ sItem }}</p>\n                    </div>\n                    <div class=\"remark-box\" *ngIf=\"item.type == 'string'\">\n                        {{ item.posted }}\n                    </div>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/data-contrast/data-contrast.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/data-contrast/data-contrast.module.ts ***!
  \*************************************************************/
/*! exports provided: DataContrastPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataContrastPageModule", function() { return DataContrastPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail/detail.component */ "./src/app/pages/data-contrast/detail/detail.component.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm2015/flex-layout.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _data_contrast_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./data-contrast.page */ "./src/app/pages/data-contrast/data-contrast.page.ts");
/* harmony import */ var src_app_pipe_data_compare_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/pipe/data-compare.pipe */ "./src/app/pipe/data-compare.pipe.ts");
/* harmony import */ var _widget_widget_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../widget/widget.module */ "./src/app/widget/widget.module.ts");
/* harmony import */ var src_app_directives_directive_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/directives/directive.module */ "./src/app/directives/directive.module.ts");
/* harmony import */ var ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ng-lazyload-image */ "./node_modules/ng-lazyload-image/fesm2015/ng-lazyload-image.js");













const routes = [
    {
        path: 'data-contrast',
        component: _data_contrast_page__WEBPACK_IMPORTED_MODULE_8__["DataContrastPage"],
    },
    {
        path: 'data-contrast/detail/:contract_id/:apply_no/:sku',
        component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__["DetailComponent"],
    },
];
let DataContrastPageModule = class DataContrastPageModule {
};
DataContrastPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__["FlexLayoutModule"],
            ng_lazyload_image__WEBPACK_IMPORTED_MODULE_12__["LazyLoadImageModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild(routes),
            _widget_widget_module__WEBPACK_IMPORTED_MODULE_10__["WidgetModule"],
            src_app_directives_directive_module__WEBPACK_IMPORTED_MODULE_11__["DirectiveModule"],
        ],
        declarations: [_data_contrast_page__WEBPACK_IMPORTED_MODULE_8__["DataContrastPage"], src_app_pipe_data_compare_pipe__WEBPACK_IMPORTED_MODULE_9__["DataComparePipe"], _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__["DetailComponent"]],
    })
], DataContrastPageModule);



/***/ }),

/***/ "./src/app/pages/data-contrast/data-contrast.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/data-contrast/data-contrast.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".high {\n  color: #808080;\n}\n\n.select {\n  color: #777;\n  padding: 6px;\n  border-radius: 6px;\n  border-color: #cecece;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9kYXRhLWNvbnRyYXN0L2RhdGEtY29udHJhc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9kYXRhLWNvbnRyYXN0L2RhdGEtY29udHJhc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQ0NKOztBRENBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FDRUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9kYXRhLWNvbnRyYXN0L2RhdGEtY29udHJhc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhpZ2h7XG4gICAgY29sb3I6ICM4MDgwODA7XG59XG4uc2VsZWN0e1xuICAgIGNvbG9yOiAjNzc3O1xuICAgIHBhZGRpbmc6IDZweDtcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XG4gICAgYm9yZGVyLWNvbG9yOiAjY2VjZWNlO1xufSIsIi5oaWdoIHtcbiAgY29sb3I6ICM4MDgwODA7XG59XG5cbi5zZWxlY3Qge1xuICBjb2xvcjogIzc3NztcbiAgcGFkZGluZzogNnB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJvcmRlci1jb2xvcjogI2NlY2VjZTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/data-contrast/data-contrast.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/data-contrast/data-contrast.page.ts ***!
  \***********************************************************/
/*! exports provided: DataContrastPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataContrastPage", function() { return DataContrastPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_data_compare_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/data-compare.service */ "./src/app/services/data-compare.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");




let DataContrastPage = class DataContrastPage {
    constructor(dataCompare, router) {
        this.dataCompare = dataCompare;
        this.router = router;
        this.data = [];
        this.currentFactory = '';
    }
    ngOnInit() {
        this.dataCompare.getCompareBasicList().subscribe(res => {
            console.log(res);
            this.data = res;
        });
    }
    toDetail(sku) {
        console.log(sku);
        this.currentSku = sku;
        this.router.navigate(['data-contrast/detail', this.currentContract, this.currentApplyNo, sku.sku]);
    }
    ionViewWillEnter() {
        this.dataCompare.getCompareBasicList().subscribe(res => {
            this.data = res;
        });
    }
    get currentApplyNo() {
        let val;
        this.data.forEach(res => {
            res.contract_data.forEach(element => {
                element.sku.forEach(sku => {
                    if (sku.sku == this.currentSku.sku) {
                        val = res.apply_inspection_no;
                    }
                });
            });
        });
        return val;
    }
    get currentContract() {
        let val;
        this.data.forEach(res => {
            res.contract_data.forEach(element => {
                element.sku.forEach(sku => {
                    if (sku.sku == this.currentSku.sku) {
                        val = element.contract_id;
                    }
                });
            });
        });
        return val;
    }
};
DataContrastPage.ctorParameters = () => [
    { type: _services_data_compare_service__WEBPACK_IMPORTED_MODULE_2__["DataCompareService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
DataContrastPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-data-contrast',
        template: __webpack_require__(/*! raw-loader!./data-contrast.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/data-contrast/data-contrast.page.html"),
        styles: [__webpack_require__(/*! ./data-contrast.page.scss */ "./src/app/pages/data-contrast/data-contrast.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_data_compare_service__WEBPACK_IMPORTED_MODULE_2__["DataCompareService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], DataContrastPage);



/***/ }),

/***/ "./src/app/pages/data-contrast/detail/detail.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/pages/data-contrast/detail/detail.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".success {\n  color: #000;\n  color: #10dc60;\n}\n\n.danger {\n  color: #fff;\n  color: #f04141;\n}\n\n.header {\n  color: black;\n}\n\nion-col img {\n  width: 40px;\n  height: 40px;\n  float: left;\n  margin-right: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9kYXRhLWNvbnRyYXN0L2RldGFpbC9kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2RhdGEtY29udHJhc3QvZGV0YWlsL2RldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtBQ0NKOztBRENBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2RhdGEtY29udHJhc3QvZGV0YWlsL2RldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWNjZXNze1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGNvbG9yOiAjMTBkYzYwO1xufVxuXG4uZGFuZ2Vye1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGNvbG9yOiAjZjA0MTQxOyAgICBcbn1cblxuLmhlYWRlcntcbiAgICBjb2xvcjogYmxhY2s7XG59XG5pb24tY29sIGltZ3tcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgZmxvYXQ6IGxlZnQ7XG4gICAgbWFyZ2luLXJpZ2h0OiAycHg7XG59IiwiLnN1Y2Nlc3Mge1xuICBjb2xvcjogIzAwMDtcbiAgY29sb3I6ICMxMGRjNjA7XG59XG5cbi5kYW5nZXIge1xuICBjb2xvcjogI2ZmZjtcbiAgY29sb3I6ICNmMDQxNDE7XG59XG5cbi5oZWFkZXIge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbmlvbi1jb2wgaW1nIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1yaWdodDogMnB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/data-contrast/detail/detail.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/data-contrast/detail/detail.component.ts ***!
  \****************************************************************/
/*! exports provided: DetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailComponent", function() { return DetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_data_compare_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/data-compare.service */ "./src/app/services/data-compare.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");





let DetailComponent = class DetailComponent {
    constructor(activeRoute, dataCompare) {
        this.activeRoute = activeRoute;
        this.dataCompare = dataCompare;
        this.imgOrigin = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].usFileUrl + 'storage/';
        this.random = Math.random();
        this.compareData = [];
        this.activeRoute.params.subscribe(res => {
            this.contractId = res.contract_id;
            this.applyNo = res.apply_no;
            this.sku = res.sku;
        });
    }
    ngOnInit() {
        this.dataCompare
            .getCompareDetail({ contract_id: this.contractId, apply_inspection_no: this.applyNo, sku: this.sku })
            .subscribe(res => {
            res.data && (this.compareData = res.data);
        });
    }
};
DetailComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _services_data_compare_service__WEBPACK_IMPORTED_MODULE_1__["DataCompareService"] }
];
DetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-detail',
        template: __webpack_require__(/*! raw-loader!./detail.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/data-contrast/detail/detail.component.html"),
        styles: [__webpack_require__(/*! ./detail.component.scss */ "./src/app/pages/data-contrast/detail/detail.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_compare_service__WEBPACK_IMPORTED_MODULE_1__["DataCompareService"]])
], DetailComponent);



/***/ }),

/***/ "./src/app/pipe/data-compare.pipe.ts":
/*!*******************************************!*\
  !*** ./src/app/pipe/data-compare.pipe.ts ***!
  \*******************************************/
/*! exports provided: DataComparePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataComparePipe", function() { return DataComparePipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DataComparePipe = class DataComparePipe {
    transform(value, apply_no, contract_id) {
        let rVal = [], factories = value;
        if (apply_no) {
            factories = factories.filter(res => res.apply_inspection_no == apply_no);
        }
        factories.forEach(res => {
            res.contract_data.forEach(element => {
                element.sku && element.sku.length && (rVal = rVal.concat(element.sku));
            });
        });
        return rVal;
    }
};
DataComparePipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'dataCompare',
    })
], DataComparePipe);



/***/ }),

/***/ "./src/app/services/data-compare.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/data-compare.service.ts ***!
  \**************************************************/
/*! exports provided: DataCompareService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataCompareService", function() { return DataCompareService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");



let DataCompareService = class DataCompareService {
    constructor(http) {
        this.http = http;
    }
    getCompareBasicList() {
        return this.http.get({ url: '/task/get_compare_apply_inspection_data' });
    }
    getCompareDetail(params) {
        return this.http.get({ url: '/task/get_compare_sku_data_for_basic_inspector', params: params });
    }
};
DataCompareService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"] }
];
DataCompareService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"]])
], DataCompareService);



/***/ })

}]);
//# sourceMappingURL=pages-data-contrast-data-contrast-module-es2015.js.map