(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		2
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		3
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		4
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		5
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		6
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		7
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		8
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		9
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		10
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		11
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		12
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		13
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		14
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		15
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		16
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		17
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		18
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		19
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		20
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		21
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		22
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		23
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		24
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		25
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		26
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		27
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		28
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		29
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		30
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		31
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		32
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		33
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		34
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		35
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		36
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		37
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		38
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		"common",
		39
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		"common",
		40
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		41
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		42
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_5.entry.js",
		0,
		"common",
		43
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		44
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		45
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		46
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		47
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		48
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		49
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		50
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		51
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		52
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		53
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		54
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		55
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		56
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		57
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		58
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		59
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		60
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		61
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		62
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		63
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		64
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		65
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		66
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		67
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		68
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		69
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		70
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		1
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		71
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		72
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		73
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		74
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		75
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		76
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		77
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		78
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n    <ion-split-pane>\n        <ion-menu type=\"overlay\" mode=\"ios\" class=\"menu\">\n            <ion-header>\n                <ion-toolbar>\n                    <ion-title>鹰眼</ion-title>\n                </ion-toolbar>\n            </ion-header>\n\n            <ion-content>\n                <ion-list>\n                    <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n                        <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\" *ngIf=\"p.type == 'link'\">\n                            <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n                            <ion-label>\n                                {{ p.title }}\n                            </ion-label>\n                        </ion-item>\n\n                        <ion-item *ngIf=\"p.type == 'btn'\" (click)=\"menuBtn(p)\">\n                            <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n                            <ion-label>\n                                {{ p.title }}\n                            </ion-label>\n                        </ion-item>\n                    </ion-menu-toggle>\n                </ion-list>\n            </ion-content>\n        </ion-menu>\n        <ion-router-outlet main> </ion-router-outlet>\n    </ion-split-pane>\n    <!-- <div style=\"position: fixed;top: 0; right: 0;z-index: 999;width: 50px;height: 56px;background: #f00;\">\n        <img src=\"../assets/img/slogan.png\" alt=\"\">\n    </div> -->\n\n    <div class=\"dis-flex\" *ngIf=\"loading\">\n        <img src=\"../../assets/icon/loadding2.svg\" alt=\"\" />\n        <ion-text>正在加载</ion-text>\n    </div>\n<!-- \n    <div class=\"item load2 \"  style=\"background-color:#0dcecb\">\n        <div class=\"loader\">加载中...</div>\n    </div>\n     -->\n</ion-app>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/queue/queue.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/implement-inspection/queue/queue.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-title>上传进度</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"close()\">关闭</ion-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"flex mt-10\">\n        <div class=\"f-l pro\">\n            <span>完成进度：</span>\n            <span>{{ alreadyUploadQueue.length + '/' + (alreadyUploadQueue.length + queue.length) }}</span>\n        </div>\n        <div class=\"f-r pro\">\n            <span>当前状态：</span>\n            <span [style.color]=\"uQueue.status ? '#10dc60' : 'red'\">{{ uQueue.status ? '上传中…' : '暂停中' }}</span>\n        </div>\n        <div>\n            <ion-button\n                [hidden]=\"true\"\n                (click)=\"uQueue.suspend()\"\n                id=\"suspend\"\n                color=\"danger\"\n                fill=\"outline\"\n                [disabled]=\"isSuspend\"\n                size=\"small\"\n                class=\"f-r mr-10\"\n            >\n                暂停\n            </ion-button>\n            <ion-button\n                [hidden]=\"true\"\n                (click)=\"uQueue.restart()\"\n                id=\"restart\"\n                size=\"small\"\n                fill=\"outline\"\n                [disabled]=\"!isSuspend\"\n                class=\"f-r\"\n            >\n                重新开始\n            </ion-button>\n        </div>\n    </div>\n\n    <ion-segment scrollable (ionChange)=\"segmentChanged($event)\" [(ngModel)]=\"uploadStatus\">\n        <ion-segment-button value=\"uploading\">\n            <ion-label>上传中</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"uploaded\">\n            <ion-label>已上传</ion-label>\n        </ion-segment-button>\n    </ion-segment>\n\n    <ion-list mode=\"md\">\n        <ion-item class=\"title\">\n            <ion-label class=\"name\">上传项目</ion-label>\n            <ion-text class=\"progress\">上传进度</ion-text>\n            <ion-label class=\"size-t\">文件大小</ion-label>\n            <ion-label class=\"do\" *ngIf=\"uploadStatus == 'uploading'\">操作</ion-label>\n        </ion-item>\n        <div *ngIf=\"uploadStatus == 'uploading'\" class=\"content\">\n            <ion-item *ngFor=\"let item of queue; let index = index\">\n                <ion-label class=\"name\">{{ inspectFieldMap[item.payload.type] }}</ion-label>\n                <ion-progress-bar\n                    [color]=\"isSuspend ? 'danger' : item.percentage < 1 ? 'success' : 'primary'\"\n                    class=\"progress\"\n                    value=\"{{ item.percentage ? item.percentage / 100 : 0 }}\"\n                ></ion-progress-bar>\n                <ion-label class=\"size-t\">{{ (item.size / 1024 / 1024).toFixed(2) + 'MB' }}</ion-label>\n                <div class=\"w-10\">\n                    <ion-button\n                        size=\"small\"\n                        (click)=\"cancel()\"\n                        color=\"danger\"\n                        class=\"do\"\n                        [hidden]=\"index !== 0 || !uQueue.status\"\n                        >取消</ion-button\n                    >\n                </div>\n            </ion-item>\n        </div>\n\n        <ng-container *ngIf=\"uploadStatus == 'uploaded'\">\n            <ion-item *ngFor=\"let item of alreadyUploadQueue\">\n                <ion-label class=\"name\">{{ inspectFieldMap[item.payload.type] }}</ion-label>\n                <ion-progress-bar\n                    color=\"success\"\n                    class=\"progress\"\n                    value=\"{{ item.percentage / 100 }}\"\n                ></ion-progress-bar>\n                <ion-label class=\"size-t\">{{ (item.size / 1024 / 1024).toFixed(2) + 'MB' }}</ion-label>\n            </ion-item>\n        </ng-container>\n    </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/feedback/feedback.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/rework-inspect/feedback/feedback.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"close()\">关闭</ion-button>\n        </ion-buttons>\n        <ion-title>问题描述</ion-title>\n    </ion-toolbar>\n</ion-header>\n \n<ion-content>\n    <ion-card>\n        <ion-item class=\"ion-activated\" >\n            <ion-icon name=\"text\" slot=\"start\"></ion-icon>\n            <!-- <textarea readonly *ngIf=\"data && data.desc; else noData\">{{ data.desc }}</textarea> -->\n            <ul>\n                <li *ngFor=\"let item of data.desc;let i = index\" [ngStyle]=\"{'color': item.color?item.color:'#000'}\">\n                    {{i + 1 + '.    ' + item.text}}\n                </li>\n            </ul>\n        </ion-item>\n\n        <ion-item class=\"ion-activated\">\n            <ion-icon name=\"image\" slot=\"start\"></ion-icon>\n            <ul class=\"img-list\"*ngIf=\"data && data.review_summary_img; else noData\" imgGallery >\n                <li *ngFor=\"let item of data.review_summary_img\" >\n                    <img [src]=\"imgOrigin + item\" alt=\"\" />\n                </li>\n            </ul>\n        </ion-item>\n\n        <ion-item class=\"ion-activated\">\n            <ion-icon name=\"videocam\" slot=\"start\"></ion-icon>\n            <ul class=\"vdo-list\"*ngIf=\"data && data.review_summary_video; else noData\">\n                <li *ngFor=\"let item of data.review_summary_video\" (click)=\"play(item)\">\n                    <video [src]=\"imgOrigin + item\" poster=\"\"></video>\n                </li>\n            </ul>\n        </ion-item>\n    </ion-card>\n</ion-content>\n\n<ng-template #noData>暂无</ng-template>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/widget/description/description.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/widget/description/description.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"pd-15\">\n    <h3>请输入备注</h3>\n    <div class=\"content\">\n        <ion-textarea [(ngModel)]=\"_desc.text\"></ion-textarea>\n        <ion-radio-group [(ngModel)]=\"_desc.level\">\n            <div>\n                <ion-label color=\"danger\">特别重要</ion-label>\n                <ion-radio value=\"important\" color=\"danger\"></ion-radio>\n            </div>\n\n            <div>\n                <ion-label color=\"warning\">重要</ion-label>\n                <ion-radio value=\"second\" color=\"warning\"></ion-radio>\n            </div>\n\n            <div>\n                <ion-label color=\"dark\">一般</ion-label>\n                <ion-radio value=\"commonly\" color=\"dark\"></ion-radio>\n            </div>\n        </ion-radio-group>\n    </div>\n\n    <ion-button size=\"small\" (click)=\"enter()\">确定</ion-button>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/widget/inspect-setting-box/inspect-setting-box.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/widget/inspect-setting-box/inspect-setting-box.component.html ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"root\">\n    <ion-list>\n        <ion-item *ngIf=\"type == 'group'\">\n            <ion-label>是否联系工厂：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_contacked_factory\"></ion-toggle>\n        </ion-item>\n\n        <ion-item *ngIf=\"type == 'group'\">\n            <ion-label>是否购买车票：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_bought_ticket\"></ion-toggle>\n        </ion-item>\n\n        <ion-item *ngIf=\"type == 'task'\">\n            <ion-label>验货工厂是否曾经验过：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_inspected_factory\"></ion-toggle>\n        </ion-item>\n\n        <ion-item *ngIf=\"type == 'skuList'\">\n            <ion-label>验货产品是否曾经验过：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_inspected_product\"></ion-toggle>\n        </ion-item>\n\n        <ion-item *ngIf=\"type == 'task'\">\n            <ion-label>是否规范好时间路线：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_plan_date\"></ion-toggle>\n        </ion-item>\n\n        <ion-item *ngIf=\"type == 'skuDetail'\">\n            <ion-label>是否熟悉要求：</ion-label>\n            <ion-toggle color=\"primary\" [(ngModel)]=\"_contract.is_know_demand\"></ion-toggle>\n        </ion-item>\n    </ion-list>\n</div>\n<ion-button color=\"primary\" (click)=\"enter()\">确定</ion-button>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/widget/parts/parts.component.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/widget/parts/parts.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/widget/scan/scan.component.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/widget/scan/scan.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-content no-scroll [ngClass]=\"{ qrscanner: isShow }\">\n    <div [ngClass]=\"{ 'qrscanner-area': isShow }\"></div>\n    <div [ngClass]=\"{ 'through-line': isShow }\"></div>\n    <div class=\"button-bottom\" fxLayout=\"row\" fxLayoutAlign=\"space-around center\"> -->\n        <!-- <ion-fab-button (click)=\"toggleLight()\" class=\"icon-camera\">\n            <ion-icon name=\"flash\"></ion-icon>\n        </ion-fab-button> -->\n        <!-- <ion-fab-button (click)=\"toggleCamera()\" color=\"secondary\" class=\"icon-camera\">\n            <ion-icon name=\"reverse-camera\"></ion-icon>\n        </ion-fab-button>\n    </div>\n</ion-content> -->\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/widget/video-play/video-play.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/widget/video-play/video-play.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"modal.dismiss()\">关闭</ion-button>\n        </ion-buttons>\n        <ion-title></ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <video [src]=\"_source\" controls autoplay width=\"100%\" height=\"100%\"></video>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _guard_login_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./guard/login.guard */ "./src/app/guard/login.guard.ts");
/* harmony import */ var _guard_login_can_leave_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./guard/login-can-leave.guard */ "./src/app/guard/login-can-leave.guard.ts");
/* harmony import */ var _guard_login_can_enter_guard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./guard/login-can-enter.guard */ "./src/app/guard/login-can-enter.guard.ts");






var routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
    },
    {
        path: '',
        loadChildren: function () { return __webpack_require__.e(/*! import() | pages-login-login-module */ "pages-login-login-module").then(__webpack_require__.bind(null, /*! ./pages/login/login.module */ "./src/app/pages/login/login.module.ts")).then(function (m) { return m.LoginPageModule; }); },
        canDeactivate: [_guard_login_can_leave_guard__WEBPACK_IMPORTED_MODULE_4__["LoginCanLeaveGuard"]],
        canActivate: [_guard_login_can_enter_guard__WEBPACK_IMPORTED_MODULE_5__["LoginCanEnterGuard"]],
    },
    {
        path: '',
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
        loadChildren: function () { return __webpack_require__.e(/*! import() | pages-welcome-welcome-module */ "pages-welcome-welcome-module").then(__webpack_require__.bind(null, /*! ./pages/welcome/welcome.module */ "./src/app/pages/welcome/welcome.module.ts")).then(function (m) { return m.WelcomePageModule; }); },
    },
    {
        path: '',
        loadChildren: function () { return Promise.all(/*! import() | pages-inspect-task-inspect-task-module */[__webpack_require__.e("default~pages-data-contrast-data-contrast-module~pages-evaluate-evaluate-module~pages-implement-insp~74f8f3ab"), __webpack_require__.e("pages-inspect-task-inspect-task-module")]).then(__webpack_require__.bind(null, /*! ./pages/inspect-task/inspect-task.module */ "./src/app/pages/inspect-task/inspect-task.module.ts")).then(function (m) { return m.InspectTaskPageModule; }); },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: 'home',
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
        loadChildren: function () { return __webpack_require__.e(/*! import() | pages-home-home-module */ "pages-home-home-module").then(__webpack_require__.bind(null, /*! ./pages/home/home.module */ "./src/app/pages/home/home.module.ts")).then(function (m) { return m.HomePageModule; }); },
    },
    {
        path: '',
        loadChildren: function () {
            return Promise.all(/*! import() | pages-implement-inspection-implement-inspection-module */[__webpack_require__.e("default~pages-data-contrast-data-contrast-module~pages-evaluate-evaluate-module~pages-implement-insp~74f8f3ab"), __webpack_require__.e("pages-implement-inspection-implement-inspection-module")]).then(__webpack_require__.bind(null, /*! ./pages/implement-inspection/implement-inspection.module */ "./src/app/pages/implement-inspection/implement-inspection.module.ts")).then(function (m) { return m.ImplementInspectionPageModule; });
        },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: '',
        loadChildren: function () { return __webpack_require__.e(/*! import() | pages-inspection-inspection-module */ "pages-inspection-inspection-module").then(__webpack_require__.bind(null, /*! ./pages/inspection/inspection.module */ "./src/app/pages/inspection/inspection.module.ts")).then(function (m) { return m.InspectionPageModule; }); },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: '',
        loadChildren: function () { return Promise.all(/*! import() | pages-evaluate-evaluate-module */[__webpack_require__.e("default~pages-data-contrast-data-contrast-module~pages-evaluate-evaluate-module~pages-implement-insp~74f8f3ab"), __webpack_require__.e("pages-evaluate-evaluate-module")]).then(__webpack_require__.bind(null, /*! ./pages/evaluate/evaluate.module */ "./src/app/pages/evaluate/evaluate.module.ts")).then(function (m) { return m.EvaluatePageModule; }); },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: 'rework-inspect',
        loadChildren: function () { return Promise.all(/*! import() | pages-rework-inspect-rework-inspect-module */[__webpack_require__.e("default~pages-data-contrast-data-contrast-module~pages-evaluate-evaluate-module~pages-implement-insp~74f8f3ab"), __webpack_require__.e("pages-rework-inspect-rework-inspect-module")]).then(__webpack_require__.bind(null, /*! ./pages/rework-inspect/rework-inspect.module */ "./src/app/pages/rework-inspect/rework-inspect.module.ts")).then(function (m) { return m.ReworkInspectPageModule; }); },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: '',
        loadChildren: function () { return Promise.all(/*! import() | pages-data-contrast-data-contrast-module */[__webpack_require__.e("default~pages-data-contrast-data-contrast-module~pages-evaluate-evaluate-module~pages-implement-insp~74f8f3ab"), __webpack_require__.e("pages-data-contrast-data-contrast-module")]).then(__webpack_require__.bind(null, /*! ./pages/data-contrast/data-contrast.module */ "./src/app/pages/data-contrast/data-contrast.module.ts")).then(function (m) { return m.DataContrastPageModule; }); },
        canActivate: [_guard_login_guard__WEBPACK_IMPORTED_MODULE_3__["LoginGuard"]],
    },
    {
        path: '**',
        redirectTo: 'welcome',
        pathMatch: 'full',
    },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".dis-flex {\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  top: 55px;\n  left: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  background: rgba(0, 0, 0, 0.5);\n  flex-direction: column;\n  color: #fff;\n}\n.dis-flex img {\n  width: 60px;\n  height: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQ0NKO0FEQUk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0VSIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRpcy1mbGV4IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHRvcDogNTVweDtcbiAgICBsZWZ0OiAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBpbWcge1xuICAgICAgICB3aWR0aDogNjBweDtcbiAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgIH1cbn1cblxuLy8gLml0ZW0ge1xuLy8gICAgIGZsb2F0OiBsZWZ0O1xuLy8gICAgIHdpZHRoOiAxODBweDtcbi8vICAgICBoZWlnaHQ6IDE4MHB4O1xuLy8gICAgIG1hcmdpbi10b3A6IDE1cHg7XG4vLyAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuLy8gICAgIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XG4vLyAgICAgY3Vyc29yOiBwb2ludGVyO1xuLy8gICAgIHBvc2l0aW9uOiBmaXhlZDtcbi8vICAgICB0b3A6IDU1cHg7XG4vLyAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbi8vIH1cblxuLy8gLypsb2FkaW5nKi9cbi8vIC5sb2FkMSAubG9hZGVyLFxuLy8gLmxvYWQxIC5sb2FkZXI6YmVmb3JlLFxuLy8gLmxvYWQxIC5sb2FkZXI6YWZ0ZXIge1xuLy8gICAgIGJhY2tncm91bmQ6ICNmZmY7XG4vLyAgICAgLXdlYmtpdC1hbmltYXRpb246IGxvYWQxIDFzIGluZmluaXRlIGVhc2UtaW4tb3V0O1xuLy8gICAgIGFuaW1hdGlvbjogbG9hZDEgMXMgaW5maW5pdGUgZWFzZS1pbi1vdXQ7XG4vLyAgICAgd2lkdGg6IDFlbTtcbi8vICAgICBoZWlnaHQ6IDRlbTtcbi8vIH1cbi8vIC5sb2FkMSAubG9hZGVyOmJlZm9yZSxcbi8vIC5sb2FkMSAubG9hZGVyOmFmdGVyIHtcbi8vICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgICAgdG9wOiAwO1xuLy8gICAgIGNvbnRlbnQ6ICcnO1xuLy8gfVxuLy8gLmxvYWQxIC5sb2FkZXI6YmVmb3JlIHtcbi8vICAgICBsZWZ0OiAtMS41ZW07XG4vLyB9XG4vLyAubG9hZDEgLmxvYWRlciB7XG4vLyAgICAgdGV4dC1pbmRlbnQ6IC05OTk5ZW07XG4vLyAgICAgbWFyZ2luOiAzOCUgYXV0bztcbi8vICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4vLyAgICAgZm9udC1zaXplOiAxMXB4O1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjE2cztcbi8vICAgICBhbmltYXRpb24tZGVsYXk6IDAuMTZzO1xuLy8gfVxuLy8gLmxvYWQxIC5sb2FkZXI6YWZ0ZXIge1xuLy8gICAgIGxlZnQ6IDEuNWVtO1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjMycztcbi8vICAgICBhbmltYXRpb24tZGVsYXk6IDAuMzJzO1xuLy8gfVxuXG4vLyAubG9hZDIgLmxvYWRlcixcbi8vIC5sb2FkMiAubG9hZGVyOmJlZm9yZSxcbi8vIC5sb2FkMiAubG9hZGVyOmFmdGVyIHtcbi8vICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4vLyB9XG4vLyAubG9hZDIgLmxvYWRlcjpiZWZvcmUsXG4vLyAubG9hZDIgLmxvYWRlcjphZnRlciB7XG4vLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICAgIGNvbnRlbnQ6ICcnO1xuLy8gfVxuLy8gLmxvYWQyIC5sb2FkZXI6YmVmb3JlIHtcbi8vICAgICB3aWR0aDogNS4yZW07XG4vLyAgICAgaGVpZ2h0OiAxMC4yZW07XG4vLyAgICAgYmFja2dyb3VuZDogIzBkY2VjYjtcbi8vICAgICBib3JkZXItcmFkaXVzOiAxMC4yZW0gMCAwIDEwLjJlbTtcbi8vICAgICB0b3A6IC0wLjFlbTtcbi8vICAgICBsZWZ0OiAtMC4xZW07XG4vLyAgICAgLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luOiA1LjJlbSA1LjFlbTtcbi8vICAgICB0cmFuc2Zvcm0tb3JpZ2luOiA1LjJlbSA1LjFlbTtcbi8vICAgICAtd2Via2l0LWFuaW1hdGlvbjogbG9hZDIgMnMgaW5maW5pdGUgZWFzZSAxLjVzO1xuLy8gICAgIGFuaW1hdGlvbjogbG9hZDIgMnMgaW5maW5pdGUgZWFzZSAxLjVzO1xuLy8gfVxuLy8gLmxvYWQyIC5sb2FkZXIge1xuLy8gICAgIGZvbnQtc2l6ZTogMTFweDtcbi8vICAgICB0ZXh0LWluZGVudDogLTk5OTk5ZW07XG4vLyAgICAgbWFyZ2luOiA0MHB4IGF1dG87XG4vLyAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuLy8gICAgIHdpZHRoOiAxMGVtO1xuLy8gICAgIGhlaWdodDogMTBlbTtcbi8vICAgICBib3gtc2hhZG93OiBpbnNldCAwIDAgMCAxZW0gI2ZmZjtcbi8vIH1cbi8vIC5sb2FkMiAubG9hZGVyOmFmdGVyIHtcbi8vICAgICB3aWR0aDogNS4yZW07XG4vLyAgICAgaGVpZ2h0OiAxMC4yZW07XG4vLyAgICAgYmFja2dyb3VuZDogIzBkY2VjYjtcbi8vICAgICBib3JkZXItcmFkaXVzOiAwIDEwLjJlbSAxMC4yZW0gMDtcbi8vICAgICB0b3A6IC0wLjFlbTtcbi8vICAgICBsZWZ0OiA1LjFlbTtcbi8vICAgICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IDBweCA1LjFlbTtcbi8vICAgICB0cmFuc2Zvcm0tb3JpZ2luOiAwcHggNS4xZW07XG4vLyAgICAgLXdlYmtpdC1hbmltYXRpb246IGxvYWQyIDJzIGluZmluaXRlIGVhc2U7XG4vLyAgICAgYW5pbWF0aW9uOiBsb2FkMiAycyBpbmZpbml0ZSBlYXNlO1xuLy8gfVxuLy8gQC13ZWJraXQta2V5ZnJhbWVzIGxvYWQyIHtcbi8vICAgICAwJSB7XG4vLyAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XG4vLyAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuLy8gICAgIH1cbi8vICAgICAxMDAlIHtcbi8vICAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpO1xuLy8gICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpO1xuLy8gICAgIH1cbi8vIH1cbi8vIEBrZXlmcmFtZXMgbG9hZDIge1xuLy8gICAgIDAlIHtcbi8vICAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTtcbi8vICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XG4vLyAgICAgfVxuLy8gICAgIDEwMCUge1xuLy8gICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XG4vLyAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XG4vLyAgICAgfVxuLy8gfVxuIiwiLmRpcy1mbGV4IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6IDU1cHg7XG4gIGxlZnQ6IDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGNvbG9yOiAjZmZmO1xufVxuLmRpcy1mbGV4IGltZyB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_menu_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/menu.service */ "./src/app/services/menu.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ "./node_modules/@ionic-native/background-mode/ngx/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./config/config */ "./src/app/config/config.ts");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/loading.service */ "./src/app/services/loading.service.ts");
















var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, menu, Router, effectCtrl, backgroundMode, http, loadingCtrl, fileOpener, transfer, file) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.menu = menu;
        this.Router = Router;
        this.effectCtrl = effectCtrl;
        this.backgroundMode = backgroundMode;
        this.http = http;
        this.loadingCtrl = loadingCtrl;
        this.fileOpener = fileOpener;
        this.transfer = transfer;
        this.file = file;
        this.appPages = this.menu.menu;
        this.loading = false;
        this.initializeApp();
        this.statusBar.overlaysWebView(false);
        // set status bar to white
        this.statusBar.backgroundColorByHexString('#03a9f4');
        backgroundMode.enable(); //防止后台睡觉
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        // 订阅loading
        this.loadingCtrl.loadingChange.subscribe(function (val) {
            _this.loading = val;
        });
    };
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            //判断版本号与线上版本是否有所差异
            _this.http
                .get(src_environments_environment__WEBPACK_IMPORTED_MODULE_14__["environment"].origin + "/version/get_latest_version")
                .toPromise()
                .then(function (res) {
                if (res && res.data !== _config_config__WEBPACK_IMPORTED_MODULE_10__["AppVersion"]) {
                    _this.effectCtrl.showAlert({
                        message: '检测到已经有新版本，是否立即自动更新？',
                        buttons: [
                            {
                                text: '取消',
                            },
                            {
                                text: '下载',
                                handler: function () {
                                    _this.downloadFile(src_environments_environment__WEBPACK_IMPORTED_MODULE_14__["environment"].origin + "/version/upload_version?version_name=" + res.data, res.data);
                                },
                            },
                        ],
                    });
                }
            });
            //下载安装
        });
    };
    /**
     *下载事件
     * @param {*} url
     * @memberof MyApp
     */
    AppComponent.prototype.downloadFile = function (url, version) {
        var _this = this;
        console.log('-----------    下载    -----------');
        this.effectCtrl.showLoad({
            message: "\u6B63\u5728\u4E0B\u8F7D\u2026",
        });
        var fileTransfer = this.transfer.create();
        fileTransfer.download(encodeURI(url), "" + this.file.externalDataDirectory + version + ".apk", true).then(function (entry) {
            // console.log(entry);
            _this.fileOpener
                .open("" + _this.file.externalDataDirectory.toString() + version + ".apk", 'application/vnd.android.package-archive')
                .then(function () { })
                .catch(function (e) {
                _this.effectCtrl.loadCtrl.dismiss();
                _this.effectCtrl.showToast({ message: '打开apk失败，请手动前往安装', color: 'danger' });
            });
        }, function (err) {
            console.log(err);
            _this.effectCtrl.loadCtrl.dismiss();
        });
        // fileTransfer.onProgress(progressEvent => {
        //     if (progressEvent.lengthComputable) {
        //         let downloadProgress = (progressEvent.loaded / progressEvent.total) * 100;
        //     }
        // });
    };
    AppComponent.prototype.menuBtn = function (p) {
        var that = this;
        if (p.title == '退出') {
            this.effectCtrl.showAlert({
                message: '确定要退出吗？',
                header: '提示',
                buttons: [
                    {
                        text: '确定',
                        handler: function () {
                            sessionStorage.removeItem('USER_INFO');
                            sessionStorage.removeItem('PERMISSION');
                            that.Router.navigate(['/login']);
                        },
                    },
                    {
                        text: '取消',
                    },
                ],
            });
        }
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
        { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"] },
        { type: _services_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_7__["PageEffectService"] },
        { type: _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_8__["BackgroundMode"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_15__["LoadingService"] },
        { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_12__["FileOpener"] },
        { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__["FileTransfer"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_13__["File"] }
    ]; };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"],
            _services_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_7__["PageEffectService"],
            _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_8__["BackgroundMode"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_15__["LoadingService"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_12__["FileOpener"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__["FileTransfer"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_13__["File"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _widget_video_play_video_play_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./widget/video-play/video-play.component */ "./src/app/widget/video-play/video-play.component.ts");
/* harmony import */ var _widget_parts_parts_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./widget/parts/parts.component */ "./src/app/widget/parts/parts.component.ts");
/* harmony import */ var _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/qr-scanner/ngx */ "./node_modules/@ionic-native/qr-scanner/ngx/index.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _services_interceptor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/interceptor */ "./src/app/services/interceptor.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./widget/inspect-setting-box/inspect-setting-box.component */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./widget/scan/scan.component */ "./src/app/widget/scan/scan.component.ts");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _widget_description_description_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./widget/description/description.component */ "./src/app/widget/description/description.component.ts");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _ionic_native_secure_storage_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic-native/secure-storage/ngx */ "./node_modules/@ionic-native/secure-storage/ngx/index.js");
/* harmony import */ var _pages_implement_inspection_queue_queue_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./pages/implement-inspection/queue/queue.component */ "./src/app/pages/implement-inspection/queue/queue.component.ts");
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ "./node_modules/@ionic-native/background-mode/ngx/index.js");
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic-native/network/ngx */ "./node_modules/@ionic-native/network/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _pages_rework_inspect_feedback_feedback_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./pages/rework-inspect/feedback/feedback.component */ "./src/app/pages/rework-inspect/feedback/feedback.component.ts");
/* harmony import */ var _directives_directive_module__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./directives/directive.module */ "./src/app/directives/directive.module.ts");































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"],
                _widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_17__["InspectSettingBoxComponent"],
                _widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_19__["ScanComponent"],
                _widget_parts_parts_component__WEBPACK_IMPORTED_MODULE_2__["PartsComponent"],
                _widget_video_play_video_play_component__WEBPACK_IMPORTED_MODULE_1__["VideoPlayComponent"],
                _widget_description_description_component__WEBPACK_IMPORTED_MODULE_21__["DescriptionComponent"],
                _pages_implement_inspection_queue_queue_component__WEBPACK_IMPORTED_MODULE_24__["QueueComponent"],
                _pages_rework_inspect_feedback_feedback_component__WEBPACK_IMPORTED_MODULE_29__["FeedbackComponent"]
            ],
            entryComponents: [
                _widget_inspect_setting_box_inspect_setting_box_component__WEBPACK_IMPORTED_MODULE_17__["InspectSettingBoxComponent"],
                _widget_scan_scan_component__WEBPACK_IMPORTED_MODULE_19__["ScanComponent"],
                _widget_parts_parts_component__WEBPACK_IMPORTED_MODULE_2__["PartsComponent"],
                _widget_video_play_video_play_component__WEBPACK_IMPORTED_MODULE_1__["VideoPlayComponent"],
                _widget_description_description_component__WEBPACK_IMPORTED_MODULE_21__["DescriptionComponent"],
                _pages_implement_inspection_queue_queue_component__WEBPACK_IMPORTED_MODULE_24__["QueueComponent"],
                _pages_rework_inspect_feedback_feedback_component__WEBPACK_IMPORTED_MODULE_29__["FeedbackComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_13__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__["BrowserAnimationsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"],
                _directives_directive_module__WEBPACK_IMPORTED_MODULE_30__["DirectiveModule"]
            ],
            providers: [
                _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_4__["Camera"],
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_11__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_10__["SplashScreen"],
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HTTP_INTERCEPTORS"], useClass: _services_interceptor__WEBPACK_IMPORTED_MODULE_15__["DefaultInterceptor"], multi: true },
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_8__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonicRouteStrategy"] },
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_18__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_18__["HashLocationStrategy"] },
                _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_3__["QRScanner"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_20__["FileTransfer"],
                _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_22__["BarcodeScanner"],
                _ionic_native_secure_storage_ngx__WEBPACK_IMPORTED_MODULE_23__["SecureStorage"],
                _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_25__["BackgroundMode"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_27__["File"],
                _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_26__["Network"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_28__["FileOpener"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_12__["AppComponent"]],
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/blue-bird/service/file-chunk.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/blue-bird/service/file-chunk.service.ts ***!
  \*********************************************************/
/*! exports provided: FileChunkService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileChunkService", function() { return FileChunkService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");



var FileChunkService = /** @class */ (function () {
    function FileChunkService(ec) {
        this.ec = ec;
        this.SIZE = 30 * 1024 * 1024; //切片10M     * 1024;
    }
    /**
     * 创建切片
     * @param file  整个file对象
     * @param size  切片大小
     */
    FileChunkService.prototype.createFileChunk = function (file, size) {
        if (size === void 0) { size = this.SIZE; }
        var fileChunkList = [];
        var cur = 0;
        while (cur < file.size) {
            fileChunkList.push({ file: file.slice(cur, cur + size) });
            cur += size;
        }
        return fileChunkList;
    };
    /**
     * file事件  html : input[type=file] onchange事件
     *          ionic Cordova : 相机tape事件 || 文件选择器picker事件
     * @param file
     */
    FileChunkService.prototype.handleFile = function (file) {
        var _this = this;
        return new Promise(function (reject) {
            _this.file = file;
            var fileChunkList = _this.createFileChunk(_this.file);
            reject(fileChunkList);
        });
    };
    FileChunkService.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] }
    ]; };
    FileChunkService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"]])
    ], FileChunkService);
    return FileChunkService;
}());



/***/ }),

/***/ "./src/app/blue-bird/service/file-hash.service.ts":
/*!********************************************************!*\
  !*** ./src/app/blue-bird/service/file-hash.service.ts ***!
  \********************************************************/
/*! exports provided: FileHashService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileHashService", function() { return FileHashService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");



var FileHashService = /** @class */ (function () {
    function FileHashService(ec) {
        this.ec = ec;
    }
    FileHashService.prototype.initHashWorker = function (fileChunkList) {
        var _this = this;
        return new Promise(function (reject) {
            var worker = new Worker('../assets/js/hash.js');
            _this.ec.showLoad({
                message: '正在获取文件hash……',
            });
            worker.postMessage({ fileChunkList: fileChunkList });
            worker.onmessage = function (e) {
                var _a = e.data, percentage = _a.percentage, hash = _a.hash;
                _this.ec.clearEffectCtrl();
                if (hash) {
                    reject(hash);
                }
            };
        });
    };
    FileHashService.prototype.fileToBlob = function (file) {
        return new Promise(function (reject) {
            var worker = new Worker('../assets/js/filetoblob.js');
            worker.postMessage({ file: file });
            worker.onmessage = function (e) {
                var blob = e.data.blob;
                reject(blob);
            };
        });
    };
    FileHashService.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] }
    ]; };
    FileHashService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"]])
    ], FileHashService);
    return FileHashService;
}());



/***/ }),

/***/ "./src/app/blue-bird/service/request.service.ts":
/*!******************************************************!*\
  !*** ./src/app/blue-bird/service/request.service.ts ***!
  \******************************************************/
/*! exports provided: RequestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestService", function() { return RequestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-info.service */ "./src/app/services/user-info.service.ts");



var RequestService = /** @class */ (function () {
    function RequestService(userInfo) {
        this.userInfo = userInfo;
    }
    RequestService.prototype.request = function (_a) {
        var _this = this;
        var url = _a.url, _b = _a.method, method = _b === void 0 ? 'post' : _b, data = _a.data, headers = _a.headers, _c = _a.onProgress, onProgress = _c === void 0 ? function (e) { return e; } : _c, _d = _a.requestList, requestList = _d === void 0 ? [] : _d;
        //console.log('-------    请求    -------')
        return new Promise(function (resolve) {
            headers.Authorization = _this.userInfo.info ? "Bearer " + _this.userInfo.info.api_token : undefined;
            var xhr = new XMLHttpRequest();
            xhr.upload.onprogress = onProgress;
            // xhr.onloadend = () => {
            //     xhr.upload.onprogress = null; //释放内存
            //     console.log('------ 闭包关闭 释放性能 ------')
            // }
            xhr.open(method, url);
            Object.keys(headers).forEach(function (key) { return xhr.setRequestHeader(key, headers[key]); });
            xhr.send(data);
            xhr.onload = function (e) {
                // 将请求成功的 xhr 从列表中删除
                if (requestList) {
                    var xhrIndex = requestList.findIndex(function (item) { return item === xhr; });
                    requestList.splice(xhrIndex, 1);
                }
                //此地增加status不为200的逻辑
                //要是不为200，则通知queue不pop。暂停上传
                resolve({
                    data: xhr.status == 200 ? e.target.response : { message: '上传失败', error: xhr.status },
                });
            };
            // 暴露当前 xhr 给外部  通过引用类型暴漏
            requestList && requestList.push(xhr);
        });
    };
    RequestService.ctorParameters = function () { return [
        { type: src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"] }
    ]; };
    RequestService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"]])
    ], RequestService);
    return RequestService;
}());



/***/ }),

/***/ "./src/app/config/config.ts":
/*!**********************************!*\
  !*** ./src/app/config/config.ts ***!
  \**********************************/
/*! exports provided: utilFn, upLoadMaxImgLength, renewInitRequestTime, maxRenewInitRequest, AppVersion */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "utilFn", function() { return utilFn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "upLoadMaxImgLength", function() { return upLoadMaxImgLength; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renewInitRequestTime", function() { return renewInitRequestTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "maxRenewInitRequest", function() { return maxRenewInitRequest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppVersion", function() { return AppVersion; });
var utilFn = {
    //公共方法
    toQueryString: function (obj) {
        var result = [];
        for (var key in obj) {
            key = encodeURIComponent(key);
            var values = obj[key];
            if (values && values.constructor == Array) {
                var queryValues = [];
                for (var i = 0, len = values.length, value = void 0; i < len; i++) {
                    value = values[i];
                    queryValues.push(this.toQueryPair(key, value));
                }
                result = result.concat(queryValues);
            }
            else {
                result.push(this.toQueryPair(key, values));
            }
        }
        return result.join('&');
    },
    toQueryPair: function (key, value) {
        //参数序列化
        if (typeof value == 'undefined') {
            return key;
        }
        return key + '=' + encodeURIComponent(value === null ? '' : String(value));
    },
    formatData: function (params) {
        var arr = [];
        Object.keys(params).forEach(function (el) {
            arr.push(el + "=" + params[el]);
        });
        return arr.join('&');
    },
    Format: function (fmt) {
        var o = {
            'M+': new Date().getMonth() + 1,
            'd+': new Date().getDate(),
            'H+': new Date().getHours(),
            'm+': new Date().getMinutes(),
            's+': new Date().getSeconds(),
            'q+': Math.floor((new Date().getMonth() + 3) / 3),
            S: new Date().getMilliseconds(),
        };
        if (/(y+)/.test(fmt))
            fmt = fmt.replace(RegExp.$1, (new Date().getFullYear() + '').substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp('(' + k + ')').test(fmt))
                fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
        return fmt;
    },
    getPlatform: function () {
        if (navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i)) {
            return 'mobile'; /*window.location.href="你的手机版地址";*/
        }
        else {
            return 'pc'; /*window.location.href="你的电脑版地址";    */
        }
    },
    goBack: function () {
        history.go(-1);
    },
};
var upLoadMaxImgLength = 5; //图片上传限量
var renewInitRequestTime = 100000;
var maxRenewInitRequest = 3;
var AppVersion = 'hawkeye_1.0.7';


/***/ }),

/***/ "./src/app/directives/chipboard.directive.ts":
/*!***************************************************!*\
  !*** ./src/app/directives/chipboard.directive.ts ***!
  \***************************************************/
/*! exports provided: ChipboardDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChipboardDirective", function() { return ChipboardDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var ChipboardDirective = /** @class */ (function () {
    function ChipboardDirective(PageEffectService) {
        this.PageEffectService = PageEffectService;
    }
    ChipboardDirective.prototype.onclick = function (e) {
        var _this = this;
        var clipText = new ClipboardJS('.chip-text', {
            text: function (trigger) {
                return trigger.innerText;
            },
        });
        clipText.on('success', function (e) {
            _this.PageEffectService.showToast({
                message: '复制成功',
                color: 'success',
            });
            clipText.destroy();
        });
    };
    ChipboardDirective.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"])('click', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], ChipboardDirective.prototype, "onclick", null);
    ChipboardDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"])({
            selector: '[Chipboard]',
        })
        //must be input  " class='chip-text' Chipboard"
        ,
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], ChipboardDirective);
    return ChipboardDirective;
}());



/***/ }),

/***/ "./src/app/directives/directive.module.ts":
/*!************************************************!*\
  !*** ./src/app/directives/directive.module.ts ***!
  \************************************************/
/*! exports provided: DirectiveModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectiveModule", function() { return DirectiveModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _gallery_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./gallery.directive */ "./src/app/directives/gallery.directive.ts");
/* harmony import */ var _chipboard_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./chipboard.directive */ "./src/app/directives/chipboard.directive.ts");





var DirectiveModule = /** @class */ (function () {
    function DirectiveModule() {
    }
    DirectiveModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_gallery_directive__WEBPACK_IMPORTED_MODULE_3__["GalleryDirective"], _chipboard_directive__WEBPACK_IMPORTED_MODULE_4__["ChipboardDirective"]],
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
            exports: [_gallery_directive__WEBPACK_IMPORTED_MODULE_3__["GalleryDirective"], _chipboard_directive__WEBPACK_IMPORTED_MODULE_4__["ChipboardDirective"]],
        })
    ], DirectiveModule);
    return DirectiveModule;
}());



/***/ }),

/***/ "./src/app/directives/gallery.directive.ts":
/*!*************************************************!*\
  !*** ./src/app/directives/gallery.directive.ts ***!
  \*************************************************/
/*! exports provided: GalleryDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryDirective", function() { return GalleryDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var GalleryDirective = /** @class */ (function () {
    function GalleryDirective(el) {
        this.el = el;
        this._url = '';
        this.viewer = new Viewer(this.el.nativeElement, {
            inline: false,
            toolbar: false,
            url: function (image) {
                if (image.src.indexOf('_compress') != -1) {
                    return (image.src.substr(0, image.src.lastIndexOf('_')) +
                        image.src.substr(image.src.lastIndexOf('.'), image.src.length));
                }
                else
                    return image.src;
            },
        });
    }
    Object.defineProperty(GalleryDirective.prototype, "url", {
        set: function (Input) {
            if (!!Input) {
                if (Input.indexOf('_compress') != -1) {
                    this._url =
                        Input.substr(0, Input.lastIndexOf('_')) + Input.substr(Input.lastIndexOf('.'), Input.length);
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    GalleryDirective.prototype.onclick = function () {
        this.viewer.update();
    };
    GalleryDirective.prototype.ngOnDestroy = function () {
        //销毁viewer
        this.viewer && this.viewer.destroy();
    };
    GalleryDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
    ], GalleryDirective.prototype, "url", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('click'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], GalleryDirective.prototype, "onclick", null);
    GalleryDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
            selector: '[imgGallery]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])
    ], GalleryDirective);
    return GalleryDirective;
}());



/***/ }),

/***/ "./src/app/guard/login-can-enter.guard.ts":
/*!************************************************!*\
  !*** ./src/app/guard/login-can-enter.guard.ts ***!
  \************************************************/
/*! exports provided: LoginCanEnterGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginCanEnterGuard", function() { return LoginCanEnterGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");




var LoginCanEnterGuard = /** @class */ (function () {
    function LoginCanEnterGuard(storage, Router) {
        this.storage = storage;
        this.Router = Router;
    }
    LoginCanEnterGuard.prototype.canActivate = function (route, state) {
        var isLogin = this.storage.get('USER_INFO') != null ? true : false;
        if (isLogin) {
            this.Router.navigate(['/welcome']);
        }
        return !isLogin;
    };
    LoginCanEnterGuard.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    LoginCanEnterGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginCanEnterGuard);
    return LoginCanEnterGuard;
}());



/***/ }),

/***/ "./src/app/guard/login-can-leave.guard.ts":
/*!************************************************!*\
  !*** ./src/app/guard/login-can-leave.guard.ts ***!
  \************************************************/
/*! exports provided: LoginCanLeaveGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginCanLeaveGuard", function() { return LoginCanLeaveGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var LoginCanLeaveGuard = /** @class */ (function () {
    function LoginCanLeaveGuard(storage) {
        this.storage = storage;
    }
    LoginCanLeaveGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        var isLogin = this.storage.get('USER_INFO') != null ? true : false;
        return isLogin;
    };
    LoginCanLeaveGuard.ctorParameters = function () { return [
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] }
    ]; };
    LoginCanLeaveGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"]])
    ], LoginCanLeaveGuard);
    return LoginCanLeaveGuard;
}());



/***/ }),

/***/ "./src/app/guard/login.guard.ts":
/*!**************************************!*\
  !*** ./src/app/guard/login.guard.ts ***!
  \**************************************/
/*! exports provided: LoginGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginGuard", function() { return LoginGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var LoginGuard = /** @class */ (function () {
    function LoginGuard(Router, effectCtrl) {
        this.Router = Router;
        this.effectCtrl = effectCtrl;
    }
    LoginGuard.prototype.canActivate = function (route, state) {
        var _this = this;
        var isLogin = sessionStorage.getItem('USER_INFO') != null ? true : false;
        if (!isLogin) {
            this.effectCtrl.showAlert({
                header: '提示',
                message: '登录失效，请重新登录',
                backdropDismiss: false,
                buttons: [
                    {
                        text: '确定',
                        handler: function () {
                            _this.Router.navigate(['/login']);
                        },
                    },
                ],
            });
        }
        return isLogin;
    };
    LoginGuard.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    LoginGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], LoginGuard);
    return LoginGuard;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/class.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/implement-inspection/class.ts ***!
  \*****************************************************/
/*! exports provided: InspectField */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectField", function() { return InspectField; });
var InspectField = {
    throw_box_video: '摔箱检测视频',
    appearance_video: '外观检测视频',
    functions_video: '功能性检测视频',
    bearing_test_video: '承重检测视频',
    water_content_test_video: '含水量检测视频',
    factory_sample_room: '工厂样品间图片',
    outer_box_pic: '唛头',
    bar_code_pic: '条码图片',
    factory_other: '工厂其他图片',
    gross_weight_pic: '毛重图片',
    product_detail_pic: '产品细节图片',
    instructions_pic: '说明书图片',
    screws_pic: '螺丝包图片',
    product_wholes_pic: '产品整体图',
    product_size_pic: '产品尺寸图',
    appearance_pic: '外观检测图片',
    functions_pic: '功能性测试图片',
    summary_pic: '总结图片',
    inspection_require_pic: '验货要求图片',
    throw_box: '摔箱图片',
    size_pic: '尺寸图片',
    size_pic_length: '外箱尺寸长图片',
    size_pic_width: '外箱尺寸宽图片',
    size_pic_height: '外箱尺寸高图片',
    packing_pic: '包装图片',
    product_place_pic: '摆放图',
    instructions_and_accessories_pic: '说明书和附件图片',
    over_all_pic: '',
    net_weight_pic: '净重图片',
    bearing_test_pic: '承重检测图片',
    water_content_test_pic: '含水量检测图片',
    inspection_complete_pic: '',
    contract_sku_pic: '合同图片',
    factory_environment_pic: '工厂环境图片',
    factory_sample_room_pic: '工厂环境图片',
    factory_other_pic: '工厂其他图片',
};


/***/ }),

/***/ "./src/app/pages/implement-inspection/queue/queue.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/pages/implement-inspection/queue/queue.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".container {\n  position: -webkit-sticky;\n  position: sticky;\n  right: 0;\n  top: 0;\n  z-index: 999;\n  width: 100%;\n  background: white;\n  height: 200px;\n}\n\n.name {\n  width: 25%;\n  font-size: 13px;\n}\n\n.progress {\n  font-size: 13px;\n  width: 55%;\n}\n\n.size-t {\n  font-size: 13px;\n  text-align: center;\n  width: 10%;\n}\n\n.do {\n  font-size: 13px;\n  text-align: center;\n}\n\n.w-10 {\n  width: 10% !important;\n}\n\n.f-r {\n  float: right;\n}\n\n.mt-10 {\n  margin-top: 10px !important;\n}\n\n.mr-10 {\n  margin-right: 10px !important;\n}\n\n.flex {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.pro {\n  margin-left: 10px;\n  font-size: 14px;\n  font-weight: bold;\n  color: #3880ff;\n}\n\n.content {\n  height: calc(100% - 200px);\n  overflow-y: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbXBsZW1lbnQtaW5zcGVjdGlvbi9xdWV1ZS9xdWV1ZS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW1wbGVtZW50LWluc3BlY3Rpb24vcXVldWUvcXVldWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx3QkFBQTtFQUFBLGdCQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQ0NKOztBREVBO0VBQ0ksVUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURHQTtFQUNJLHFCQUFBO0FDQUo7O0FER0E7RUFDSSxZQUFBO0FDQUo7O0FER0E7RUFDSSwyQkFBQTtBQ0FKOztBREdBO0VBQ0ksNkJBQUE7QUNBSjs7QURHQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUNBSjs7QURPQTtFQUNJLDBCQUFBO0VBQ0Esa0JBQUE7QUNKSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ltcGxlbWVudC1pbnNwZWN0aW9uL3F1ZXVlL3F1ZXVlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHN0aWNreTtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDA7XG4gICAgei1pbmRleDogOTk5O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGhlaWdodDogMjAwcHg7XG59XG5cbi5uYW1lIHtcbiAgICB3aWR0aDogMjUlO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbn1cblxuLnByb2dyZXNzIHtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgd2lkdGg6IDU1JTtcbn1cblxuLnNpemUtdHtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiAxMCU7XG59XG5cbi5kb3tcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC8vIHdpZHRoOiAxMDAlO1xufVxuXG4udy0xMHtcbiAgICB3aWR0aDogMTAlICFpbXBvcnRhbnQ7XG59XG5cbi5mLXJ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4ubXQtMTB7XG4gICAgbWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4ubXItMTB7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5mbGV4e1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG5cbi5wcm97XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGNvbG9yOiAjMzg4MGZmO1xufVxuXG4udGl0bGV7XG4gICAgXG59XG5cbi5jb250ZW50e1xuICAgIGhlaWdodDogY2FsYygxMDAlIC0gMjAwcHgpO1xuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcbn0iLCIuY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHN0aWNreTtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogMDtcbiAgei1pbmRleDogOTk5O1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGhlaWdodDogMjAwcHg7XG59XG5cbi5uYW1lIHtcbiAgd2lkdGg6IDI1JTtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4ucHJvZ3Jlc3Mge1xuICBmb250LXNpemU6IDEzcHg7XG4gIHdpZHRoOiA1NSU7XG59XG5cbi5zaXplLXQge1xuICBmb250LXNpemU6IDEzcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwJTtcbn1cblxuLmRvIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi53LTEwIHtcbiAgd2lkdGg6IDEwJSAhaW1wb3J0YW50O1xufVxuXG4uZi1yIHtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4ubXQtMTAge1xuICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tci0xMCB7XG4gIG1hcmdpbi1yaWdodDogMTBweCAhaW1wb3J0YW50O1xufVxuXG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLnBybyB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogIzM4ODBmZjtcbn1cblxuLmNvbnRlbnQge1xuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDIwMHB4KTtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/implement-inspection/queue/queue.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/implement-inspection/queue/queue.component.ts ***!
  \*********************************************************************/
/*! exports provided: QueueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QueueComponent", function() { return QueueComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _upload_queue_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");
/* harmony import */ var _class__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../class */ "./src/app/pages/implement-inspection/class.ts");
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/network/ngx */ "./node_modules/@ionic-native/network/ngx/index.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");







var QueueComponent = /** @class */ (function () {
    function QueueComponent(modal, uQueue, ref, network, es) {
        var _this = this;
        this.modal = modal;
        this.uQueue = uQueue;
        this.ref = ref;
        this.network = network;
        this.es = es;
        this.uploadStatus = 'uploading';
        this.queue = [];
        this.inspectFieldMap = _class__WEBPACK_IMPORTED_MODULE_4__["InspectField"];
        this.destroy = false;
        this.isSuspend = false;
        this.statusSub = null;
        this.alreadyUploadQueue = []; //已上传的项目
        this.queue = uQueue.queue;
        this.alreadyUploadQueue = uQueue.alreadyUploadQueue;
        this.statusSub = uQueue.onChangeUploadStatus.subscribe(function (res) {
            _this.queue = uQueue.queue;
            _this.alreadyUploadQueue = uQueue.alreadyUploadQueue;
            _this.isSuspend = res;
        });
        //网络变化的时候触发
        network.onChange().subscribe(function (res) {
            // console.log('---- 重新进入 ----')
            var msg = '', color = 'success';
            if (!_this.queue || !_this.queue.length)
                return;
            switch (network.type) {
                case '2g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A2g,\u7CFB\u7EDF\u5224\u5B9A\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'warning';
                    document.getElementById('suspend').click();
                    break;
                case '3g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A3g,\u7CFB\u7EDF\u5224\u5B9A\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'warning';
                    document.getElementById('suspend').click();
                    break;
                case '4g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A4g,\u4E0A\u4F20\u4EFB\u52A1\u81EA\u52A8\u8FDB\u884C\u3002";
                    color = 'success';
                    document.getElementById('restart').click();
                    _this.queue = uQueue.queue;
                    break;
                case 'wifi':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3Awifi,\u4E0A\u4F20\u4EFB\u52A1\u81EA\u52A8\u8FDB\u884C\u3002";
                    color = 'success';
                    document.getElementById('restart').click();
                    _this.queue = uQueue.queue;
                    break;
                default: {
                    msg = "\u5F53\u524D\u6CA1\u6709\u7F51\u7EDC\u8FDE\u63A5,\u7CFB\u7EDF\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'danger';
                    document.getElementById('suspend').click();
                }
            }
            _this.es.showToast({
                message: msg,
                color: color,
            });
        });
    }
    QueueComponent.prototype.close = function () {
        this.modal.dismiss();
        this.uQueue.alreadyUpProgress = false;
    };
    QueueComponent.prototype.ngOnInit = function () { };
    QueueComponent.prototype.upload = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
            return [2 /*return*/];
        }); });
    };
    QueueComponent.prototype.segmentChanged = function (e) { };
    QueueComponent.prototype.cancel = function () {
        var _this = this;
        this.es.showAlert({
            message: '确定要取消吗？',
            buttons: [{
                    text: '取消',
                }, {
                    text: '确定',
                    handler: function () {
                        _this.uQueue.cancel();
                    }
                }]
        });
    };
    QueueComponent.prototype.ngDestroy = function () {
        this.destroy = true;
        this.statusSub.unsubscribe();
    };
    QueueComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _upload_queue_service__WEBPACK_IMPORTED_MODULE_3__["UploadQueueService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
        { type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_5__["Network"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] }
    ]; };
    QueueComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-queue',
            template: __webpack_require__(/*! raw-loader!./queue.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/implement-inspection/queue/queue.component.html"),
            changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].Default,
            styles: [__webpack_require__(/*! ./queue.component.scss */ "./src/app/pages/implement-inspection/queue/queue.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _upload_queue_service__WEBPACK_IMPORTED_MODULE_3__["UploadQueueService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_5__["Network"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"]])
    ], QueueComponent);
    return QueueComponent;
}());



/***/ }),

/***/ "./src/app/pages/implement-inspection/upload-queue.service.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/implement-inspection/upload-queue.service.ts ***!
  \********************************************************************/
/*! exports provided: UploadQueueService, HashCode */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadQueueService", function() { return UploadQueueService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HashCode", function() { return HashCode; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_blue_bird_service_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/blue-bird/service/request.service */ "./src/app/blue-bird/service/request.service.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/user-info.service */ "./src/app/services/user-info.service.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/network/ngx */ "./node_modules/@ionic-native/network/ngx/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var src_app_blue_bird_service_file_chunk_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/blue-bird/service/file-chunk.service */ "./src/app/blue-bird/service/file-chunk.service.ts");
/* harmony import */ var src_app_blue_bird_service_file_hash_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/blue-bird/service/file-hash.service */ "./src/app/blue-bird/service/file-hash.service.ts");
/* harmony import */ var src_app_services_http_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/http.service */ "./src/app/services/http.service.ts");












var UploadQueueService = /** @class */ (function () {
    function UploadQueueService(request, userInfo, es, network, file, fileReq, fileChunk, fileHash, http) {
        var _this = this;
        this.request = request;
        this.userInfo = userInfo;
        this.es = es;
        this.network = network;
        this.file = file;
        this.fileReq = fileReq;
        this.fileChunk = fileChunk;
        this.fileHash = fileHash;
        this.http = http;
        this.status = false; // 是否在下载
        this.isSuspend = false; //是否暂停状态
        this.queue = []; //上传队列 数组队列
        this.videoQueue = []; //视频上传队列
        this.alreadyUploadQueue = []; //已上传数组队列
        this.onChangeUploadStatus = new rxjs__WEBPACK_IMPORTED_MODULE_7__["BehaviorSubject"](this.isSuspend);
        this.alreadyUpProgress = false; //已经点过“上传进度”按钮 状态
        this.getImgData = new rxjs__WEBPACK_IMPORTED_MODULE_7__["BehaviorSubject"](null);
        this.alreadyUploadPayload$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.num = 0;
        this.requestList = [];
        network.onChange().subscribe(function (res) {
            // console.log('---- 重新进入 ----')
            var msg = '', color = 'success';
            if (!_this.queue || !_this.queue.length)
                return;
            switch (network.type) {
                case '2g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A2g,\u7CFB\u7EDF\u5224\u5B9A\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'warning';
                    _this.suspend();
                    break;
                case '3g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A3g,\u7CFB\u7EDF\u5224\u5B9A\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'warning';
                    _this.suspend();
                    break;
                case '4g':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3A4g,\u4E0A\u4F20\u4EFB\u52A1\u81EA\u52A8\u8FDB\u884C\u3002";
                    color = 'success';
                    _this.restart();
                    break;
                case 'wifi':
                    msg = "\u5F53\u524D\u7F51\u7EDC\u73AF\u5883\u4E3Awifi,\u4E0A\u4F20\u4EFB\u52A1\u81EA\u52A8\u8FDB\u884C\u3002";
                    color = 'success';
                    _this.restart();
                    break;
                default: {
                    msg = "\u5F53\u524D\u6CA1\u6709\u7F51\u7EDC\u8FDE\u63A5,\u7CFB\u7EDF\u6682\u505C\u4E0A\u4F20\u4EFB\u52A1\u3002";
                    color = 'danger';
                    _this.suspend();
                }
            }
            _this.es.showToast({
                message: msg,
                color: color,
            });
        });
    }
    /**
     * 向已上传队列里增加成员
     * @param ele  成员 - node
     */
    UploadQueueService.prototype.push = function (ele) {
        this.queue.push(ele);
        this.duplicateRemoval();
        !this.status && this.run();
        // this.queue = this.duplicateRemoval();  TODO有问题
        return true;
    };
    /**
     * 队列去重
     */
    UploadQueueService.prototype.duplicateRemoval = function () {
        var hash = {}, data = this.queue;
        data = data.reduce(function (preVal, curVal) {
            hash[curVal.hash] ? '' : (hash[curVal.hash] =  true && preVal.push(curVal));
            return preVal;
        }, []);
        return data;
    };
    /**
     * 队列出列 -
     */
    UploadQueueService.prototype.pop = function (payload, notEmitImg) {
        var qNode = this.queue.shift();
        if (!qNode)
            return;
        var node = {
            type: qNode.type,
            size: qNode.size,
            percentage: 100,
            payload: qNode.payload,
            path: payload.path,
        };
        // qNode.payload.type = payload.type;
        this.alreadyUploadQueue.push(node);
        //console.log('------ 回传 -----', node.path);
        !notEmitImg && this.alreadyUploadPayload$.next(node);
        return qNode;
    };
    Object.defineProperty(UploadQueueService.prototype, "front", {
        //获取队首
        get: function () {
            return this.queue[0];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(UploadQueueService.prototype, "rear", {
        //获取队尾
        get: function () {
            return this.queue[this.queue.length - 1];
        },
        enumerable: true,
        configurable: true
    });
    //清空队列
    UploadQueueService.prototype.clear = function () {
        this.queue = [];
    };
    Object.defineProperty(UploadQueueService.prototype, "size", {
        //获取队长
        get: function () {
            return this.queue.length;
        },
        enumerable: true,
        configurable: true
    });
    //暂停机制
    UploadQueueService.prototype.suspend = function () {
        if (!this.requestList || !this.requestList.length)
            return;
        this.requestList[0].abort();
        this.isSuspend = true;
        this.onChangeUploadStatus.next(this.isSuspend);
    };
    //重新开始
    UploadQueueService.prototype.restart = function () {
        this.queue = this.queue.slice();
        this.requestList = [];
        this.isSuspend = false;
        this.upload();
        this.onChangeUploadStatus.next(this.isSuspend);
    };
    /**
     * run方法 自动上传
     */
    UploadQueueService.prototype.run = function () {
        this.status = true;
        if (!this.networkLogic())
            return;
        this.upload();
    };
    //Add 外部调用
    UploadQueueService.prototype.add = function (ele) {
        if (ele.type == 'img') {
            this.push(ele);
        }
        else
            this.packingVideo(ele);
    };
    /**
     * 上传视频
     */
    UploadQueueService.prototype.packingVideo = function (ele) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var fileChunkList, hash, _a, uploadedList, shouldUpload;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.fileChunk.handleFile(ele.blob)];
                    case 1:
                        fileChunkList = _b.sent();
                        //主动将整个Blob置为null 释放缓存
                        ele.blob = null;
                        return [4 /*yield*/, this.fileHash.initHashWorker(fileChunkList)];
                    case 2:
                        hash = _b.sent();
                        ele.payload.hash = hash;
                        return [4 /*yield*/, this.verifyUpload(hash, ele.payload.path, ele.payload)];
                    case 3:
                        _a = (_b.sent()).data, uploadedList = _a.uploadedList, shouldUpload = _a.shouldUpload;
                        if (!shouldUpload) {
                            alert('文件已上传');
                            return [2 /*return*/];
                        }
                        else {
                            // 此地将切片push到队列
                            this.chunkToQueueNode(uploadedList ? uploadedList : [], fileChunkList, ele);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * 网速判断
     */
    UploadQueueService.prototype.networkLogic = function () {
        var val = true;
        // if (this.network.type == 'none') {
        //     val = false;
        //     this.suspend();
        //     this.es.showToast({
        //         message: '当前网络环境不佳，上传任务搁置',
        //         color: 'danger',
        //     });
        // }
        return val;
    };
    //驱动上传
    UploadQueueService.prototype.driveUpload = function (node) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var formData, key;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!node)
                            return [2 /*return*/, true];
                        formData = new FormData();
                        try {
                            //组装额外参数 区分图片和视频
                            for (key in node.payload) {
                                formData.append(key, node.payload[key]);
                            }
                            if (node.type == 'video') {
                                formData.append('sort_index', node.sort_index);
                                formData.append('apply_inspection_no', node.apply_inspection_no);
                                formData.append('contract_no', node.contract_no);
                                formData.append('sku', node.sku);
                                formData.append('chunk', node.chunk);
                                formData.append('chunk_total', node.chunk_total);
                                formData.delete('hash');
                            }
                            // console.log('-----  上传之前FormData  -----');
                            // console.log(node.payload)
                        }
                        catch (e) {
                            console.log('getFront没有', this.queue, node);
                        }
                        node.type == 'img' && formData.append('file', node.blob);
                        return [4 /*yield*/, this.request.request({
                                url: "" + src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + (node.type == 'img' ? '/task/add_inspection_task_img2' : '/task/add_inspection_task_video'),
                                requestList: this.requestList,
                                onProgress: this.createProgressHandler(this.front),
                                data: formData,
                                headers: {
                                    Authorization: this.userInfo.info ? "Bearer " + this.userInfo.info.api_token : undefined,
                                },
                            })];
                    case 1: 
                    //将结果返回
                    return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    /**
     * 通用上传API
     * 递归
     */
    UploadQueueService.prototype.upload = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var chunkNode, next_1, msg, next;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        chunkNode = [];
                        //此处判断是否有chunks
                        if (this.front.chunks && this.front.chunks.length) {
                            //如果有则将chunks转为队列
                            chunkNode = this.front.chunks;
                        }
                        else {
                            chunkNode = [this.front];
                        }
                        if (!(chunkNode && chunkNode.length && chunkNode[0].type == 'video')) return [3 /*break*/, 6];
                        debugger;
                        return [4 /*yield*/, this.driveUpload(chunkNode[0])];
                    case 1:
                        next_1 = _a.sent();
                        if (!(next_1.data && JSON.parse(next_1.data).status == 1)) return [3 /*break*/, 5];
                        chunkNode.shift();
                        if (chunkNode.length) {
                            //如果还有切片则上传
                            this.upload();
                            return [2 /*return*/];
                        }
                        if (!(JSON.parse(next_1.data).data && JSON.parse(next_1.data).data.canMerge === true)) return [3 /*break*/, 3];
                        debugger;
                        return [4 /*yield*/, this.mergeRequest(this.front)];
                    case 2:
                        msg = _a.sent();
                        //合并完成之后 判断状态 如果成功则删除缓存 在让主队列的front出列
                        if (msg.status === 1 && this.front) {
                            // this.pop(msg.data);
                            this.pop(msg.data[0], msg.data.status === 'already');
                            if (this.size) {
                                this.upload();
                                //此处判断如果一维队列没有queue可传 则将总状态（status）置为false
                            }
                            else
                                this.status = false;
                            return [2 /*return*/];
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        this.cancel();
                        return [2 /*return*/];
                    case 4: return [3 /*break*/, 6];
                    case 5:
                        this.cancel();
                        alert('上传出错，请重新上传');
                        _a.label = 6;
                    case 6:
                        console.log('视频上传不应该执行到这里  ');
                        return [4 /*yield*/, this.driveUpload(chunkNode[0])];
                    case 7:
                        next = _a.sent();
                        //如果next为 则直接跳过 上传下一个
                        if (next === true || (next && next.data && !JSON.parse(next.data).error) || next === 1) {
                            try {
                                //console.log('------ 返回值 -------', JSON.parse(next.data));
                                //!Important  此处判断因为后台去重后返回的值status 为 already时 不pop队列 不删除缓存 继续往下执行方法
                                //再出队列 将已经上传的node的线上url发布出去 等待photograph component订阅
                                this.pop(JSON.parse(next.data).data[0], JSON.parse(next.data).status === 'already');
                            }
                            catch (e) {
                                //console.log(this.front);
                            }
                            if (this.size && this.front) {
                                this.upload();
                            }
                            else
                                this.status = false;
                        }
                        else {
                            //暂停上传
                            this.es.showToast({
                                color: 'danger',
                                message: '当前网络状态不好，系统自动暂停上传',
                            });
                            this.front.percentage = 0;
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    // 用闭包保存每个 chunk 的进度数据
    UploadQueueService.prototype.createProgressHandler = function (item) {
        if (!item)
            return;
        try {
            return function (e) {
                if (item.type == 'img') {
                    item.percentage = parseInt(String((e.loaded / e.total) * 100));
                }
                else {
                    //在此增加计算已经上传了的切片
                    item.current = parseInt(String((e.loaded / e.total) * 100));
                    if (item.current === 100) {
                        item.percentage = 100 - (item.chunks.length / item.chunksLength) * 100;
                        console.log('--------------------- 切片完成 ---------------------', item.percentage);
                    }
                }
            };
        }
        catch (e) {
            console.log(e, item);
        }
    };
    UploadQueueService.prototype.chunkToQueueNode = function (uploadedList, fileChunkList, ele) {
        if (uploadedList === void 0) { uploadedList = []; }
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data, node;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                data = fileChunkList
                    //组装为切片
                    .map(function (_a, index) {
                    var file = _a.file;
                    var obj = {
                        chunk: file,
                        type: ele.type,
                        payload: null,
                        size: file.size,
                        apply_inspection_no: ele.payload.apply_inspection_no,
                        contract_no: ele.payload.contract_no,
                        sku: ele.payload.sku,
                        chunk_total: fileChunkList.length,
                        percentage: uploadedList.includes(index + '') ? 100 : 0,
                    };
                    obj.payload = {
                        cut_num: index,
                        filehash: ele.payload.hash,
                        hash: ele.payload.hash + '__' + index,
                        index: index,
                        upload_type: 'upload',
                        type: ele.payload.type,
                    };
                    return obj;
                })
                    //筛选未上传的切片
                    .filter(function (_a) {
                    var hash = _a.payload.hash;
                    return !uploadedList.includes(hash);
                });
                ele.already = uploadedList.length;
                ele.chunks = data;
                /**
                 *  此地需要判断一种情况
                 *  当切片通过线上已上传的切片过滤后没有可传的切片时
                 *  此时直接进行合并操作
                 * */
                if (fileChunkList.length === uploadedList.length) {
                    node = {
                        type: null,
                        size: null,
                        payload: {
                            type: ele.type,
                            apply_inspection_no: ele.payload.apply_inspection_no,
                            contract_no: ele.payload.contract_no,
                            sku: ele.payload.sku,
                            hash: ele.payload.hash,
                            sort_index: ele.payload.sort_index,
                        },
                    };
                    this.mergeRequest(node);
                    return [2 /*return*/];
                }
                //此地先将chunks的数量存好，上传的时候是每传完一个就会删除
                ele.chunksLength = fileChunkList.length;
                ele.percentage = (ele.already / ele.chunksLength) * 100;
                this.push(ele); //** 此处应该在push里驱动upload
                return [2 /*return*/];
            });
        });
    };
    UploadQueueService.prototype.mergeRequest = function (node) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                data = {
                    filehash: node.payload.hash,
                    type: node.payload.type,
                    apply_inspection_no: node.payload.apply_inspection_no,
                    contract_no: node.payload.contract_no,
                    sku: node.payload.sku,
                    upload_type: 'merge',
                    sort_index: node.payload.sort_index,
                };
                !node.payload.sort_index && delete data.sort_index;
                return [2 /*return*/, this.http.post({ url: '/task/add_inspection_task_video', params: data }).toPromise()];
            });
        });
    };
    UploadQueueService.prototype.getFileEntry = function (url) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var dirPath, fileName;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        dirPath = url.substring(0, url.lastIndexOf('/'));
                        fileName = url.substring(url.lastIndexOf('/') + 1, url.length);
                        return [4 /*yield*/, this.file.readAsArrayBuffer(dirPath, fileName)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    //根据参数获取base64流 （每个photograph展示用）
    UploadQueueService.prototype.getCacheImagesByParams = function (params) {
        var cache = JSON.parse(localStorage.getItem('CURRENT_INSPECT_META_DATA_PATH'));
    };
    /**
     * 通过base64ToBlob WebWorker 得到Blob
     * @param base64
     */
    UploadQueueService.prototype.doWorkerGetBlob = function (base64) {
        var obs = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Observable"](function (observer) {
            var worker = new Worker('../assets/js/dataURItoBlob.js');
            worker.postMessage({ res: base64 });
            worker.onmessage = function (e) {
                observer.next(e);
            };
        });
        return obs;
    };
    /**
     * 验证视频上传接口
     * @param fileHash
     * @param filePath
     */
    UploadQueueService.prototype.verifyUpload = function (fileHash, filePath, params) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.fileReq.request({
                            url: src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + "/task/add_inspection_task_video",
                            headers: {
                                'content-type': 'application/json',
                            },
                            data: JSON.stringify({
                                filehash: fileHash,
                                filepath: filePath,
                                type: params.type,
                                apply_inspection_no: params.apply_inspection_no,
                                contract_no: params.contract_no,
                                sku: params.sku,
                                upload_type: 'fileVerify',
                            }),
                        })];
                    case 1:
                        data = (_a.sent()).data;
                        return [2 /*return*/, JSON.parse(data)];
                }
            });
        });
    };
    //取消上传 跳过第一个
    UploadQueueService.prototype.cancel = function () {
        this.suspend(); //暂停
        this.queue.shift(); //出队列
        this.size && this.restart(); //重新开始上传
    };
    UploadQueueService.ctorParameters = function () { return [
        { type: src_app_blue_bird_service_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_4__["UserInfoService"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"] },
        { type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_6__["Network"] },
        { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_8__["File"] },
        { type: src_app_blue_bird_service_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"] },
        { type: src_app_blue_bird_service_file_chunk_service__WEBPACK_IMPORTED_MODULE_9__["FileChunkService"] },
        { type: src_app_blue_bird_service_file_hash_service__WEBPACK_IMPORTED_MODULE_10__["FileHashService"] },
        { type: src_app_services_http_service__WEBPACK_IMPORTED_MODULE_11__["HttpService"] }
    ]; };
    UploadQueueService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_blue_bird_service_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            src_app_services_user_info_service__WEBPACK_IMPORTED_MODULE_4__["UserInfoService"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"],
            _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_6__["Network"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_8__["File"],
            src_app_blue_bird_service_request_service__WEBPACK_IMPORTED_MODULE_2__["RequestService"],
            src_app_blue_bird_service_file_chunk_service__WEBPACK_IMPORTED_MODULE_9__["FileChunkService"],
            src_app_blue_bird_service_file_hash_service__WEBPACK_IMPORTED_MODULE_10__["FileHashService"],
            src_app_services_http_service__WEBPACK_IMPORTED_MODULE_11__["HttpService"]])
    ], UploadQueueService);
    return UploadQueueService;
}());

function HashCode(str) {
    var hash = 0, i, chr;
    if (str.length === 0)
        return hash;
    for (i = 0; i < str.length; i++) {
        chr = str.charCodeAt(i);
        hash = (hash << 5) - hash + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}


/***/ }),

/***/ "./src/app/pages/rework-inspect/feedback/feedback.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/pages/rework-inspect/feedback/feedback.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  padding: 10px 0;\n}\n\n.vdo-list {\n  width: 100%;\n}\n\n.vdo-list li {\n  float: left;\n  width: 50%;\n}\n\n.vdo-list li video {\n  width: 100%;\n}\n\n.img-list, .vdo-list {\n  width: 100%;\n}\n\n.img-list li, .vdo-list li {\n  float: left;\n  width: 50%;\n  max-height: 250px;\n  overflow: hidden;\n  padding: 0.5rem;\n  padding-right: 0;\n}\n\n.img-list li img, .img-list li video, .vdo-list li img, .vdo-list li video {\n  border: 1px solid #ccc;\n  height: 100%;\n  width: 100%;\n}\n\n.img-list::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n\nion-text {\n  color: #505050;\n  font-size: 14px;\n}\n\nul {\n  padding-bottom: 10px;\n}\n\nul li {\n  line-height: 18px;\n  font-size: 14px;\n  width: 100%;\n  margin-top: 5px;\n  border: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9yZXdvcmstaW5zcGVjdC9mZWVkYmFjay9mZWVkYmFjay5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvcmV3b3JrLWluc3BlY3QvZmVlZGJhY2svZmVlZGJhY2suY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0FDQ0o7O0FEQUk7RUFDSSxXQUFBO0VBQ0EsVUFBQTtBQ0VSOztBRERRO0VBQ0ksV0FBQTtBQ0daOztBREVBO0VBQ0ksV0FBQTtBQ0NKOztBREFJO0VBQ0ksV0FBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDRVI7O0FERFE7RUFDSSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDR1o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxvQkFBQTtBQ0NKOztBREFJO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FDRVIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9yZXdvcmstaW5zcGVjdC9mZWVkYmFjay9mZWVkYmFjay5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVte1xuICAgIHBhZGRpbmc6IDEwcHggMDtcbn1cblxuLnZkby1saXN0e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGxpe1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgd2lkdGg6IDUwJTtcbiAgICAgICAgdmlkZW97XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmltZy1saXN0LC52ZG8tbGlzdHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBsaXtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIHdpZHRoOiA1MCU7XG4gICAgICAgIG1heC1oZWlnaHQ6IDI1MHB4O1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICBwYWRkaW5nOiAuNXJlbTtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMDtcbiAgICAgICAgaW1nLHZpZGVve1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uaW1nLWxpc3Q6OmFmdGVye1xuICAgIGNvbnRlbnQ6ICcnO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGNsZWFyOiBib3RoO1xufVxuXG5pb24tdGV4dHtcbiAgICBjb2xvcjogIzUwNTA1MDtcbiAgICBmb250LXNpemU6IDE0cHg7XG59XG5cbnVsIHtcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICBsaXtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgYm9yZGVyOiAwO1xuICAgIH1cbn0iLCJpb24taXRlbSB7XG4gIHBhZGRpbmc6IDEwcHggMDtcbn1cblxuLnZkby1saXN0IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4udmRvLWxpc3QgbGkge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDUwJTtcbn1cbi52ZG8tbGlzdCBsaSB2aWRlbyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uaW1nLWxpc3QsIC52ZG8tbGlzdCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLmltZy1saXN0IGxpLCAudmRvLWxpc3QgbGkge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDUwJTtcbiAgbWF4LWhlaWdodDogMjUwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBhZGRpbmc6IDAuNXJlbTtcbiAgcGFkZGluZy1yaWdodDogMDtcbn1cbi5pbWctbGlzdCBsaSBpbWcsIC5pbWctbGlzdCBsaSB2aWRlbywgLnZkby1saXN0IGxpIGltZywgLnZkby1saXN0IGxpIHZpZGVvIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmltZy1saXN0OjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjbGVhcjogYm90aDtcbn1cblxuaW9uLXRleHQge1xuICBjb2xvcjogIzUwNTA1MDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG51bCB7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxudWwgbGkge1xuICBsaW5lLWhlaWdodDogMThweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBib3JkZXI6IDA7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/rework-inspect/feedback/feedback.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/rework-inspect/feedback/feedback.component.ts ***!
  \*********************************************************************/
/*! exports provided: FeedbackComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeedbackComponent", function() { return FeedbackComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var src_app_widget_video_play_video_play_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/widget/video-play/video-play.component */ "./src/app/widget/video-play/video-play.component.ts");







var FeedbackComponent = /** @class */ (function () {
    function FeedbackComponent(modal, es, inspectCtrl) {
        this.modal = modal;
        this.es = es;
        this.inspectCtrl = inspectCtrl;
        this.imgOrigin = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].usFileUrl;
        this.data = {
            desc: '',
            review_summary_img: '',
            review_summary_video: '',
        };
    }
    FeedbackComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.inspectCtrl
            .getReworkTaskContent({
            apply_inspection_no: this.apply_inspection_no,
            sku: this.sku,
            contract_no: this.contract_no,
        })
            .subscribe(function (res) {
            console.log(res);
            _this.data = res.data;
            if (typeof _this.data.desc == 'string') {
                _this.data.desc = [{ text: _this.data.desc, color: 'rgb(0, 0, 0)' }];
            }
            else {
                if (_this.data.desc && _this.data.desc.length) {
                    if (!_this.data.desc.length) {
                        _this.data.desc = [{ text: '', color: 'rgb(0, 0, 0)' }];
                    }
                }
                else {
                    _this.data.desc = [{ text: '', color: 'rgb(0, 0, 0)' }];
                }
            }
        });
    };
    FeedbackComponent.prototype.close = function () {
        this.modal.dismiss();
    };
    FeedbackComponent.prototype.play = function (p) {
        this.es.showModal({
            component: src_app_widget_video_play_video_play_component__WEBPACK_IMPORTED_MODULE_6__["VideoPlayComponent"],
            componentProps: { source: p },
        });
    };
    FeedbackComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], FeedbackComponent.prototype, "apply_inspection_no", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], FeedbackComponent.prototype, "sku", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], FeedbackComponent.prototype, "contract_no", void 0);
    FeedbackComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-feedback',
            template: __webpack_require__(/*! raw-loader!./feedback.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/rework-inspect/feedback/feedback.component.html"),
            styles: [__webpack_require__(/*! ./feedback.component.scss */ "./src/app/pages/rework-inspect/feedback/feedback.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_3__["InspectionService"]])
    ], FeedbackComponent);
    return FeedbackComponent;
}());



/***/ }),

/***/ "./src/app/services/http.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/http.service.ts ***!
  \******************************************/
/*! exports provided: HttpService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpService", function() { return HttpService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _user_info_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-info.service */ "./src/app/services/user-info.service.ts");
/* harmony import */ var _loading_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");






var HttpService = /** @class */ (function () {
    function HttpService(http, loading, userInfo) {
        this.http = http;
        this.loading = loading;
        this.userInfo = userInfo;
    }
    HttpService.prototype.get = function (params, showLoading) {
        //登陆后的get请求
        !showLoading && this.loading.setLoading(true);
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl + params.url, {
            headers: {
                Authorization: this.userInfo.info ? "Bearer " + this.userInfo.info.api_token : undefined,
            },
            params: params.params,
        });
    };
    HttpService.prototype.delete = function (params, showLoading) {
        !showLoading && this.loading.setLoading(true);
        return this.http.delete(src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl + params.url + '/' + params.params, {
            headers: {
                Authorization: this.userInfo.info ? "Bearer " + this.userInfo.info.api_token : undefined,
            },
        });
    };
    HttpService.prototype.post = function (params, showLoading) {
        !showLoading && this.loading.setLoading(true);
        var obj = {
            'Content-Type': 'application/json;charset=UTF-8',
            Authorization: this.userInfo.info ? "Bearer " + this.userInfo.info.api_token : undefined,
        };
        !this.userInfo.info && delete obj.Authorization;
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl + params.url, JSON.stringify(params.params), {
            headers: obj,
        });
    };
    HttpService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
        { type: _loading_service__WEBPACK_IMPORTED_MODULE_2__["LoadingService"] },
        { type: _user_info_service__WEBPACK_IMPORTED_MODULE_1__["UserInfoService"] }
    ]; };
    HttpService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _loading_service__WEBPACK_IMPORTED_MODULE_2__["LoadingService"], _user_info_service__WEBPACK_IMPORTED_MODULE_1__["UserInfoService"]])
    ], HttpService);
    return HttpService;
}());



/***/ }),

/***/ "./src/app/services/inspection.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/inspection.service.ts ***!
  \************************************************/
/*! exports provided: InspectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionService", function() { return InspectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var InspectionService = /** @class */ (function () {
    function InspectionService(http) {
        this.http = http;
    }
    InspectionService.prototype.getTaskList = function (obj) {
        return this.http.get({ url: '/inspection/get_inspection_task_data', params: obj });
    };
    InspectionService.prototype.inspectSetting = function (params) {
        return this.http.post({
            url: '/inspection/pre_inspection_task',
            params: params,
        });
    };
    InspectionService.prototype.getInspectTaskList = function (obj) {
        return this.http.get({
            url: '/task/inspection_task_list',
            params: { page: obj.page, keywords: obj.keywords, value: obj.value },
        });
    };
    InspectionService.prototype.getReworkInspectList = function (obj) {
        return this.http.get({
            url: '/task/inspection_task_list_rework',
            params: { page: obj.page, keywords: obj.keywords, value: obj.value },
        });
    };
    InspectionService.prototype.getReworkTaskContent = function (obj) {
        return this.http.get({
            url: '/task/get_inspection_task_rework_desc',
            params: { apply_inspection_no: obj.apply_inspection_no, sku: obj.sku, contract_no: obj.contract_no },
        });
    };
    InspectionService.prototype.toInspection = function (params) {
        //验货  （sku）
        return this.http.get({
            url: '/task/task-sku-view',
            params: {
                task_id: params.id,
                sku: params.sku,
                contract_id: params.contract_id,
            },
        });
    };
    InspectionService.prototype.addInspectionTaskDesc = function (params) {
        return this.http.post({
            url: '/inspection/add_inspection_task_desc',
            params: params,
        });
    };
    InspectionService.prototype.getInspectTaskById = function (apply_id) {
        return this.http.get({
            url: '/inspection/get_inspection_for_apply_id',
            params: { apply_id: apply_id },
        });
    };
    InspectionService.prototype.submitData = function (uploadData) {
        //sku  提交
        return this.http.post({
            url: '/task/task-inspection-post',
            params: uploadData,
        });
    };
    InspectionService.prototype.submitDataAcc = function (accUpload) {
        return this.http.post({
            url: '/task/task-inspection-acc-post',
            params: accUpload,
        });
    };
    InspectionService.ctorParameters = function () { return [
        { type: _http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"] }
    ]; };
    InspectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"]])
    ], InspectionService);
    return InspectionService;
}());



/***/ }),

/***/ "./src/app/services/interceptor.ts":
/*!*****************************************!*\
  !*** ./src/app/services/interceptor.ts ***!
  \*****************************************/
/*! exports provided: DefaultInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DefaultInterceptor", function() { return DefaultInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _loading_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../config/config */ "./src/app/config/config.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");










var DefaultInterceptor = /** @class */ (function () {
    function DefaultInterceptor(router, loading, effectCtrl) {
        this.router = router;
        this.loading = loading;
        this.effectCtrl = effectCtrl;
        this.errArr = [401, 404, 500, 502, 301];
        this.filterUrls = '/task/add_inspection_task_img /task/add_inspection_task_video';
    }
    DefaultInterceptor.prototype.intercept = function (req, next) {
        var _this = this;
        // req = req.clone({
        //   setHeaders: {
        //     Authorization: `Bearer ${this.baseData.userInfo.api_token}`
        //   }
        // });
        // console.log('HttpInterceptor req', req);
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["mergeMap"])(function (event) {
            // 允许统一对请求错误处理，这是因为一个请求若是业务上错误的情况下其HTTP请求的状态是200的情况下需要
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"] && event.status == 200)
                return _this.handleData(event);
            // 若一切都正常，则后续操作
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(event);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["timeout"])(_config_config__WEBPACK_IMPORTED_MODULE_8__["renewInitRequestTime"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["retryWhen"])(function (err$) {
            //重试 节奏控制器
            // takeWhile(req => (req as any).url.indexOf(this.filterUrls) != -1),
            return err$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["scan"])(function (errCount, err) {
                if (errCount >= _config_config__WEBPACK_IMPORTED_MODULE_8__["maxRenewInitRequest"] || _this.errArr.indexOf(err.status) != -1) {
                    throw err;
                }
                return errCount + 1;
            }, 0), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["delay"])(3000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["tap"])(function (errCount) {
                if (errCount == 1) {
                    //第一次重试时显示友好信息
                    _this.effectCtrl.showToast({
                        message: '网络错误，正在进行第一次重新请求',
                        color: 'warning',
                    });
                }
                else if (errCount == 2) {
                    _this.effectCtrl.toastCtrl.dismiss();
                    _this.effectCtrl.showToast({
                        message: '网络错误，正在进行第二次重新请求',
                        color: 'warning',
                    });
                }
                else {
                }
            }));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["catchError"])(function (err) { return _this.handleData(err); }));
    };
    DefaultInterceptor.prototype.handleData = function (event) {
        var _this = this;
        // console.log('HttpInterceptor handleData', event);
        // 可能会因为 `throw` 导出无法执行 `_HttpClient` 的 `end()` 操作
        // this.injector.get(_HttpClient).end();
        // 业务处理：一些通用操作
        this.loading.setLoading(false);
        // this.effectCtrl.showLoad({
        //     message: '加载中…'
        // })
        switch (event.status) {
            case 200:
                !src_environments_environment__WEBPACK_IMPORTED_MODULE_9__["environment"].production && console.log('成功发送请求');
                // 业务层级错误处理，以下是假定restful有一套统一输出格式（指不管成功与否都有相应的数据格式）情况下进行处理
                // 例如响应内容：
                //  错误内容：{ status: 1, msg: '非法参数' }
                //  正确内容：{ status: 0, response: {  } }
                // 则以下代码片断可直接适用
                // if (event instanceof HttpResponse) {
                //     const body: any = event.body;
                //     if (body && body.status !== 0) {
                //         this.msg.error(body.msg);
                //         // 继续抛出错误中断后续所有 Pipe、subscribe 操作，因此：
                //         // this.http.get('/').subscribe() 并不会触发
                //         return throwError({});
                //     } else {
                //         // 重新修改 `body` 内容为 `response` 内容，对于绝大多数场景已经无须再关心业务状态码
                //         return of(new HttpResponse(Object.assign(event, { body: body.response })));
                //         // 或者依然保持完整的格式
                //         return of(event);
                //     }
                // }
                this.clearEffectElem();
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpResponse"]) {
                    var body = event.body;
                    if (body && body.retCode === 1002) {
                        // this.msg.error(body.comment);
                        this.router.navigate(['/login']);
                    }
                }
                break;
            case 401: // 未登录状态码
                this.effectCtrl.alertCtrl
                    .getTop() //跨域的时候有时会发送两次请求  为了避免有两个弹框 先判断
                    .then(function (alert) {
                    if (!alert) {
                        _this.effectCtrl.showAlert({
                            header: '提示',
                            message: '登陆无效，请重新登录',
                            backdropDismiss: false,
                            buttons: [
                                {
                                    text: 'ok',
                                    handler: function () {
                                        _this.effectCtrl.alertCtrl.dismiss().then(function () {
                                            sessionStorage.removeItem('USER_INFO');
                                            _this.router.navigate(['/login']);
                                            _this.clearEffectElem();
                                        });
                                    },
                                },
                            ],
                        });
                    }
                });
                break;
            case 403:
            case 404:
                this.clearEffectElem();
                this.effectCtrl.showToast({
                    message: '请求错误，请稍后重试！',
                    color: 'danger',
                });
            case 500:
                this.clearEffectElem();
                this.effectCtrl.showAlert({
                    header: '提示',
                    message: '服务器出错啦',
                    backdropDismiss: false,
                    buttons: [
                        {
                            text: 'ok',
                            handler: function () {
                                _this.effectCtrl.alertCtrl.dismiss();
                            },
                        },
                    ],
                });
                break;
            default:
                if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpErrorResponse"]) {
                    console.warn('未可知错误，大部分是由于后端不支持CORS或无效配置引起', event);
                }
                this.clearEffectElem();
                this.effectCtrl.showAlert({
                    header: '提示',
                    message: '网络错误，请稍后重试',
                    buttons: ['ok'],
                });
                break;
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_6__["of"])(event);
    };
    DefaultInterceptor.prototype.clearEffectElem = function () {
        var _this = this;
        this.effectCtrl.toastCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.toastCtrl.dismiss();
            }
        });
        this.effectCtrl.loadCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.loadCtrl.dismiss();
            }
        });
        this.effectCtrl.alertCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.alertCtrl.dismiss();
            }
        });
        this.effectCtrl.loadCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.effectCtrl.loadCtrl.dismiss();
            }
        });
    };
    DefaultInterceptor.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _loading_service__WEBPACK_IMPORTED_MODULE_1__["LoadingService"] },
        { type: _page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] }
    ]; };
    DefaultInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _loading_service__WEBPACK_IMPORTED_MODULE_1__["LoadingService"], _page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"]])
    ], DefaultInterceptor);
    return DefaultInterceptor;
}());



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var LoadingService = /** @class */ (function () {
    function LoadingService() {
        this.loading = false;
        this.loadingChange = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
    }
    LoadingService.prototype.setLoading = function (val) {
        this.loading = val;
        this.loadingChange.next(this.loading);
    };
    LoadingService.prototype.getLoading = function () {
        return this.loading;
    };
    LoadingService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LoadingService);
    return LoadingService;
}());



/***/ }),

/***/ "./src/app/services/menu.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/menu.service.ts ***!
  \******************************************/
/*! exports provided: MenuService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuService", function() { return MenuService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu */ "./src/app/services/menu.ts");




var MenuService = /** @class */ (function () {
    function MenuService() {
        this.menu = _menu__WEBPACK_IMPORTED_MODULE_3__["menu"];
        this.menuChanged = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.autoExpandMenu = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"](); //自动展开菜单项
    }
    MenuService.prototype.setMenuChange = function (val) {
        this.menuChanged.next(val);
    };
    MenuService.prototype.setMenuExpand = function (menu) {
        this.autoExpandMenu.next(menu);
    };
    MenuService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MenuService);
    return MenuService;
}());



/***/ }),

/***/ "./src/app/services/menu.ts":
/*!**********************************!*\
  !*** ./src/app/services/menu.ts ***!
  \**********************************/
/*! exports provided: menu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "menu", function() { return menu; });
var appPages = [
    {
        title: '主页',
        url: '/home',
        type: 'link',
        icon: 'home',
        active: false,
    },
    {
        title: '验货任务',
        url: '/inspect-task',
        type: 'link',
        limit: 'inspect-task',
        icon: 'contract',
        active: false,
    },
    {
        title: '执行验货',
        url: '/implement-inspection',
        type: 'link',
        limit: 'implement-inspection',
        icon: 'switch',
        active: false,
    },
    {
        title: '验货评价',
        url: '/evaluate',
        type: 'link',
        limit: 'evaluate',
        icon: 'paper',
        active: false,
    },
    {
        title: '数据对比',
        url: '/data-contrast',
        type: 'link',
        limit: 'data-contrast',
        icon: 'contrast',
        active: false,
    },
    {
        title: '返工验货',
        url: '/rework-inspect',
        type: 'link',
        limit: 'rework-inspect',
        icon: 'redo',
        active: false,
    },
    {
        title: '退出',
        type: 'btn',
        icon: 'exit',
        active: false,
    },
];
var menu = appPages;


/***/ }),

/***/ "./src/app/services/page-effect.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/page-effect.service.ts ***!
  \*************************************************/
/*! exports provided: PageEffectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageEffectService", function() { return PageEffectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var PageEffectService = /** @class */ (function () {
    function PageEffectService(alertCtrl, loadCtrl, modalCtrl, actionSheetController, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.loadCtrl = loadCtrl;
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.toastCtrl = toastCtrl;
    }
    PageEffectService.prototype.showAlert = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create(option)];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.showLoad = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var load;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadCtrl.create(option)];
                    case 1:
                        load = _a.sent();
                        return [4 /*yield*/, load.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.showToast = function (option) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        option.position = 'top';
                        option.mode = 'ios';
                        option.duration = 1000;
                        return [4 /*yield*/, this.toastCtrl.create(option)];
                    case 1:
                        toast = _a.sent();
                        return [4 /*yield*/, toast.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, toast.onDidDismiss()];
                }
            });
        });
    };
    PageEffectService.prototype.showModal = function (option, callback) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal, data;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: option.component,
                            cssClass: option.cssClass,
                            componentProps: option.componentProps,
                            backdropDismiss: option.backdropDismiss === false ? option.backdropDismiss : true
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, modal.onDidDismiss()];
                    case 3:
                        data = (_a.sent()).data;
                        if (data) {
                            callback && callback(data);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.showActionSheet = function (options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var actionSheet;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.actionSheetController.create(options)];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PageEffectService.prototype.clearEffectCtrl = function () {
        var _this = this;
        this.toastCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.toastCtrl.dismiss();
            }
        });
        this.actionSheetController.getTop().then(function (e) {
            if (e && e.id) {
                _this.actionSheetController.dismiss();
            }
        });
        this.loadCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.loadCtrl.dismiss();
            }
        });
        this.alertCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.alertCtrl.dismiss();
            }
        });
        this.modalCtrl.getTop().then(function (e) {
            if (e && e.id) {
                _this.modalCtrl.dismiss();
            }
        });
    };
    PageEffectService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"] }
    ]; };
    PageEffectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"]])
    ], PageEffectService);
    return PageEffectService;
}());



/***/ }),

/***/ "./src/app/services/storage.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/storage.service.ts ***!
  \*********************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var StorageService = /** @class */ (function () {
    function StorageService() {
        this.sessionStorage = window.sessionStorage;
        if (!this.sessionStorage) {
            throw new Error('您的浏览器不支持本地存储（LocalStorage）！');
        }
    }
    StorageService.prototype.set = function (key, value) {
        this.sessionStorage.setItem(key, JSON.stringify(value));
    };
    StorageService.prototype.get = function (key) {
        var value = this.sessionStorage.getItem(key);
        try {
            value = JSON.parse(value);
        }
        catch (e) { }
        return value;
    };
    StorageService.prototype.remove = function (key) {
        this.sessionStorage.removeItem(key);
    };
    StorageService.prototype.clear = function () {
        this.sessionStorage.clear();
    };
    StorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], StorageService);
    return StorageService;
}());



/***/ }),

/***/ "./src/app/services/user-info.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/user-info.service.ts ***!
  \***********************************************/
/*! exports provided: UserInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserInfoService", function() { return UserInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var UserInfoService = /** @class */ (function () {
    function UserInfoService(storage) {
        this.storage = storage;
        this.info = {
            api_token: '',
            company_no: '',
            id: null,
            name: '',
            email: '',
            level: null,
            department: '',
        };
        this.info = this.storage.get('USER_INFO');
    }
    UserInfoService.ctorParameters = function () { return [
        { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] }
    ]; };
    UserInfoService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"]])
    ], UserInfoService);
    return UserInfoService;
}());



/***/ }),

/***/ "./src/app/widget/description/description.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/widget/description/description.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-textarea {\n  border: 1px solid #e6e6e6;\n  height: 90px;\n}\n\n.pd-15 {\n  padding: 15px;\n}\n\nion-item {\n  --border-width: 0 !important ;\n}\n\nion-radio-group div {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n  margin: 12px;\n}\n\nion-radio-group div ion-label {\n  margin-right: 6px;\n}\n\nh3 {\n  margin-bottom: 25px;\n}\n\nion-button {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC93aWRnZXQvZGVzY3JpcHRpb24vZGVzY3JpcHRpb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3dpZGdldC9kZXNjcmlwdGlvbi9kZXNjcmlwdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtBQ0NGOztBREVBO0VBQ0UsYUFBQTtBQ0NGOztBREVBO0VBQ0UsNkJBQUE7QUNDRjs7QURHRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtBQ0FKOztBRENJO0VBQ0UsaUJBQUE7QUNDTjs7QURJQTtFQUNFLG1CQUFBO0FDREY7O0FESUE7RUFDRSxZQUFBO0FDREYiLCJmaWxlIjoic3JjL2FwcC93aWRnZXQvZGVzY3JpcHRpb24vZGVzY3JpcHRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdGV4dGFyZWF7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlNmU2ZTY7XG4gIGhlaWdodDogOTBweDtcbn1cblxuLnBkLTE1e1xuICBwYWRkaW5nOiAxNXB4O1xufVxuXG5pb24taXRlbXtcbiAgLS1ib3JkZXItd2lkdGg6IDAgIWltcG9ydGFudFxufVxuXG5pb24tcmFkaW8tZ3JvdXB7XG4gIGRpdntcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgIG1hcmdpbjoxMnB4O1xuICAgIGlvbi1sYWJlbHtcbiAgICAgIG1hcmdpbi1yaWdodDogNnB4O1xuICAgIH1cbiAgfVxufVxuXG5oM3tcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbn1cblxuaW9uLWJ1dHRvbntcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuIiwiaW9uLXRleHRhcmVhIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2U2ZTZlNjtcbiAgaGVpZ2h0OiA5MHB4O1xufVxuXG4ucGQtMTUge1xuICBwYWRkaW5nOiAxNXB4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwICFpbXBvcnRhbnQgO1xufVxuXG5pb24tcmFkaW8tZ3JvdXAgZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBtYXJnaW46IDEycHg7XG59XG5pb24tcmFkaW8tZ3JvdXAgZGl2IGlvbi1sYWJlbCB7XG4gIG1hcmdpbi1yaWdodDogNnB4O1xufVxuXG5oMyB7XG4gIG1hcmdpbi1ib3R0b206IDI1cHg7XG59XG5cbmlvbi1idXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/widget/description/description.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/widget/description/description.component.ts ***!
  \*************************************************************/
/*! exports provided: DescriptionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DescriptionComponent", function() { return DescriptionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var DescriptionComponent = /** @class */ (function () {
    function DescriptionComponent(modal) {
        this.modal = modal;
    }
    Object.defineProperty(DescriptionComponent.prototype, "desc", {
        set: function (input) {
            if (!!input)
                this._desc = JSON.parse(JSON.stringify(input));
        },
        enumerable: true,
        configurable: true
    });
    DescriptionComponent.prototype.ngOnInit = function () { };
    DescriptionComponent.prototype.enter = function () {
        this.modal.dismiss(this._desc);
    };
    DescriptionComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], DescriptionComponent.prototype, "desc", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], DescriptionComponent.prototype, "type", void 0);
    DescriptionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-description',
            template: __webpack_require__(/*! raw-loader!./description.component.html */ "./node_modules/raw-loader/index.js!./src/app/widget/description/description.component.html"),
            styles: [__webpack_require__(/*! ./description.component.scss */ "./src/app/widget/description/description.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], DescriptionComponent);
    return DescriptionComponent;
}());



/***/ }),

/***/ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/widget/inspect-setting-box/inspect-setting-box.component.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-list {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC93aWRnZXQvaW5zcGVjdC1zZXR0aW5nLWJveC9pbnNwZWN0LXNldHRpbmctYm94LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC93aWRnZXQvaW5zcGVjdC1zZXR0aW5nLWJveC9pbnNwZWN0LXNldHRpbmctYm94LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvd2lkZ2V0L2luc3BlY3Qtc2V0dGluZy1ib3gvaW5zcGVjdC1zZXR0aW5nLWJveC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1saXN0IHtcbiAgICB3aWR0aDogMTAwJTtcbn1cbiIsImlvbi1saXN0IHtcbiAgd2lkdGg6IDEwMCU7XG59Il19 */"

/***/ }),

/***/ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/widget/inspect-setting-box/inspect-setting-box.component.ts ***!
  \*****************************************************************************/
/*! exports provided: InspectSettingBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectSettingBoxComponent", function() { return InspectSettingBoxComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");






var InspectSettingBoxComponent = /** @class */ (function () {
    function InspectSettingBoxComponent(modalService, storage, inspectService, effectCtrl) {
        this.modalService = modalService;
        this.storage = storage;
        this.inspectService = inspectService;
        this.effectCtrl = effectCtrl;
        this.type = '';
        this.apply_id = null;
    }
    Object.defineProperty(InspectSettingBoxComponent.prototype, "contract", {
        set: function (input) {
            this._contract = JSON.parse(JSON.stringify(input));
        },
        enumerable: true,
        configurable: true
    });
    InspectSettingBoxComponent.prototype.ngOnInit = function () { };
    InspectSettingBoxComponent.prototype.enter = function () {
        var _this = this;
        var params = {
            is_contacked_factory: this._contract.is_contacked_factory ? 1 : 0,
            is_bought_ticket: this._contract.is_bought_ticket ? 1 : 0,
            is_inspected_factory: this._contract.is_inspected_factory ? 1 : 0,
            is_inspected_product: this._contract.is_inspected_product ? 1 : 0,
            is_plan_date: this._contract.is_plan_date ? 1 : 0,
            is_know_demand: this._contract.is_know_demand ? 1 : 0,
            apply_id: this.type == 'skuList' || this.type == 'skuDetail'
                ? this.storage.get('CURRENT_INSPECT_CONTRACT').id
                : this.apply_id,
        };
        if (this.type == 'skuList' || this.type == 'skuDetail') {
            this.inspectService
                .addInspectionTaskDesc({
                apply_id: params.apply_id,
                sku: this._contract.sku,
                is_know_demand: params.is_know_demand,
                is_inspected_product: params.is_inspected_product,
            })
                .subscribe(function (data) {
                if (data.status == 1) {
                    _this.modalService.dismiss({
                        refresh: _this._contract,
                    });
                }
                else
                    _this.modalService.dismiss();
                _this.effectCtrl.showToast({
                    message: data.message,
                    color: 'success',
                });
            });
        }
        else {
            this.inspectService.inspectSetting(params).subscribe(function (data) {
                if (data.status == 1) {
                    _this.modalService.dismiss({
                        refresh: _this._contract,
                    });
                }
                else
                    _this.modalService.dismiss();
                _this.effectCtrl.showToast({
                    message: data.message,
                    color: 'success',
                });
            });
        }
    };
    InspectSettingBoxComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
        { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] },
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], InspectSettingBoxComponent.prototype, "contract", null);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], InspectSettingBoxComponent.prototype, "type", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], InspectSettingBoxComponent.prototype, "apply_id", void 0);
    InspectSettingBoxComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-inspect-setting-box',
            template: __webpack_require__(/*! raw-loader!./inspect-setting-box.component.html */ "./node_modules/raw-loader/index.js!./src/app/widget/inspect-setting-box/inspect-setting-box.component.html"),
            styles: [__webpack_require__(/*! ./inspect-setting-box.component.scss */ "./src/app/widget/inspect-setting-box/inspect-setting-box.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"],
            src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__["InspectionService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_2__["PageEffectService"]])
    ], InspectSettingBoxComponent);
    return InspectSettingBoxComponent;
}());



/***/ }),

/***/ "./src/app/widget/parts/parts.component.scss":
/*!***************************************************!*\
  !*** ./src/app/widget/parts/parts.component.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3dpZGdldC9wYXJ0cy9wYXJ0cy5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/widget/parts/parts.component.ts":
/*!*************************************************!*\
  !*** ./src/app/widget/parts/parts.component.ts ***!
  \*************************************************/
/*! exports provided: PartsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PartsComponent", function() { return PartsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PartsComponent = /** @class */ (function () {
    function PartsComponent() {
    }
    Object.defineProperty(PartsComponent.prototype, "sku", {
        set: function (input) {
            if (!!input)
                this._data = input;
        },
        enumerable: true,
        configurable: true
    });
    PartsComponent.prototype.ngOnInit = function () { };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], PartsComponent.prototype, "sku", null);
    PartsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-parts',
            template: __webpack_require__(/*! raw-loader!./parts.component.html */ "./node_modules/raw-loader/index.js!./src/app/widget/parts/parts.component.html"),
            styles: [__webpack_require__(/*! ./parts.component.scss */ "./src/app/widget/parts/parts.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PartsComponent);
    return PartsComponent;
}());



/***/ }),

/***/ "./src/app/widget/scan/scan.component.scss":
/*!*************************************************!*\
  !*** ./src/app/widget/scan/scan.component.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".qrscanner {\n  background: none;\n}\n.qrscanner-area {\n  width: 100%;\n  height: 86%;\n  background: url('scanner.svg') no-repeat center center;\n  background-size: contain;\n}\n.through-line {\n  left: 25%;\n  width: 50%;\n  height: 2px;\n  background: red;\n  position: absolute;\n  -webkit-animation: myfirst 2s linear infinite alternate;\n          animation: myfirst 2s linear infinite alternate;\n}\n@-webkit-keyframes myfirst {\n  0% {\n    background: red;\n    top: 30%;\n  }\n  25% {\n    background: yellow;\n    top: 35%;\n  }\n  50% {\n    background: blue;\n    top: 40%;\n  }\n  75% {\n    background: green;\n    top: 45%;\n  }\n  100% {\n    background: red;\n    top: 50%;\n  }\n}\n@keyframes myfirst {\n  0% {\n    background: red;\n    top: 30%;\n  }\n  25% {\n    background: yellow;\n    top: 35%;\n  }\n  50% {\n    background: blue;\n    top: 40%;\n  }\n  75% {\n    background: green;\n    top: 45%;\n  }\n  100% {\n    background: red;\n    top: 50%;\n  }\n}\n.button-bottom {\n  width: 130px;\n  position: absolute;\n  left: 50%;\n  bottom: 1.8rem;\n  margin-left: -60px;\n}\n.button-bottom .icon-camera {\n  float: left;\n}\n.button-bottom ion-fab-button:last-child {\n  margin-left: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC93aWRnZXQvc2Nhbi9zY2FuLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC93aWRnZXQvc2Nhbi9zY2FuLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUNDSjtBREFJO0VBQ0ksV0FBQTtFQUNBLFdBQUE7RUFDQSxzREFBQTtFQUNBLHdCQUFBO0FDRVI7QURDQTtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHVEQUFBO1VBQUEsK0NBQUE7QUNFSjtBREFBO0VBQ0k7SUFDSSxlQUFBO0lBQ0EsUUFBQTtFQ0dOO0VEREU7SUFDSSxrQkFBQTtJQUNBLFFBQUE7RUNHTjtFRERFO0lBQ0ksZ0JBQUE7SUFDQSxRQUFBO0VDR047RURERTtJQUNJLGlCQUFBO0lBQ0EsUUFBQTtFQ0dOO0VEREU7SUFDSSxlQUFBO0lBQ0EsUUFBQTtFQ0dOO0FBQ0Y7QUR2QkE7RUFDSTtJQUNJLGVBQUE7SUFDQSxRQUFBO0VDR047RURERTtJQUNJLGtCQUFBO0lBQ0EsUUFBQTtFQ0dOO0VEREU7SUFDSSxnQkFBQTtJQUNBLFFBQUE7RUNHTjtFRERFO0lBQ0ksaUJBQUE7SUFDQSxRQUFBO0VDR047RURERTtJQUNJLGVBQUE7SUFDQSxRQUFBO0VDR047QUFDRjtBRERBO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0dKO0FERkk7RUFDSSxXQUFBO0FDSVI7QURGSTtFQUNJLGlCQUFBO0FDSVIiLCJmaWxlIjoic3JjL2FwcC93aWRnZXQvc2Nhbi9zY2FuLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnFyc2Nhbm5lciB7XG4gICAgYmFja2dyb3VuZDogbm9uZTtcbiAgICAmLWFyZWEge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiA4NiU7XG4gICAgICAgIGJhY2tncm91bmQ6IHVybCgnLi4vLi4vLi4vYXNzZXRzL2ljb24vc2Nhbm5lci5zdmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlcjtcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xuICAgIH1cbn1cbi50aHJvdWdoLWxpbmUge1xuICAgIGxlZnQ6IDI1JTtcbiAgICB3aWR0aDogNTAlO1xuICAgIGhlaWdodDogMnB4O1xuICAgIGJhY2tncm91bmQ6IHJlZDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYW5pbWF0aW9uOiBteWZpcnN0IDJzIGxpbmVhciBpbmZpbml0ZSBhbHRlcm5hdGU7XG59XG5Aa2V5ZnJhbWVzIG15Zmlyc3Qge1xuICAgIDAlIHtcbiAgICAgICAgYmFja2dyb3VuZDogcmVkO1xuICAgICAgICB0b3A6IDMwJTtcbiAgICB9XG4gICAgMjUlIHtcbiAgICAgICAgYmFja2dyb3VuZDogeWVsbG93O1xuICAgICAgICB0b3A6IDM1JTtcbiAgICB9XG4gICAgNTAlIHtcbiAgICAgICAgYmFja2dyb3VuZDogYmx1ZTtcbiAgICAgICAgdG9wOiA0MCU7XG4gICAgfVxuICAgIDc1JSB7XG4gICAgICAgIGJhY2tncm91bmQ6IGdyZWVuO1xuICAgICAgICB0b3A6IDQ1JTtcbiAgICB9XG4gICAgMTAwJSB7XG4gICAgICAgIGJhY2tncm91bmQ6IHJlZDtcbiAgICAgICAgdG9wOiA1MCU7XG4gICAgfVxufVxuLmJ1dHRvbi1ib3R0b20ge1xuICAgIHdpZHRoOiAxMzBweDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNTAlO1xuICAgIGJvdHRvbTogMS44cmVtO1xuICAgIG1hcmdpbi1sZWZ0OiAtNjBweDtcbiAgICAuaWNvbi1jYW1lcmEge1xuICAgICAgICBmbG9hdDogbGVmdDtcbiAgICB9XG4gICAgaW9uLWZhYi1idXR0b246bGFzdC1jaGlsZCB7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICAgIH1cbn1cbiIsIi5xcnNjYW5uZXIge1xuICBiYWNrZ3JvdW5kOiBub25lO1xufVxuLnFyc2Nhbm5lci1hcmVhIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogODYlO1xuICBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi8uLi9hc3NldHMvaWNvbi9zY2FubmVyLnN2Z1wiKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xufVxuXG4udGhyb3VnaC1saW5lIHtcbiAgbGVmdDogMjUlO1xuICB3aWR0aDogNTAlO1xuICBoZWlnaHQ6IDJweDtcbiAgYmFja2dyb3VuZDogcmVkO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGFuaW1hdGlvbjogbXlmaXJzdCAycyBsaW5lYXIgaW5maW5pdGUgYWx0ZXJuYXRlO1xufVxuXG5Aa2V5ZnJhbWVzIG15Zmlyc3Qge1xuICAwJSB7XG4gICAgYmFja2dyb3VuZDogcmVkO1xuICAgIHRvcDogMzAlO1xuICB9XG4gIDI1JSB7XG4gICAgYmFja2dyb3VuZDogeWVsbG93O1xuICAgIHRvcDogMzUlO1xuICB9XG4gIDUwJSB7XG4gICAgYmFja2dyb3VuZDogYmx1ZTtcbiAgICB0b3A6IDQwJTtcbiAgfVxuICA3NSUge1xuICAgIGJhY2tncm91bmQ6IGdyZWVuO1xuICAgIHRvcDogNDUlO1xuICB9XG4gIDEwMCUge1xuICAgIGJhY2tncm91bmQ6IHJlZDtcbiAgICB0b3A6IDUwJTtcbiAgfVxufVxuLmJ1dHRvbi1ib3R0b20ge1xuICB3aWR0aDogMTMwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogNTAlO1xuICBib3R0b206IDEuOHJlbTtcbiAgbWFyZ2luLWxlZnQ6IC02MHB4O1xufVxuLmJ1dHRvbi1ib3R0b20gLmljb24tY2FtZXJhIHtcbiAgZmxvYXQ6IGxlZnQ7XG59XG4uYnV0dG9uLWJvdHRvbSBpb24tZmFiLWJ1dHRvbjpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/widget/scan/scan.component.ts":
/*!***********************************************!*\
  !*** ./src/app/widget/scan/scan.component.ts ***!
  \***********************************************/
/*! exports provided: ScanComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScanComponent", function() { return ScanComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/page-effect.service */ "./src/app/services/page-effect.service.ts");





var ScanComponent = /** @class */ (function () {
    function ScanComponent(barcodeScanner, modalCtrl, es) {
        this.barcodeScanner = barcodeScanner;
        this.modalCtrl = modalCtrl;
        this.es = es;
    }
    ScanComponent.prototype.ngOnInit = function () { };
    ScanComponent.prototype.ionViewDidEnter = function () {
        var _this = this;
        this.barcodeScanner
            .scan()
            .then(function (barcodeData) {
            console.log(barcodeData);
            _this.modalCtrl.dismiss({
                value: barcodeData.text,
            });
        })
            .catch(function (err) {
            console.log('Error', err);
        });
    };
    ScanComponent.ctorParameters = function () { return [
        { type: _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__["BarcodeScanner"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
        { type: src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"] }
    ]; };
    ScanComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-scan',
            template: __webpack_require__(/*! raw-loader!./scan.component.html */ "./node_modules/raw-loader/index.js!./src/app/widget/scan/scan.component.html"),
            styles: [__webpack_require__(/*! ./scan.component.scss */ "./src/app/widget/scan/scan.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__["BarcodeScanner"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            src_app_services_page_effect_service__WEBPACK_IMPORTED_MODULE_4__["PageEffectService"]])
    ], ScanComponent);
    return ScanComponent;
}());



/***/ }),

/***/ "./src/app/widget/video-play/video-play.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/widget/video-play/video-play.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3dpZGdldC92aWRlby1wbGF5L3ZpZGVvLXBsYXkuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/widget/video-play/video-play.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/widget/video-play/video-play.component.ts ***!
  \***********************************************************/
/*! exports provided: VideoPlayComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VideoPlayComponent", function() { return VideoPlayComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");




var VideoPlayComponent = /** @class */ (function () {
    function VideoPlayComponent(modal) {
        this.modal = modal;
        this.origin = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].usFileUrl;
    }
    Object.defineProperty(VideoPlayComponent.prototype, "source", {
        set: function (input) {
            if (!!input) {
                this._source = this.origin + '/' + input;
            }
        },
        enumerable: true,
        configurable: true
    });
    VideoPlayComponent.prototype.ngOnInit = function () { };
    VideoPlayComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
    ], VideoPlayComponent.prototype, "source", null);
    VideoPlayComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-video-play',
            template: __webpack_require__(/*! raw-loader!./video-play.component.html */ "./node_modules/raw-loader/index.js!./src/app/widget/video-play/video-play.component.html"),
            styles: [__webpack_require__(/*! ./video-play.component.scss */ "./src/app/widget/video-play/video-play.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], VideoPlayComponent);
    return VideoPlayComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.p w z wrod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    apiUrl: 'http://192.168.1.114/api/v1',
    fileUrlPath: 'http://keyi.xdrlgroup.com',
    usFileUrl: 'http://192.168.1.114/',
    origin: 'http://192.168.1.108'
    // apiUrl: 'http://121.196.179.68/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://121.196.179.68/',
    // origin:'http://121.196.179.68'
    // apiUrl: 'http://121.196.179.68:8081/api/v1',
    // fileUrlPath: 'http://keyi.xdrlgroup.com',
    // usFileUrl: 'http://121.196.179.68:8081/',
    // origin: 'http://121.196.179.68:8081',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])()
    .bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Volumes/Macintosh HD - 数据/web/hawkeye-mobile/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es5.js.map