(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/login/login.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/login/login.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div class=\"back\"></div>\n    <div class=\"content_box pos-r\">\n        <ion-card mode=\"ios\">\n            <div class=\"logo-box\">\n                <img src=\"../../assets/img/logo.png\" alt=\"\" class=\"logo\" />\n            </div>\n            <form [formGroup]=\"registerForm\">\n                <ion-list vertical-center>\n                    <ion-item>\n                        <ion-label position=\"floating\">工号</ion-label>\n                        <ion-input\n                            type=\"text\"\n                            [(ngModel)]=\"loginInfo.company_no\"\n                            formControlName=\"company_no\"\n                            clearInput=\"true\"\n                        ></ion-input>\n                    </ion-item>\n                    <span *ngIf=\"formErrors.company_no\" class=\"showerr alert-danger\">{{ formErrors.company_no }}</span>\n\n                    <ion-item>\n                        <ion-label position=\"floating\">密码</ion-label>\n                        <ion-input\n                            type=\"password\"\n                            [(ngModel)]=\"loginInfo.password\"\n                            formControlName=\"password\"\n                            clearInput=\"true\"\n                        ></ion-input>\n                    </ion-item>\n                    <span *ngIf=\"formErrors.password\" class=\"showerr alert-danger\">{{ formErrors.password }}</span>\n                </ion-list>\n\n                <div class=\"mt-30\">\n                    <ion-button\n                        events=\"ionBur\"\n                        type=\"submit\"\n                        color=\"secondary\"\n                        [disabled]=\"\n                        !registerForm.value.company_no ||\n                        formErrors.company_no ||\n                        !registerForm.value.password||\n                        isClick\n                        \"\n                        expand=\"block\"\n                        *ngIf=\"status == 'login'\"\n                        (click)=\"doLogin()\"\n                        >登录\n                    </ion-button>\n                </div>\n            </form>\n        </ion-card>\n\n        <div class=\"bottom-tips\">\n            <span>当前版本：</span>\n            <span>Inspect-meta</span>\n        </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/login/login.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");
/* harmony import */ var _ionic_native_secure_storage_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/secure-storage/ngx */ "./node_modules/@ionic-native/secure-storage/ngx/index.js");








const routes = [
    {
        path: 'login',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"],
    },
];
let LoginPageModule = class LoginPageModule {
};
LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ReactiveFormsModule"]],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]],
        providers: [_ionic_native_secure_storage_ngx__WEBPACK_IMPORTED_MODULE_7__["SecureStorage"]],
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: rgb(247, 247, 247);\n  z-index: 2;\n}\nion-content .content_box {\n  top: -50px;\n}\nion-content .content_box ion-card {\n  background: #fff;\n  width: 500px;\n  padding: 20px 100px;\n  margin: 0 auto;\n}\nion-content .mt-30 {\n  margin-top: 30px !important;\n}\n.back {\n  width: 100;\n  height: 250px;\n  background: url('back.png') no-repeat;\n  background-size: cover;\n}\n.logo-box {\n  margin-top: 3rem;\n  width: 100%;\n  text-align: center;\n}\n.logo-box .logo {\n  width: 5rem;\n  display: inline-block;\n  margin-bottom: 0.5rem;\n}\n.showerr {\n  text-align: left;\n  font-size: 12px;\n  color: #f00;\n  padding-left: 15px;\n  background: 0;\n}\n.custom-loading {\n  color: #f00;\n}\nform {\n  width: 100%;\n  margin: 0 auto;\n}\nion-list {\n  background: transparent;\n}\nion-label {\n  --color: #333;\n}\nion-item {\n  --background: transparent;\n  color: #333;\n}\nion-input {\n  --color: #333;\n}\n@media screen and (min-width: 800px) {\n  .logo-box {\n    margin-top: 1rem;\n  }\n\n  form {\n    width: 300px;\n  }\n}\n@media screen and (min-width: 1080px) {\n  .logo-box {\n    margin-top: 6rem;\n  }\n\n  form {\n    width: 300px;\n  }\n}\n.bottom-tips {\n  text-align: center;\n  position: fixed;\n  width: 100%;\n  font-size: 12px;\n  color: #656565;\n  bottom: 2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdDQUFBO0VBQ0EsVUFBQTtBQ0NKO0FEQUk7RUFDSSxVQUFBO0FDRVI7QUREUTtFQUNJLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0daO0FEQUk7RUFDSSwyQkFBQTtBQ0VSO0FERUE7RUFDSSxVQUFBO0VBQ0EsYUFBQTtFQUNBLHFDQUFBO0VBQ0Esc0JBQUE7QUNDSjtBREVBO0VBQ0ksZ0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNDSjtBREFJO0VBQ0ksV0FBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7QUNFUjtBREVBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQ0NKO0FEQ0E7RUFDSSxXQUFBO0FDRUo7QURDQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FDRUo7QURDQTtFQUNJLHVCQUFBO0FDRUo7QURBQTtFQUNJLGFBQUE7QUNHSjtBRERBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0FDSUo7QUREQTtFQUNJLGFBQUE7QUNJSjtBRERBO0VBQ0k7SUFDSSxnQkFBQTtFQ0lOOztFREZFO0lBQ0ksWUFBQTtFQ0tOO0FBQ0Y7QURGQTtFQUNJO0lBQ0ksZ0JBQUE7RUNJTjs7RURGRTtJQUNJLFlBQUE7RUNLTjtBQUNGO0FERkE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FDSUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjQ3LCAyNDcsIDI0Nyk7XG4gICAgei1pbmRleDogMjtcbiAgICAuY29udGVudF9ib3gge1xuICAgICAgICB0b3A6IC01MHB4O1xuICAgICAgICBpb24tY2FyZCB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgICAgICAgICAgd2lkdGg6IDUwMHB4O1xuICAgICAgICAgICAgcGFkZGluZzogMjBweCAxMDBweDtcbiAgICAgICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICB9XG4gICAgfVxuICAgIC5tdC0zMCB7XG4gICAgICAgIG1hcmdpbi10b3A6IDMwcHggIWltcG9ydGFudDtcbiAgICB9XG59XG5cbi5iYWNrIHtcbiAgICB3aWR0aDogMTAwO1xuICAgIGhlaWdodDogMjUwcHg7XG4gICAgYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi9hc3NldHMvaW1nL2JhY2sucG5nJykgbm8tcmVwZWF0O1xuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5sb2dvLWJveCB7XG4gICAgbWFyZ2luLXRvcDogM3JlbTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLmxvZ28ge1xuICAgICAgICB3aWR0aDogNXJlbTtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XG4gICAgfVxufVxuXG4uc2hvd2VyciB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgY29sb3I6ICNmMDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNXB4O1xuICAgIGJhY2tncm91bmQ6IDA7XG59XG4uY3VzdG9tLWxvYWRpbmcge1xuICAgIGNvbG9yOiAjZjAwO1xufVxuXG5mb3JtIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW46IDAgYXV0bztcbn1cblxuaW9uLWxpc3Qge1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWxhYmVsIHtcbiAgICAtLWNvbG9yOiAjMzMzO1xufVxuaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgY29sb3I6ICMzMzM7XG59XG5cbmlvbi1pbnB1dCB7XG4gICAgLS1jb2xvcjogIzMzMztcbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogODAwcHgpIHtcbiAgICAubG9nby1ib3gge1xuICAgICAgICBtYXJnaW4tdG9wOiAxcmVtO1xuICAgIH1cbiAgICBmb3JtIHtcbiAgICAgICAgd2lkdGg6IDMwMHB4O1xuICAgIH1cbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTA4MHB4KSB7XG4gICAgLmxvZ28tYm94IHtcbiAgICAgICAgbWFyZ2luLXRvcDogNnJlbTtcbiAgICB9XG4gICAgZm9ybSB7XG4gICAgICAgIHdpZHRoOiAzMDBweDtcbiAgICB9XG59XG5cbi5ib3R0b20tdGlwc3tcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBjb2xvcjogIzY1NjU2NTtcbiAgICBib3R0b206IDJyZW07XG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHJnYigyNDcsIDI0NywgMjQ3KTtcbiAgei1pbmRleDogMjtcbn1cbmlvbi1jb250ZW50IC5jb250ZW50X2JveCB7XG4gIHRvcDogLTUwcHg7XG59XG5pb24tY29udGVudCAuY29udGVudF9ib3ggaW9uLWNhcmQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB3aWR0aDogNTAwcHg7XG4gIHBhZGRpbmc6IDIwcHggMTAwcHg7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuaW9uLWNvbnRlbnQgLm10LTMwIHtcbiAgbWFyZ2luLXRvcDogMzBweCAhaW1wb3J0YW50O1xufVxuXG4uYmFjayB7XG4gIHdpZHRoOiAxMDA7XG4gIGhlaWdodDogMjUwcHg7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uLy4uL2Fzc2V0cy9pbWcvYmFjay5wbmdcIikgbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4ubG9nby1ib3gge1xuICBtYXJnaW4tdG9wOiAzcmVtO1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmxvZ28tYm94IC5sb2dvIHtcbiAgd2lkdGg6IDVyZW07XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xufVxuXG4uc2hvd2VyciB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICNmMDA7XG4gIHBhZGRpbmctbGVmdDogMTVweDtcbiAgYmFja2dyb3VuZDogMDtcbn1cblxuLmN1c3RvbS1sb2FkaW5nIHtcbiAgY29sb3I6ICNmMDA7XG59XG5cbmZvcm0ge1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG5cbmlvbi1saXN0IHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIC0tY29sb3I6ICMzMzM7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgY29sb3I6ICMzMzM7XG59XG5cbmlvbi1pbnB1dCB7XG4gIC0tY29sb3I6ICMzMzM7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDgwMHB4KSB7XG4gIC5sb2dvLWJveCB7XG4gICAgbWFyZ2luLXRvcDogMXJlbTtcbiAgfVxuXG4gIGZvcm0ge1xuICAgIHdpZHRoOiAzMDBweDtcbiAgfVxufVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTA4MHB4KSB7XG4gIC5sb2dvLWJveCB7XG4gICAgbWFyZ2luLXRvcDogNnJlbTtcbiAgfVxuXG4gIGZvcm0ge1xuICAgIHdpZHRoOiAzMDBweDtcbiAgfVxufVxuLmJvdHRvbS10aXBzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjNjU2NTY1O1xuICBib3R0b206IDJyZW07XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage, loginInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginInfo", function() { return loginInfo; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/menu.service */ "./src/app/services/menu.service.ts");
/* harmony import */ var _services_user_rights_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/user-rights.service */ "./src/app/services/user-rights.service.ts");
/* harmony import */ var _services_user_info_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../services/user-info.service */ "./src/app/services/user-info.service.ts");
/* harmony import */ var _services_http_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../services/http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../implement-inspection/upload-queue.service */ "./src/app/pages/implement-inspection/upload-queue.service.ts");











let LoginPage = class LoginPage {
    constructor(Router, fb, el, http, userInfo, rights, menu, storage, effectCtrl, uQueue) {
        this.Router = Router;
        this.fb = fb;
        this.el = el;
        this.http = http;
        this.userInfo = userInfo;
        this.rights = rights;
        this.menu = menu;
        this.storage = storage;
        this.effectCtrl = effectCtrl;
        this.uQueue = uQueue;
        this.status = 'login';
        this.loginInfo = new loginInfo('', '');
        // 表单验证不通过时显示的错误消息
        this.formErrors = {
            username: '',
            company_no: '',
            password: '',
            password_confirmation: '',
        };
        // 为每一项表单验证添加说明文字
        this.validationMessage = {
            username: {
                minlength: '用户名长度最少为2个字符',
                maxlength: '用户名长度最多为10个字符',
                required: '请填写用户名',
            },
            company_no: {
                required: '请填写工号',
                pattern: '不是工号格式',
            },
            password: {
                required: '请输入密码',
            },
            password_confirmation: {
                required: '请再次输入密码',
                atypism: '两次输入不一致',
                notPwd: '请先输入密码',
            },
        };
        this.isClick = false;
    }
    // 构建表单方法
    buildForm() {
        // 通过 formBuilder构建表单
        this.registerForm = this.fb.group({
            /* 为 username 添加3项验证规则：
             * 1.必填， 2.最大长度为10， 3.最小长度为3， 4.不能以下划线开头， 5.只能包含数字、字母、下划线
             * 其中第一个空字符串参数为表单的默认值
             */
            username: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].minLength(2)]],
            company_no: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].pattern(/['X']['D'][0-9][0-9][0-9]/g)]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required]],
            password_confirmation: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required]],
        });
        // 每次表单数据发生变化的时候更新错误信息
        this.registerForm.valueChanges.subscribe(data => {
            this.onValueChanged(data);
            if (data.password_confirmation && !data.password) {
                this.formErrors['password_confirmation'] += this.validationMessage['password_confirmation']['notPwd'];
            }
            if (data.password_confirmation && data.password && data.password_confirmation !== data.password) {
                this.formErrors['password_confirmation'] += this.validationMessage['password_confirmation']['atypism'];
            }
        });
        // 初始化错误信息
        this.onValueChanged();
    }
    // 每次数据发生改变时触发此方法
    onValueChanged(data) {
        // 如果表单不存在则返回
        if (!this.registerForm)
            return;
        // 获取当前的表单
        const form = this.registerForm;
        // 遍历错误消息对象
        for (const field in this.formErrors) {
            // 清空当前的错误消息
            this.formErrors[field] = '';
            // 获取当前表单的控件
            const control = form.get(field);
            // 当前表单存在此空间控件 && 此控件没有被修改 && 此控件验证不通过
            if (control && control.dirty && !control.valid) {
                // 获取验证不通过的控件名，为了获取更详细的不通过信息
                const messages = this.validationMessage[field];
                // 遍历当前控件的错误对象，获取到验证不通过的属性
                for (const key in control.errors) {
                    // 把所有验证不通过项的说明文字拼接成错误消息
                    this.formErrors[field] += messages[key] + '\n';
                }
            }
        }
    }
    ngOnInit() {
        this.buildForm();
        let userInfo = this.storage.get('USER_INFO');
        if (userInfo) {
            this.storage.remove('USER_INFO');
            this.storage.remove('PERMISSION');
        }
        let account = JSON.parse(localStorage.getItem('HAWKEYE_ACCOUNT')), pwd = JSON.parse(localStorage.getItem('HAWKEYE_PASSWORD'));
        if (account && pwd) {
            this.loginInfo.company_no = account;
            this.loginInfo.password = pwd;
        }
    }
    ngAfterViewInit() {
        this.rememberPwdBug();
    }
    rememberPwdBug() {
        setTimeout(() => {
            let inputGroup = this.el.nativeElement.querySelectorAll('ion-input');
            inputGroup.forEach(element => {
                element.children[0].style = '';
            });
        }, 2000);
    }
    doLogin() {
        this.isClick = true;
        this.effectCtrl
            .showLoad({
            spinner: null,
            duration: 0,
            message: '正在登录……',
            translucent: false,
        })
            .then(() => {
            let params = JSON.parse(JSON.stringify(this.loginInfo));
            this.http.post({ url: '/login', params: params }, true)
                .subscribe(data => {
                this.effectCtrl.loadCtrl.dismiss();
                this.isClick = false;
                let base = data;
                if (base.status == 0) {
                    this.effectCtrl.showAlert({
                        message: '登陆失败！',
                        header: '提示',
                        buttons: ['确定'],
                        subHeader: '',
                    });
                }
                else {
                    this.userInfo.info = base.data;
                    this.rights.rights = base.permission.data;
                    this.storage.set('USER_INFO', this.userInfo.info);
                    this.storage.set('PERMISSION', this.rights.rights);
                    //判断是否是第一次登录
                    this.userInfo.info.is_first = base.is_first;
                    //判断是否是验货人
                    this.Router.navigate(['/home']);
                    this.menu.setMenuChange(true);
                    localStorage.setItem('HAWKEYE_ACCOUNT', JSON.stringify(this.loginInfo.company_no));
                    localStorage.setItem('HAWKEYE_PASSWORD', JSON.stringify(this.loginInfo.password));
                }
            });
        });
        setTimeout(() => {
            this.isClick = false;
        }, 12000);
    }
    ionViewCanLeave() {
        this.effectCtrl.clearEffectCtrl();
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"] },
    { type: _services_http_service__WEBPACK_IMPORTED_MODULE_5__["HttpService"] },
    { type: _services_user_info_service__WEBPACK_IMPORTED_MODULE_4__["UserInfoService"] },
    { type: _services_user_rights_service__WEBPACK_IMPORTED_MODULE_3__["UserRightsService"] },
    { type: _services_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenuService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] },
    { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_9__["PageEffectService"] },
    { type: _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_10__["UploadQueueService"] }
];
LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-login',
        template: __webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/login/login.page.html"),
        styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"],
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"],
        _services_http_service__WEBPACK_IMPORTED_MODULE_5__["HttpService"],
        _services_user_info_service__WEBPACK_IMPORTED_MODULE_4__["UserInfoService"],
        _services_user_rights_service__WEBPACK_IMPORTED_MODULE_3__["UserRightsService"],
        _services_menu_service__WEBPACK_IMPORTED_MODULE_2__["MenuService"],
        _services_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"],
        _services_page_effect_service__WEBPACK_IMPORTED_MODULE_9__["PageEffectService"],
        _implement_inspection_upload_queue_service__WEBPACK_IMPORTED_MODULE_10__["UploadQueueService"]])
], LoginPage);

class loginInfo {
    constructor(company_no, password) {
        this.company_no = company_no;
        this.password = password;
    }
}
loginInfo.ctorParameters = () => [
    { type: String },
    { type: String }
];


/***/ }),

/***/ "./src/app/services/user-rights.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/user-rights.service.ts ***!
  \*************************************************/
/*! exports provided: UserRightsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRightsService", function() { return UserRightsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");



let UserRightsService = class UserRightsService {
    constructor(storage) {
        this.storage = storage;
        this.rights = this.storage.get('PERMISSION');
    }
};
UserRightsService.ctorParameters = () => [
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"] }
];
UserRightsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_service__WEBPACK_IMPORTED_MODULE_1__["StorageService"]])
], UserRightsService);



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module-es2015.js.map