(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-inspection-inspection-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspection/acc-inspec/acc-inspec.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspection/acc-inspec/acc-inspec.page.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"secondary\">\n            <ion-button>\n                <i class=\"iconfont iconfanhui\"></i>\n                <ion-label class=\"global-back-text\">返回</ion-label>\n            </ion-button>\n        </ion-buttons>\n\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n\n        <ion-title>\n            {{title}}\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <form action=\"\">\n        <div *ngFor=\"let item of accInspArray\">\n            <div class=\"inspection-item\" *ngFor=\"let sItem of item.data\">\n                <div class=\"form-group mb-0\">\n                    <label class=\"col-sm-2 control-label\">包装类型</label>\n                    <div class=\"col-sm-8 flex-box clearfix\">\n                        <input\n                            name=\"PackingType\"\n                            type=\"text\"\n                            class=\"form-control\"\n                            required\n                            [(ngModel)]=\"sItem.PackingType\"\n                            placeholder=\"请输入包装类型\"\n                        />\n                        <!-- <div [hidden]='name.pristine || name.valid' class=\"showerr alert-danger\">请输入名称</div> -->\n                    </div>\n                </div>\n            </div>\n\n            <div class=\"inspection-item\" *ngFor=\"let sItem of item.data\">\n                <div class=\"form-group mb-0\">\n                    <label class=\"col-sm-2 control-label\">条形码</label>\n                    <div class=\"col-sm-8 flex-box clearfix\">\n                        <input\n                            name=\"BarCode\"\n                            type=\"text\"\n                            class=\"form-control\"\n                            required\n                            [(ngModel)]=\"sItem.BarCode\"\n                            placeholder=\"请输入条形码\"\n                        />\n                        <!-- <div [hidden]='name.pristine || name.valid' class=\"showerr alert-danger\">请输入名称</div> -->\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <ion-button (click)=\"submit()\" [expand]='\"block\"' color=\"dark\">提交</ion-button>\n    </form>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/inspection/inspection/inspection.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/inspection/inspection/inspection.page.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"secondary\">\n            <ion-back-button defaultHref=\"home\" text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button>\n        </ion-buttons>\n\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n\n        <ion-title>\n            {{title}}\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <form action=\"\" *ngIf='type==\"undone\"'>\n        <div class=\"inspection-item\" *ngIf=\"inspectionInfoMetaData.sku_sys.RateContainer !='1'\">\n            <div class=\"form-group mb-0\">\n                <label for=\"inputEmail3\" class=\"col-sm-2 control-label\">外箱长宽高(CM)</label>\n                <div class=\"col-sm-8 flex-box clearfix\">\n                    <ion-input\n                        name=\"PackingSizeLength\"\n                        type=\"number\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.PackingSizeLength\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入长(cm)\"\n                    >\n                    </ion-input>\n                    <ion-input\n                        name=\"PackingSizeWidth\"\n                        type=\"number\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.PackingSizeWidth\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入宽(cm)\"\n                    >\n                    </ion-input>\n                    <ion-input\n                        name=\"PackingSizeHight\"\n                        type=\"number\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.PackingSizeHight\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入高(cm)\"\n                    >\n                    </ion-input>\n                    <!-- <div [hidden]='name.pristine || name.valid' class=\"showerr alert-danger\">请输入名称</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\">\n            <div class=\"form-group mb-0\">\n                <label class=\"col-sm-2 control-label\">内箱长宽高(CM)</label>\n                <div class=\"col-sm-8 flex-box clearfix\">\n                    <ion-input\n                        name=\"SinglePackingSizeLength \"\n                        type=\"number\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.SinglePackingSizeLength\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入长(cm)\"\n                    >\n                    </ion-input>\n                    <ion-input\n                        name=\"SinglePackingSizeWidth \"\n                        type=\"number\"\n                        class=\"form-control\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.SinglePackingSizeWidth\"\n                        required\n                        placeholder=\"请输入宽(cm)\"\n                    >\n                    </ion-input>\n                    <ion-input\n                        name=\"SinglePackingSizeHight\"\n                        type=\"number\"\n                        class=\"form-control\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.SinglePackingSizeHight\"\n                        required\n                        placeholder=\"请输入高(cm)\"\n                    >\n                    </ion-input>\n                    <!-- <div [hidden]='name.pristine || name.valid' class=\"showerr alert-danger\">请输入名称</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">条形码</label>\n                <div class=\"col-sm-8\">\n                    <input\n                        name=\"BarCode\"\n                        type=\"text\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.BarCode\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入条形码\"\n                    />\n                    <!-- <div [hidden]='route.pristine || route.valid' class=\"showerr alert-danger\">请输入条码</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\" *ngIf='inspectionInfoMetaData.sku_sys.RateContainer !=\"1\"'>\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">外箱条形码</label>\n                <div class=\"col-sm-8\">\n                    <input\n                        name=\"OutsideBarCode\"\n                        type=\"text\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.OutsideBarCode\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入外箱条形码\"\n                    />\n                    <!-- <div [hidden]='route.pristine || route.valid' class=\"showerr alert-danger\">请输入条码</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">单个毛重(KG) </label>\n                <div class=\"col-sm-8\">\n                    <input\n                        name=\"RoughWeight\"\n                        type=\"text\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.RoughWeight\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入单个毛重(KG)\"\n                    />\n                    <!-- <div [hidden]='route.pristine || route.valid' class=\"showerr alert-danger\">请输入条码</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\" *ngIf=\"inspectionInfoMetaData.sku_sys.RateContainer !='1'\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">外箱毛重(KG) </label>\n                <div class=\"col-sm-8\">\n                    <input\n                        name=\"NetWeight\"\n                        type=\"number\"\n                        [(ngModel)]=\"inspectionInfo.sku_sys.NetWeight\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入外箱毛重(KG)\"\n                    />\n                    <!-- <div [hidden]='route.pristine || route.valid' class=\"showerr alert-danger\">请输入条码</div> -->\n                </div>\n            </div>\n        </div>\n\n        <div class=\"inspection-item\" *ngFor=\"let item of inspectionInfo.sku_other;let idx=index\">\n            <div class=\"form-group\">\n                <label class=\"col-sm-2 control-label\">{{item.InspectionRequiremen}} </label>\n                <ul class=\"sku_other_imgbox\" imgGallery>\n                    <li *ngFor=\"let sItem of item.pic\">\n                        <img [src]=\"fileUrl + sItem\" alt=\"\" />\n                    </li>\n                </ul>\n\n                <div class=\"col-sm-2 ion_select\">\n                    <ion-select\n                        [interfaceOptions]=\"{translucent: true}\"\n                        interface=\"popover\"\n                        value=\"1\"\n                        name=\"other0+{{idx}}\"\n                        [selectedText]='item.is_standard == 0 ? \"不合格\" : \"合格\"'\n                        [compareWith]=\"locationCompare\"\n                        [(ngModel)]=\"item.is_standard\"\n                    >\n                        <ion-select-option value=\"1\">合格</ion-select-option>\n                        <ion-select-option value=\"0\">不合格</ion-select-option>\n                    </ion-select>\n                </div>\n                <div class=\"col-sm-6\" *ngIf=\"item.is_standard == 0\">\n                    <input\n                        name=\"other0+{{idx}}\"\n                        type=\"text\"\n                        [(ngModel)]=\"item.description\"\n                        class=\"form-control\"\n                        required\n                        placeholder=\"请输入不合格的理由\"\n                    />\n                </div>\n            </div>\n        </div>\n\n        <ion-button\n            (click)=\"submit()\"\n            [expand]='\"block\"'\n            color=\"dark\"\n            [disabled]=\"!inspectionInfo.sku_sys.SinglePackingSizeLength  || \n                  !inspectionInfo.sku_sys.SinglePackingSizeWidth  || \n                  !inspectionInfo.sku_sys.SinglePackingSizeHight ||\n                  !inspectionInfo.sku_sys.BarCode ||\n                  !inspectionInfo.sku_sys.RoughWeight ||\n                  submitClicked\"\n            >提交</ion-button\n        >\n    </form>\n\n    <div class=\"slider_box\" *ngIf='type==\"done\"'>\n        <table\n            class=\"table table-striped table-condensed table-responsive table-hover table-condensed table-text-no-break\"\n        >\n            <thead>\n                <tr>\n                    <td>检验项目</td>\n                    <td>源数据</td>\n                    <td>验货数据</td>\n                    <td>自检图片</td>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td>条形码</td>\n                    <td>{{selfTest.data.sku_sys.BarCode.org}}</td>\n                    <td>{{selfTest.data.sku_sys.BarCode.new}}</td>\n                    <td imgGallery>\n                        <div *ngFor=\"let item of selfTest.data.sku_sys.BarCode.pic\">\n                            <img style=\"width: 30px;height: 30px;\" [src]=\"item\" alt=\"\" />\n                        </div>\n                    </td>\n                </tr>\n\n                <tr *ngIf=\"selfTest.data.sku_sys.rate_container!=1\">\n                    <td>外箱条形码</td>\n                    <td>{{selfTest.data.sku_sys.OutsideBarCode.org}}</td>\n                    <td>{{selfTest.data.sku_sys.OutsideBarCode.new}}</td>\n                    <td></td>\n                </tr>\n\n                <tr>\n                    <td>内箱长</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeLength.org}}</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeLength.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.SinglePackingSizeLength.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr>\n                    <td>内箱宽</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeWidth.org }}</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeWidth.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.SinglePackingSizeWidth.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr>\n                    <td>内箱高</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeHight.org }}</td>\n                    <td>{{selfTest.data.sku_sys.SinglePackingSizeHight.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.SinglePackingSizeHight.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr *ngIf=\"selfTest.data.sku_sys.rate_container!=1\">\n                    <td>外箱长</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeLength.org }}</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeLength.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.PackingSizeLength.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr *ngIf=\"selfTest.data.sku_sys.rate_container!=1\">\n                    <td>外箱宽</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeWidth.org }}</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeWidth.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.PackingSizeWidth.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr *ngIf=\"selfTest.data.sku_sys.rate_container!=1\">\n                    <td>外箱高</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeHight.org }}</td>\n                    <td>{{selfTest.data.sku_sys.PackingSizeHight.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.PackingSizeHight.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr>\n                    <td>毛重</td>\n                    <td>{{selfTest.data.sku_sys.RoughWeight.org }}</td>\n                    <td>{{selfTest.data.sku_sys.RoughWeight.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.RoughWeight.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr *ngIf=\"selfTest.data.sku_sys.rate_container!=1\">\n                    <td>外箱毛重</td>\n                    <td>{{selfTest.data.sku_sys.NetWeight.org }}</td>\n                    <td>{{selfTest.data.sku_sys.NetWeight.new }}</td>\n                    <td>\n                        <ng-template *ngFor=\"let item of selfTest.data.sku_sys.NetWeight.pic\">\n                            <img [src]=\"apiUrl+item\" alt=\"\" />\n                        </ng-template>\n                    </td>\n                </tr>\n\n                <tr *ngFor=\"let item of selfTest.data.sku_other;let idx=index\">\n                    <td>{{'额外数据'+idx+1}}</td>\n                    <td>{{item.InspectionRequiremen.org }}</td>\n                    <td>{{item.InspectionRequiremen.new }}</td>\n                    <td>\n                        <div *ngFor=\"let sItem of item.pic\">\n                            <img [src]=\"apiUrl+sItem\" alt=\"\" />\n                        </div>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/guard/InspectionReslove.reslove.ts":
/*!****************************************************!*\
  !*** ./src/app/guard/InspectionReslove.reslove.ts ***!
  \****************************************************/
/*! exports provided: InspectionReslove */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionReslove", function() { return InspectionReslove; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_task_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/task.service */ "./src/app/services/task.service.ts");




var InspectionReslove = /** @class */ (function () {
    function InspectionReslove(Router, taskService) {
        this.Router = Router;
        this.taskService = taskService;
    }
    InspectionReslove.prototype.resolve = function (route, state) {
        var sid = route.params['sid'], sku = route.params['sku'], cid = route.params['cid'];
        return this.taskService.toInspection({ id: sid, sku: sku, contract_id: cid });
    };
    InspectionReslove.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
        { type: _services_task_service__WEBPACK_IMPORTED_MODULE_3__["TaskService"] }
    ]; };
    InspectionReslove = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _services_task_service__WEBPACK_IMPORTED_MODULE_3__["TaskService"]])
    ], InspectionReslove);
    return InspectionReslove;
}());



/***/ }),

/***/ "./src/app/guard/acc-insp-reslove.ts":
/*!*******************************************!*\
  !*** ./src/app/guard/acc-insp-reslove.ts ***!
  \*******************************************/
/*! exports provided: AccInspReslove */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccInspReslove", function() { return AccInspReslove; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_task_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/task.service */ "./src/app/services/task.service.ts");




var AccInspReslove = /** @class */ (function () {
    function AccInspReslove(taskService, Router) {
        this.taskService = taskService;
        this.Router = Router;
    }
    AccInspReslove.prototype.resolve = function (route, state) {
        var taskId = route.params['sid'], contract_id = route.params['cid'];
        return this.taskService.getAccessbyTaskAndFac({ task_id: taskId, contract_id: contract_id });
    };
    AccInspReslove.ctorParameters = function () { return [
        { type: _services_task_service__WEBPACK_IMPORTED_MODULE_3__["TaskService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    AccInspReslove = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_task_service__WEBPACK_IMPORTED_MODULE_3__["TaskService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], AccInspReslove);
    return AccInspReslove;
}());



/***/ }),

/***/ "./src/app/pages/inspection/acc-inspec-form-remind.guard.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/inspection/acc-inspec-form-remind.guard.ts ***!
  \******************************************************************/
/*! exports provided: AccInspFormRemindGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccInspFormRemindGuard", function() { return AccInspFormRemindGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var AccInspFormRemindGuard = /** @class */ (function () {
    function AccInspFormRemindGuard(effectCtrl) {
        this.effectCtrl = effectCtrl;
    }
    AccInspFormRemindGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        if (!component.isFormDirty()) {
            var some = true;
            return window.confirm('您还未保存数据，确定要离开吗？');
        }
        else
            return true;
    };
    AccInspFormRemindGuard.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] }
    ]; };
    AccInspFormRemindGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"]])
    ], AccInspFormRemindGuard);
    return AccInspFormRemindGuard;
}());



/***/ }),

/***/ "./src/app/pages/inspection/acc-inspec/acc-inspec.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/pages/inspection/acc-inspec/acc-inspec.page.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luc3BlY3Rpb24vYWNjLWluc3BlYy9hY2MtaW5zcGVjLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/inspection/acc-inspec/acc-inspec.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/inspection/acc-inspec/acc-inspec.page.ts ***!
  \****************************************************************/
/*! exports provided: AccInspecPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccInspecPage", function() { return AccInspecPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_app_pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/pipe/acc-insp-obj.pipe */ "./src/app/pipe/acc-insp-obj.pipe.ts");






var AccInspecPage = /** @class */ (function () {
    function AccInspecPage(inspecService, effectCtrl, activeRoute, accinspPipe) {
        this.inspecService = inspecService;
        this.effectCtrl = effectCtrl;
        this.activeRoute = activeRoute;
        this.accinspPipe = accinspPipe;
        this.canLeave = false;
        this.accInspArrayMetadata = [];
        this.accInspArray = [];
    }
    AccInspecPage.prototype.ngOnInit = function () {
        var _this = this;
        this.activeRoute.data.subscribe(function (data) {
            _this.accInspArrayMetadata = data.accInsps;
            _this.accInspArray = _this.accinspPipe.transform(data.accInsps);
            var cache = {
                contract_id: data.accInsps[0].contract_id,
                task_id: data.accInsps[0].task_id,
                sku: data.accInsps[0].data[0].AccessoryCode,
                parentSku: data.accInsps[0].data[0].ProductCode,
            };
            sessionStorage.setItem('TASK_CONTRACT_INFO', JSON.stringify(cache));
        });
        this.title = JSON.parse(sessionStorage.getItem('TASK_DETAIL_PROJECT')).AccessoryName;
    };
    AccInspecPage.prototype.submit = function () {
        var _this = this;
        if (this.canSubmit()) {
            this.inspecService.submitDataAcc(this.accInspArray).subscribe(function (data) {
                if (data.status == 1) {
                    _this.canLeave = true;
                    _this.effectCtrl.showAlert({
                        header: '提示',
                        message: '上传成功',
                        backdropDismiss: false,
                        buttons: [
                            {
                                text: 'OK',
                                handler: function () {
                                    history.go(-1);
                                },
                            },
                        ],
                    });
                }
            });
        }
        else {
            this.effectCtrl.showAlert({
                header: '提示',
                message: '请完善验货表单！',
            });
        }
    };
    AccInspecPage.prototype.canSubmit = function () {
        var some = true;
        this.accInspArray.forEach(function (element) {
            element.data.forEach(function (acc, j) {
                for (var key in acc) {
                    if ((key == 'BarCode' || key == 'PackingType' || key == 'AccessoryCode' || key == 'ProductCode') &&
                        (acc[key] == '' || acc[key] == null)) {
                        some = !some;
                        return some;
                    }
                }
            });
        });
        return some;
    };
    AccInspecPage.prototype.ionViewWillLeave = function () {
        // sessionStorage.removeItem("INSPECTION_META_DATA")
        sessionStorage.removeItem('TASK_DETAIL_PROJECT');
        sessionStorage.removeItem('TASK_CONTRACT_INFO');
        console.log('4.0 ionViewWillLeave 当将要从页面离开时触发');
    };
    AccInspecPage.prototype.isFormDirty = function () {
        var _this = this;
        // && this.type=='undone'
        var some = true;
        this.accInspArray.forEach(function (accessOfTaskAndFac) {
            accessOfTaskAndFac.data.forEach(function (access) {
                if ((access.PackingType || access.BarCode) && _this.canLeave) {
                    some = false;
                    return;
                }
            });
        });
        return some;
    };
    AccInspecPage.ctorParameters = function () { return [
        { type: src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: src_app_pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_5__["AccInspObjPipe"] }
    ]; };
    AccInspecPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-acc-inspec',
            template: __webpack_require__(/*! raw-loader!./acc-inspec.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspection/acc-inspec/acc-inspec.page.html"),
            providers: [src_app_pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_5__["AccInspObjPipe"]],
            styles: [__webpack_require__(/*! ./acc-inspec.page.scss */ "./src/app/pages/inspection/acc-inspec/acc-inspec.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_inspection_service__WEBPACK_IMPORTED_MODULE_4__["InspectionService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            src_app_pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_5__["AccInspObjPipe"]])
    ], AccInspecPage);
    return AccInspecPage;
}());



/***/ }),

/***/ "./src/app/pages/inspection/insp-form-remind.guard.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/inspection/insp-form-remind.guard.ts ***!
  \************************************************************/
/*! exports provided: InspFormRemindGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspFormRemindGuard", function() { return InspFormRemindGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var InspFormRemindGuard = /** @class */ (function () {
    function InspFormRemindGuard() {
    }
    InspFormRemindGuard.prototype.canDeactivate = function (component, currentRoute, currentState, nextState) {
        if (!component.isFormDirty()) {
            return window.confirm('确定要离开吗？');
        }
        else
            return true;
    };
    InspFormRemindGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], InspFormRemindGuard);
    return InspFormRemindGuard;
}());



/***/ }),

/***/ "./src/app/pages/inspection/inspection.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/inspection/inspection.module.ts ***!
  \*******************************************************/
/*! exports provided: InspectionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionPageModule", function() { return InspectionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _acc_inspec_acc_inspec_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./acc-inspec/acc-inspec.page */ "./src/app/pages/inspection/acc-inspec/acc-inspec.page.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _inspection_inspection_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./inspection/inspection.page */ "./src/app/pages/inspection/inspection/inspection.page.ts");
/* harmony import */ var _pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../pipe/inspection-obj.pipe */ "./src/app/pipe/inspection-obj.pipe.ts");
/* harmony import */ var _insp_form_remind_guard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./insp-form-remind.guard */ "./src/app/pages/inspection/insp-form-remind.guard.ts");
/* harmony import */ var _pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../pipe/acc-insp-obj.pipe */ "./src/app/pipe/acc-insp-obj.pipe.ts");
/* harmony import */ var _acc_inspec_form_remind_guard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./acc-inspec-form-remind.guard */ "./src/app/pages/inspection/acc-inspec-form-remind.guard.ts");
/* harmony import */ var src_app_guard_InspectionReslove_reslove__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/guard/InspectionReslove.reslove */ "./src/app/guard/InspectionReslove.reslove.ts");
/* harmony import */ var src_app_guard_acc_insp_reslove__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/guard/acc-insp-reslove */ "./src/app/guard/acc-insp-reslove.ts");














var routes = [
    {
        path: 'inspection/sku/:sid/:sku/:cid/:type',
        resolve: {
            contracts: src_app_guard_InspectionReslove_reslove__WEBPACK_IMPORTED_MODULE_12__["InspectionReslove"],
        },
        canDeactivate: [_insp_form_remind_guard__WEBPACK_IMPORTED_MODULE_9__["InspFormRemindGuard"]],
        component: _inspection_inspection_page__WEBPACK_IMPORTED_MODULE_7__["InspectionPage"],
    },
    {
        path: 'inspection/acc/:sid/:cid',
        resolve: {
            accInsps: src_app_guard_acc_insp_reslove__WEBPACK_IMPORTED_MODULE_13__["AccInspReslove"],
        },
        canDeactivate: [_acc_inspec_form_remind_guard__WEBPACK_IMPORTED_MODULE_11__["AccInspFormRemindGuard"]],
        component: _acc_inspec_acc_inspec_page__WEBPACK_IMPORTED_MODULE_1__["AccInspecPage"],
    },
];
var InspectionPageModule = /** @class */ (function () {
    function InspectionPageModule() {
    }
    InspectionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)],
            providers: [_insp_form_remind_guard__WEBPACK_IMPORTED_MODULE_9__["InspFormRemindGuard"]],
            declarations: [_inspection_inspection_page__WEBPACK_IMPORTED_MODULE_7__["InspectionPage"], _acc_inspec_acc_inspec_page__WEBPACK_IMPORTED_MODULE_1__["AccInspecPage"], _pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_8__["inspectionObjPipe"], _pipe_acc_insp_obj_pipe__WEBPACK_IMPORTED_MODULE_10__["AccInspObjPipe"]],
        })
    ], InspectionPageModule);
    return InspectionPageModule;
}());



/***/ }),

/***/ "./src/app/pages/inspection/inspection/inspection.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/pages/inspection/inspection/inspection.page.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".form-group::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n\n.form-group .control-label {\n  height: 30px;\n  line-height: 30px;\n}\n\n.form-group .img-box {\n  width: 100%;\n  max-height: 300px;\n  overflow: hidden;\n}\n\n.form-group .img-box li {\n  width: 20%;\n  margin-bottom: 20px;\n  float: left;\n  overflow: hidden;\n  padding: 10px;\n  box-sizing: border-box;\n}\n\n.form-group .img-box li img {\n  width: 100%;\n  transform: rotateZ(-90deg);\n  height: auto;\n  max-height: 100px;\n}\n\n.form-group .file-box {\n  position: relative;\n}\n\n.form-group .file-box input {\n  opacity: 0;\n  font-size: 100px;\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n}\n\n.flex-box input {\n  margin-right: 20px;\n  margin-bottom: 5px;\n  width: 120px;\n  float: left;\n}\n\n.ion_select ion-select {\n  margin-bottom: 10px;\n  border: 1px solid #eee;\n}\n\n.sku_other_imgbox {\n  padding: 0 15px;\n  width: 100%;\n}\n\n.sku_other_imgbox li {\n  float: left;\n  width: 25%;\n  height: auto;\n  overflow: hidden;\n}\n\n.sku_other_imgbox li img {\n  width: 100%;\n  height: 100%;\n}\n\n.sku_other_imgbox::after {\n  content: \"\";\n  display: block;\n  clear: both;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9pbnNwZWN0aW9uL2luc3BlY3Rpb24vaW5zcGVjdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2luc3BlY3Rpb24vaW5zcGVjdGlvbi9pbnNwZWN0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREdJO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0FDQVI7O0FERUk7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQ0FSOztBRENRO0VBQ0ksVUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0FDQ1o7O0FEQVk7RUFDSSxXQUFBO0VBQ0EsMEJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNFaEI7O0FERUk7RUFDSSxrQkFBQTtBQ0FSOztBRENRO0VBQ0ksVUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0FDQ1o7O0FES0k7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUNGUjs7QURhSTtFQUNJLG1CQUFBO0VBQ0Esc0JBQUE7QUNWUjs7QURjQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDWEo7O0FEWUk7RUFDSSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ1ZSOztBRFdRO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNUWjs7QURhQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ1ZKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaW5zcGVjdGlvbi9pbnNwZWN0aW9uL2luc3BlY3Rpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvcm0tZ3JvdXA6OmFmdGVyIHtcbiAgICBjb250ZW50OiAnJztcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjbGVhcjogYm90aDtcbn1cblxuLmZvcm0tZ3JvdXAge1xuICAgIC5jb250cm9sLWxhYmVsIHtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICB9XG4gICAgLmltZy1ib3gge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgbWF4LWhlaWdodDogMzAwcHg7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIGxpIHtcbiAgICAgICAgICAgIHdpZHRoOiAyMCU7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgICAgICBpbWcge1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpO1xuICAgICAgICAgICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgICAgICAgICAgICBtYXgtaGVpZ2h0OiAxMDBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAuZmlsZS1ib3gge1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGlucHV0IHtcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgICAgICBmb250LXNpemU6IDEwMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICB0b3A6IDA7XG4gICAgICAgICAgICBsZWZ0OiAwO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uZmxleC1ib3gge1xuICAgIGlucHV0IHtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgIHdpZHRoOiAxMjBweDtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgfVxufVxuXG4uaW5zcGVjdGlvbi1pdGVtIHtcbn1cblxuLmluc3BlY3Rpb24taXRlbS1pbWcge1xufVxuXG4uaW9uX3NlbGVjdCB7XG4gICAgaW9uLXNlbGVjdCB7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNlZWU7XG4gICAgfVxufVxuXG4uc2t1X290aGVyX2ltZ2JveCB7XG4gICAgcGFkZGluZzogMCAxNXB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGxpIHtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIHdpZHRoOiAyNSU7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgaW1nIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxufVxuLnNrdV9vdGhlcl9pbWdib3g6OmFmdGVyIHtcbiAgICBjb250ZW50OiAnJztcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjbGVhcjogYm90aDtcbn1cbiIsIi5mb3JtLWdyb3VwOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjbGVhcjogYm90aDtcbn1cblxuLmZvcm0tZ3JvdXAgLmNvbnRyb2wtbGFiZWwge1xuICBoZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xufVxuLmZvcm0tZ3JvdXAgLmltZy1ib3gge1xuICB3aWR0aDogMTAwJTtcbiAgbWF4LWhlaWdodDogMzAwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uZm9ybS1ncm91cCAuaW1nLWJveCBsaSB7XG4gIHdpZHRoOiAyMCU7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIGZsb2F0OiBsZWZ0O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuLmZvcm0tZ3JvdXAgLmltZy1ib3ggbGkgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpO1xuICBoZWlnaHQ6IGF1dG87XG4gIG1heC1oZWlnaHQ6IDEwMHB4O1xufVxuLmZvcm0tZ3JvdXAgLmZpbGUtYm94IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmZvcm0tZ3JvdXAgLmZpbGUtYm94IGlucHV0IHtcbiAgb3BhY2l0eTogMDtcbiAgZm9udC1zaXplOiAxMDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG59XG5cbi5mbGV4LWJveCBpbnB1dCB7XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICB3aWR0aDogMTIwcHg7XG4gIGZsb2F0OiBsZWZ0O1xufVxuXG4uaW9uX3NlbGVjdCBpb24tc2VsZWN0IHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2VlZTtcbn1cblxuLnNrdV9vdGhlcl9pbWdib3gge1xuICBwYWRkaW5nOiAwIDE1cHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuLnNrdV9vdGhlcl9pbWdib3ggbGkge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDI1JTtcbiAgaGVpZ2h0OiBhdXRvO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLnNrdV9vdGhlcl9pbWdib3ggbGkgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnNrdV9vdGhlcl9pbWdib3g6OmFmdGVyIHtcbiAgY29udGVudDogXCJcIjtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNsZWFyOiBib3RoO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/inspection/inspection/inspection.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/inspection/inspection/inspection.page.ts ***!
  \****************************************************************/
/*! exports provided: InspectionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionPage", function() { return InspectionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../pipe/inspection-obj.pipe */ "./src/app/pipe/inspection-obj.pipe.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _services_inspection_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/inspection.service */ "./src/app/services/inspection.service.ts");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");








var InspectionPage = /** @class */ (function () {
    function InspectionPage(effectCtrl, activeRoute, inspecService, taskService, emptyPipe) {
        this.effectCtrl = effectCtrl;
        this.activeRoute = activeRoute;
        this.inspecService = inspecService;
        this.taskService = taskService;
        this.emptyPipe = emptyPipe;
        this.apiUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].apiUrl;
        this.fileUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].usFileUrl;
        this.canLeave = true;
        this.selfTest = {
            data: {
                sku_sys: {
                    BarCode: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    SinglePackingSizeLength: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    SinglePackingSizeWidth: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    SinglePackingSizeHight: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    OutsideBarCode: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    PackingSizeLength: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    PackingSizeWidth: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    PackingSizeHight: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    RoughWeight: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                    NetWeight: {
                        org: '',
                        new: '',
                        pic: [],
                    },
                },
                sku_other: [
                    {
                        InspectionRequiremen: {
                            new: '',
                            org: '',
                        },
                        pic: [],
                    },
                ],
                sku_acc: [
                    {
                        BarCode: {
                            new: '',
                            org: '',
                        },
                    },
                ],
            },
        };
        this.submitClicked = false; //提交按钮是否被点击过
        this.uploadData = {
            contract_id: null,
            data: null,
            sku: '',
            task_id: null,
        };
    }
    InspectionPage.prototype.ngOnInit = function () {
        var _this = this;
        this.activeRoute.data.subscribe(function (data) {
            _this.inspectionInfoMetaData = data.contracts.data;
            _this.inspectionInfo = _this.emptyPipe.transform(JSON.parse(JSON.stringify(_this.inspectionInfoMetaData)));
            _this.uploadData.contract_id = _this.inspectionInfoMetaData.sku_sys.contract_id;
            _this.uploadData.data = _this.inspectionInfo;
            _this.uploadData.sku = _this.inspectionInfoMetaData.sku_sys.ProductCode;
            _this.uploadData.task_id = data.contracts.task_id;
            sessionStorage.setItem('INSPECTION_META_DATA', JSON.stringify(_this.inspectionInfoMetaData));
            var cache = {
                contract_id: data.contracts.data.sku_sys.contract_id,
                task_id: data.contracts.task_id,
                sku: data.contracts.data.sku_sys.ProductCode,
            };
            sessionStorage.setItem('TASK_CONTRACT_INFO', JSON.stringify(cache));
        });
        this.activeRoute.params.subscribe(function (params) {
            _this.type = params.type;
            var param = {
                sku: params.sku,
                task_id: params.sid,
                contract_id: params.cid,
            };
            if (_this.type == 'done') {
                _this.taskService.getDoneSkuDetailByTaCaS(param).subscribe(function (data) {
                    _this.selfTest = data;
                    console.log(data, 'ssssssssss');
                });
            }
        });
        // this.title = JSON.parse(sessionStorage.getItem('TASK_DETAIL_PROJECT')).name
    };
    InspectionPage.prototype.ngOnDestroy = function () { };
    InspectionPage.prototype.ionViewWillLeave = function () {
        sessionStorage.removeItem('INSPECTION_META_DATA');
        sessionStorage.removeItem('TASK_DETAIL_PROJECT');
        sessionStorage.removeItem('TASK_CONTRACT_INFO');
        console.log('4.0 ionViewWillLeave 当将要从页面离开时触发');
    };
    InspectionPage.prototype.submit = function () {
        var _this = this;
        this.submitClicked = !this.submitClicked;
        this.inspecService.submitData(this.uploadData).subscribe(function (data) {
            if (data.status == 1) {
                _this.canLeave = true;
                _this.effectCtrl.showAlert({
                    header: '提示',
                    message: '提交成功',
                    backdropDismiss: false,
                    buttons: [
                        {
                            text: 'Ok',
                            handler: function () {
                                history.go(-1);
                            },
                        },
                    ],
                });
            }
        });
    };
    InspectionPage.prototype.isFormDirty = function () {
        if ((this.inspectionInfo.sku_sys.SinglePackingSizeLength ||
            this.inspectionInfo.sku_sys.SinglePackingSizeWidth ||
            this.inspectionInfo.sku_sys.SinglePackingSizeHight ||
            this.inspectionInfo.sku_sys.BarCode ||
            this.inspectionInfo.sku_sys.RoughWeight) &&
            this.type == 'undone') {
            this.canLeave = false;
        }
        return this.canLeave;
    };
    InspectionPage.prototype.canDeactivate = function () {
        return true;
    };
    InspectionPage.prototype.locationCompare = function (a, b) {
        if (a.is_standard == b.is_standard) {
            return true;
        }
        return false;
    };
    InspectionPage.ctorParameters = function () { return [
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _services_inspection_service__WEBPACK_IMPORTED_MODULE_6__["InspectionService"] },
        { type: src_app_services_task_service__WEBPACK_IMPORTED_MODULE_7__["TaskService"] },
        { type: _pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_2__["inspectionObjPipe"] }
    ]; };
    InspectionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-inspection',
            template: __webpack_require__(/*! raw-loader!./inspection.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/inspection/inspection/inspection.page.html"),
            providers: [_pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_2__["inspectionObjPipe"]],
            styles: [__webpack_require__(/*! ./inspection.page.scss */ "./src/app/pages/inspection/inspection/inspection.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_page_effect_service__WEBPACK_IMPORTED_MODULE_5__["PageEffectService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _services_inspection_service__WEBPACK_IMPORTED_MODULE_6__["InspectionService"],
            src_app_services_task_service__WEBPACK_IMPORTED_MODULE_7__["TaskService"],
            _pipe_inspection_obj_pipe__WEBPACK_IMPORTED_MODULE_2__["inspectionObjPipe"]])
    ], InspectionPage);
    return InspectionPage;
}());



/***/ }),

/***/ "./src/app/pipe/acc-insp-obj.pipe.ts":
/*!*******************************************!*\
  !*** ./src/app/pipe/acc-insp-obj.pipe.ts ***!
  \*******************************************/
/*! exports provided: AccInspObjPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccInspObjPipe", function() { return AccInspObjPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AccInspObjPipe = /** @class */ (function () {
    function AccInspObjPipe() {
    }
    AccInspObjPipe.prototype.transform = function (value, args) {
        var some = JSON.parse(JSON.stringify(value));
        some.forEach(function (element, i) {
            element.data.forEach(function (acc, j) {
                for (var key in acc) {
                    if (key == 'AccessoryCode' || key == 'ProductCode') {
                        acc[key] = acc[key];
                    }
                    else
                        acc[key] = '';
                }
            });
        });
        return some;
    };
    AccInspObjPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'accInspObj',
        })
    ], AccInspObjPipe);
    return AccInspObjPipe;
}());



/***/ }),

/***/ "./src/app/pipe/inspection-obj.pipe.ts":
/*!*********************************************!*\
  !*** ./src/app/pipe/inspection-obj.pipe.ts ***!
  \*********************************************/
/*! exports provided: inspectionObjPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inspectionObjPipe", function() { return inspectionObjPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var inspectionObjPipe = /** @class */ (function () {
    function inspectionObjPipe() {
    }
    inspectionObjPipe.prototype.transform = function (value, args) {
        var some = JSON.parse(JSON.stringify(value));
        for (var key in some.sku_sys) {
            some.sku_sys[key] = '';
        }
        some = this.sku_other_set_passed(some);
        some = this.sku_other_set_remark(some);
        return some;
    };
    inspectionObjPipe.prototype.sku_other_set_passed = function (project) {
        //默认设置为通过
        var some = JSON.parse(JSON.stringify(project));
        for (var key in some.sku_other) {
            some.sku_other[key].is_standard = 1;
        }
        return some;
    };
    inspectionObjPipe.prototype.sku_other_set_remark = function (project) {
        var some = JSON.parse(JSON.stringify(project));
        for (var key in some.sku_other) {
            some.sku_other[key].remark = some.sku_other[key].InspectionRequiremen;
        }
        return some;
    };
    inspectionObjPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'inspectionObj',
        })
    ], inspectionObjPipe);
    return inspectionObjPipe;
}());



/***/ }),

/***/ "./src/app/services/task.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/task.service.ts ***!
  \******************************************/
/*! exports provided: TaskService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskService", function() { return TaskService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var TaskService = /** @class */ (function () {
    function TaskService(http) {
        this.http = http;
    }
    TaskService.prototype.getTaskList = function () {
        //通过用户信息获取任务列表
        return this.http.get({ url: '/task' });
    };
    TaskService.prototype.getContractList = function (search) {
        return this.http.get({ url: '/schedule/contract-list', params: search }); //合同列表
    };
    TaskService.prototype.delTaskById = function (params) {
        //通过任务id删除任务
        return this.http.delete({ url: '/task/task-delete', params: { id: params.id } });
    };
    TaskService.prototype.upDateTask = function (params) {
        //修改任务
        return this.http.post({
            url: '/task/task-update',
            params: {
                id: params.id,
                user_id: params.user_id,
                contract_id: params.contract_id,
                date: params.date,
                count: params.count,
            },
        });
    };
    TaskService.prototype.addTask = function (params) {
        //添加任务
        return this.http.post({
            url: '/task/task-add',
            params: {
                user_id: params.user_id,
                contract_id: params.contract_id,
                date: params.date,
                count: params.count,
            },
        });
    };
    TaskService.prototype.getTaskById = function (taskId) {
        //通过任务id获取任务详情  sku-列表
        return this.http.get({ url: '/task/task-sku-list', params: { task_id: taskId } });
    };
    TaskService.prototype.toInspection = function (params) {
        //验货  （sku）
        return this.http.get({
            url: '/task/task-sku-view',
            params: { task_id: params.id, sku: params.sku, contract_id: params.contract_id },
        });
    };
    TaskService.prototype.getAccessbyTaskAndFac = function (params) {
        //验货   （acc）
        return this.http.get({
            url: '/task/task-acc-view',
            params: { task_id: params.task_id, contract_id: params.contract_id },
        });
    };
    TaskService.prototype.getPoListByTaskAndFactory = function (params) {
        //po列表
        return this.http.get({
            url: '/task/task-factory-contract',
            params: { task_id: params.task_id, factory_group: params.factory_group },
        });
    };
    TaskService.prototype.getSkuListByPoAndTask = function (task_id, contract_id) {
        return this.http.get({
            url: '/task/contract-sku-list',
            params: { task_id: task_id, contract_id: contract_id },
        });
    };
    TaskService.prototype.uploadTask = function (data) {
        //上传任务
        return this.http.post({ url: '/task/task-add', params: data });
    };
    TaskService.prototype.getScheduleList = function (contract_id) {
        //进度列表
        return this.http.get({ url: '/schedule/' + contract_id });
    };
    TaskService.prototype.updateSchedule = function (update) {
        //更新进度
        return this.http.post({ url: '/schedule', params: update });
    };
    TaskService.prototype.updateNeedSchedule = function (needScheduleParams) {
        return this.http.post({ url: '/schedule/update_schedule-isneed', params: needScheduleParams });
    };
    TaskService.prototype.getNeedSchedule = function (contract_id) {
        return this.http.get({ url: '/schedule/schedule-isneed', params: { contract_id: contract_id } });
    };
    TaskService.prototype.getHistoryList = function (contract_id) {
        return this.http.get({ url: '/schedule/history', params: { contract_id: contract_id } });
    };
    TaskService.prototype.getHistoryDetailByContract = function (id) {
        return this.http.get({ url: '/schedule/history-view', params: { id: id } });
    };
    TaskService.prototype.delayTrack = function (id) {
        return this.http.get({ url: '/schedule/delay-track', params: { contract_id: id } });
    };
    TaskService.prototype.recoveryDelay = function (id) {
        return this.http.get({ url: '/schedule/set-track', params: { contract_id: id } });
    };
    //////////////////////////////////////////////////////////////////////////////// 冗余api
    TaskService.prototype.getDoneTaskList = function () {
        return this.http.get({ url: '/task/inspection-result-task-list' });
    };
    TaskService.prototype.getDoneContractByTask = function (task_id) {
        return this.http.get({ url: '/task/inspection-result-contract-list', params: { task_id: task_id } });
    };
    TaskService.prototype.getDoneSkuByTaskAndContract = function (getPoParams) {
        return this.http.get({ url: '/task/inspection-result-contract-sku-list', params: getPoParams });
    };
    TaskService.prototype.getDoneSkuDetailByTaCaS = function (params) {
        return this.http.get({ url: '/task/sku-view', params: params });
    };
    TaskService.ctorParameters = function () { return [
        { type: _http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"] }
    ]; };
    TaskService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"]])
    ], TaskService);
    return TaskService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-inspection-inspection-module-es5.js.map