(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-evaluate-evaluate-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/evaluate/detail/detail.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/evaluate/detail/detail.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>评价详情</ion-title>\n        <ion-buttons slot=\"end\">\n            <!-- <ion-back-button defaultHref='/evaluate' text=\"返回\" color=\"white\" mode=\"md\"></ion-back-button> -->\n            <ion-button [routerLink]=\"['/evaluate']\">返回</ion-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"evaluate-detail\">\n    <div class=\"factory-eval\">\n        <ion-card mode=\"ios\" class=\"factory\">\n            <ion-card-header>\n                <ion-card-title color=\"primary\">工厂情况评价</ion-card-title>\n            </ion-card-header>\n\n            <ion-radio-group\n            [(ngModel)]=\"data.inspection_cooperation_level\"\n            [value]=\"data.inspection_cooperation_level\"\n            *ngIf=\"type == 'rework'\"\n        >\n            <ion-list-header>\n                <ion-label >1.返工痕迹   <span class=\"must-text\">*</span></ion-label>\n             \n            </ion-list-header>\n\n            <ion-item>\n                <ion-label>明显</ion-label>\n                <ion-radio slot=\"end\" value=\"0\" [checked]=\"data.inspection_cooperation_level == 0\"></ion-radio>\n            </ion-item>\n\n            <ion-item>\n                <ion-label>细微</ion-label>\n                <ion-radio slot=\"end\" value=\"1\" [checked]=\"data.inspection_cooperation_level == 1\"></ion-radio>\n            </ion-item>\n\n            <ion-item>\n                <ion-label>5⃣️</ion-label>\n                <ion-radio slot=\"end\" value=\"2\" [checked]=\"data.inspection_cooperation_level == 2\"></ion-radio>\n            </ion-item>\n\n            <ion-item>\n                <!-- *ngIf=\"data.inspection_cooperation_level != 1\" -->\n                <ion-textarea\n                 \n                    [(ngModel)]=\"data.inspection_cooperation_level_desc\"\n                    placeholder=\"请描述具体表现\"\n                ></ion-textarea>\n            </ion-item>\n        </ion-radio-group>\n\n\n            <ion-radio-group\n                [(ngModel)]=\"data.inspection_cooperation_level\"\n                [value]=\"data.inspection_cooperation_level\"\n            >\n                <ion-list-header>\n                    <ion-label >1.验货配合度   <span class=\"must-text\">*</span></ion-label>\n                 \n                </ion-list-header>\n\n                <ion-item>\n                    <ion-label>高</ion-label>\n                    <ion-radio slot=\"end\" value=\"0\" [checked]=\"data.inspection_cooperation_level == 0\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>一般</ion-label>\n                    <ion-radio slot=\"end\" value=\"1\" [checked]=\"data.inspection_cooperation_level == 1\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>低</ion-label>\n                    <ion-radio slot=\"end\" value=\"2\" [checked]=\"data.inspection_cooperation_level == 2\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <!-- *ngIf=\"data.inspection_cooperation_level != 1\" -->\n                    <ion-textarea\n                     \n                        [(ngModel)]=\"data.inspection_cooperation_level_desc\"\n                        placeholder=\"请描述具体表现\"\n                    ></ion-textarea>\n                </ion-item>\n            </ion-radio-group>\n\n            <ion-radio-group *ngIf=\"type == 'default'\">\n                <ion-list-header>\n                    <ion-label>2.工厂的仓储条件 <span class=\"must-text\">*</span></ion-label>\n                </ion-list-header>\n\n                <ion-item *ngFor=\"let item of storage_condition_ary\">\n                    <ion-label>{{ item.key }}</ion-label>\n                    <ion-checkbox [(ngModel)]=\"item.value\"></ion-checkbox>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>其他</ion-label>\n                    <ion-checkbox [(ngModel)]=\"other\"></ion-checkbox>\n                </ion-item>\n\n                <ion-item>\n                    <ion-textarea placeholder=\"请描述具体表现\" [(ngModel)]=\"data.storage_condition_desc\"></ion-textarea>\n                    <!-- *ngIf=\"other\" -->\n                </ion-item>\n            </ion-radio-group>\n\n            <ion-radio-group\n                [(ngModel)]=\"data.storage_condition_appraisement\"\n                [value]=\"data.storage_condition_appraisement\"\n                *ngIf=\"type == 'default'\">\n                <ion-list-header>\n                    <ion-label>3.工厂的仓储条件等级 <span class=\"must-text\">*</span></ion-label>\n                </ion-list-header>\n                <ion-item>\n                    <ion-label>优秀</ion-label>\n                    <ion-radio slot=\"end\" value=\"0\" [checked]=\"data.storage_condition_appraisement == 0\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>一般</ion-label>\n                    <ion-radio slot=\"end\" value=\"1\" [checked]=\"data.storage_condition_appraisement == 1\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>不合格</ion-label>\n                    <ion-radio slot=\"end\" value=\"2\" [checked]=\"data.storage_condition_appraisement == 2\"></ion-radio>\n                </ion-item>\n            </ion-radio-group>\n\n            <ion-radio-group\n                [(ngModel)]=\"data.remaining_storage_space_condition\"\n                [value]=\"data.remaining_storage_space_condition\"\n                *ngIf=\"type == 'default'\">\n                <ion-list-header>\n                    <ion-label>4.剩余仓储情况 <span class=\"must-text\">*</span></ion-label>\n                </ion-list-header>\n\n                <ion-item>\n                    <ion-label>充足</ion-label>\n                    <ion-radio slot=\"end\" value=\"0\" [checked]=\"data.remaining_storage_space_condition == 0\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>一般</ion-label>\n                    <ion-radio slot=\"end\" value=\"1\" [checked]=\"data.remaining_storage_space_condition == 1\"></ion-radio>\n                </ion-item>\n\n                <ion-item>\n                    <ion-label>紧张</ion-label>\n                    <ion-radio slot=\"end\" value=\"2\" [checked]=\"data.remaining_storage_space_condition == 2\"></ion-radio>\n                </ion-item>\n            </ion-radio-group>\n\n            <div *ngIf=\"type == 'default'\">\n                <div>\n                    <ion-list-header>\n                        <ion-label>5.工厂生产的主要产品类型</ion-label>\n                    </ion-list-header>\n                    <ion-textarea\n                        class=\"textarea\"\n                        [(ngModel)]=\"data.production_type\"\n                        placeholder=\"请输入工厂生产的主要产品类型\"\n                    ></ion-textarea>\n                </div>\n                <div>\n                    <ion-list-header>\n                        <ion-label>6.工厂情况</ion-label>\n                    </ion-list-header>\n                    <ion-textarea\n                        class=\"textarea\"\n                        [(ngModel)]=\"data.factory_situation\"\n                        placeholder=\"请输入工厂情况\"\n                    ></ion-textarea>\n                </div>\n            </div>\n        </ion-card>\n    </div>\n\n    <div class=\"sku-eval\">\n        <ion-card mode=\"ios\" class=\"factory\">\n            <ion-card-header>\n                <ion-card-title color=\"primary\">货号</ion-card-title>\n            </ion-card-header>\n\n            <ng-container *ngFor=\"let item of sku_appraisement; let i = index\">\n                <ion-radio-group (ionChange)=\"skuAppraisementChange($event, i)\">\n                    <ion-list-header>\n                        <ion-label>{{ i + 1 + '.' + item.sku }}</ion-label>\n                    </ion-list-header>\n\n                    <ion-item>\n                        <ion-label>通过</ion-label>\n                        <ion-radio slot=\"end\" value=\"0\" [checked]=\"item.appraisement == '0'\"></ion-radio>\n                    </ion-item>\n\n                    <ion-item>\n                        <ion-label>待定</ion-label>\n                        <ion-radio slot=\"end\" value=\"1\" [checked]=\"item.appraisement == '1'\"></ion-radio>\n                    </ion-item>\n\n                    <ion-item>\n                        <ion-label>不通过</ion-label>\n                        <ion-radio slot=\"end\" value=\"2\" [checked]=\"item.appraisement == '2'\"></ion-radio>\n                    </ion-item>\n\n                    <ion-item>\n                        <app-item-by-item-desc\n                            description=\"备注\"\n                            [ary]=\"item.desc\"\n                            (onComplete)=\"descEnter($event, i)\"\n                        ></app-item-by-item-desc>\n                    </ion-item>\n                </ion-radio-group>\n            </ng-container>\n        </ion-card>\n    </div>\n\n    <div class=\"submit\">\n        <ion-button expand=\"block\" (click)=\"submit()\" class=\"mb-20\">提交</ion-button>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/evaluate/evaluate.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/evaluate/evaluate.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header mode=\"ios\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>验货评价</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-searchbar\n        animated\n        clearInput\n        mode=\"ios\"\n        placeholder=\"输入工厂名检索\"\n        (ionChange)=\"filterFactory()\"\n        [(ngModel)]=\"getListParams.value\"\n    ></ion-searchbar>\n\n    <ion-card mode=\"ios\">\n        <ion-card-header>\n            <ion-card-title color=\"primary\">验货列表</ion-card-title>\n        </ion-card-header>\n        <ion-button fill=\"clear\" expand=\"full\" *ngIf=\"!list || !list.length\" (click)=\"ionViewWillEnter()\"\n            >重新获取</ion-button\n        >\n\n        <ion-item *ngFor=\"let item of list\">\n            <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\" class=\"w100\">\n                <div (click)=\"toDetail(item)\">{{item.factory_name}}</div>\n                <ion-badge color=\"success\" *ngIf=\"item.inspection_appraisement_id\">已评价</ion-badge>\n                <ion-badge color=\"danger\" *ngIf=\"!item.inspection_appraisement_id\">未评价</ion-badge>\n                <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n                    <div (click)=\"toDetail(item)\">{{item.apply_inspection_no}}</div>\n                    <ion-button\n                        class=\"ml-20\"\n                        [hidden]=\"!item.inspection_appraisement_id\"\n                        size=\"small\"\n                        (click)=\"cancel(item)\"\n                        >取消评价</ion-button\n                    >\n                </div>\n            </div>\n        </ion-item>\n\n        <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n            <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"正在加载\"> </ion-infinite-scroll-content>\n        </ion-infinite-scroll>\n        <p *ngIf=\"!list.length\" class=\"text-c \">暂无数据</p>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/evaluate/detail/detail.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/evaluate/detail/detail.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".textarea {\n  padding: 0 10px;\n}\n\n.mb-10 {\n  margin-bottom: 10px !important;\n}\n\n.storage > div {\n  margin: 0 auto;\n  width: 80%;\n}\n\n.mb-20 {\n  margin-bottom: 20px !important;\n}\n\nion-label {\n  margin-top: 15px !important;\n  color: #000;\n  display: flex;\n  align-items: center;\n  justify-content: left;\n}\n\nion-item ion-label {\n  color: #535353;\n  font-size: 14px;\n}\n\nion-item ion-textarea {\n  color: #535353;\n}\n\napp-item-by-item-desc {\n  width: 100%;\n}\n\n.submit {\n  padding: 10px !important;\n}\n\n.must-text {\n  color: red;\n  font-size: 28px;\n  margin-left: 10px;\n  margin-top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9ldmFsdWF0ZS9kZXRhaWwvZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9ldmFsdWF0ZS9kZXRhaWwvZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0ksZUFBQTtBQ0ZKOztBREtBO0VBQ0ksOEJBQUE7QUNGSjs7QURNSTtFQUNJLGNBQUE7RUFDQSxVQUFBO0FDSFI7O0FET0E7RUFDSSw4QkFBQTtBQ0pKOztBRE9BO0VBQ0ksMkJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7QUNKSjs7QURRSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0FDTFI7O0FET0k7RUFDSSxjQUFBO0FDTFI7O0FEU0E7RUFDRSxXQUFBO0FDTkY7O0FEYUE7RUFDRSx3QkFBQTtBQ1ZGOztBRGFBO0VBQ0ksVUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNWSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2V2YWx1YXRlL2RldGFpbC9kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXZhbHVhdGUtZGV0YWlsIHtcbiAgICAvLyBwYWRkaW5nOiA7XG59XG4udGV4dGFyZWEge1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbn1cblxuLm1iLTEwIHtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5zdG9yYWdlIHtcbiAgICA+IGRpdiB7XG4gICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICB3aWR0aDogODAlO1xuICAgIH1cbn1cblxuLm1iLTIwIHtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gICAgbWFyZ2luLXRvcDogMTVweCAhaW1wb3J0YW50O1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGxlZnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgICBpb24tbGFiZWwge1xuICAgICAgICBjb2xvcjogIzUzNTM1MztcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgIH1cbiAgICBpb24tdGV4dGFyZWEge1xuICAgICAgICBjb2xvcjogIzUzNTM1MztcbiAgICB9XG59XG5cbmFwcC1pdGVtLWJ5LWl0ZW0tZGVzY3tcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi8vIDpob3N0IDo6bmctZGVlcCBhcHAtaXRlbS1ieS1pdGVtLWRlc2MgcC5pdGVtIHNwYW46Zmlyc3QtY2hpbGQge1xuLy8gICAgIGRpc3BsYXk6IG5vbmU7XG4vLyB9XG5cbi5zdWJtaXR7XG4gIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcbn1cblxuLm11c3QtdGV4dHtcbiAgICBjb2xvcjogcmVkO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBtYXJnaW4tdG9wOiA4cHg7XG59IiwiLnRleHRhcmVhIHtcbiAgcGFkZGluZzogMCAxMHB4O1xufVxuXG4ubWItMTAge1xuICBtYXJnaW4tYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5zdG9yYWdlID4gZGl2IHtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHdpZHRoOiA4MCU7XG59XG5cbi5tYi0yMCB7XG4gIG1hcmdpbi1ib3R0b206IDIwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTVweCAhaW1wb3J0YW50O1xuICBjb2xvcjogIzAwMDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBsZWZ0O1xufVxuXG5pb24taXRlbSBpb24tbGFiZWwge1xuICBjb2xvcjogIzUzNTM1MztcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuaW9uLWl0ZW0gaW9uLXRleHRhcmVhIHtcbiAgY29sb3I6ICM1MzUzNTM7XG59XG5cbmFwcC1pdGVtLWJ5LWl0ZW0tZGVzYyB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uc3VibWl0IHtcbiAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xufVxuXG4ubXVzdC10ZXh0IHtcbiAgY29sb3I6IHJlZDtcbiAgZm9udC1zaXplOiAyOHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXRvcDogOHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/evaluate/detail/detail.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/evaluate/detail/detail.component.ts ***!
  \***********************************************************/
/*! exports provided: DetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailComponent", function() { return DetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../services/inspect-evaluate.service */ "./src/app/services/inspect-evaluate.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/storage.service */ "./src/app/services/storage.service.ts");






var DetailComponent = /** @class */ (function () {
    function DetailComponent(evalService, es, activeRoute, storage, router) {
        this.evalService = evalService;
        this.es = es;
        this.activeRoute = activeRoute;
        this.storage = storage;
        this.router = router;
        this.type = 'default';
        this.data = {
            inspection_cooperation_level: 0,
            reworkMark: 0,
            inspection_cooperation_level_desc: '',
            storage_condition_appraisement: '',
            storage_condition_desc: '',
            production_type: '',
            remaining_storage_space_condition: 0,
            factory_situation: '',
            sku_appraisement: [],
        };
        this.sku_appraisement = [];
        this.storage_condition_ary = [
            {
                key: '使用托盘',
                value: 0,
            },
            {
                key: '场地干燥',
                value: 0,
            },
            {
                key: '堆放整齐',
                value: 0,
            },
            {
                key: '有管理员',
                value: 0,
            },
        ];
        this.other = false;
        this.apply_inspection_id = null;
        this.apply_inspection_no = null;
        this.inspection_appraisement_id = null;
    }
    DetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activeRoute.params.subscribe(function (res) {
            _this.apply_inspection_id = res.applyId;
            _this.inspection_appraisement_id = res.id;
            _this.apply_inspection_no = res.applyNo;
        });
        var data = this.storage.get('EVALUATE_DETAIL_SKU');
        data &&
            data.forEach(function (elem) {
                _this.sku_appraisement.push({ sku: elem, desc: [{ text: '', level: '' }] });
            });
        if (!this.inspection_appraisement_id)
            return;
        this.getData();
    };
    DetailComponent.prototype.getData = function () {
        var _this = this;
        this.evalService.getEvaluateById(this.inspection_appraisement_id).subscribe(function (res) {
            if (!res.status)
                return;
            _this.data = res.data;
            _this.storage_condition_ary.forEach(function (elem, i) {
                _this.data.storage_condition.indexOf(i) != -1 && (_this.storage_condition_ary[i].value = 1);
            });
            if (_this.data.sku_appraisement && _this.data.sku_appraisement.length)
                _this.sku_appraisement = _this.data.sku_appraisement;
        });
    };
    DetailComponent.prototype.ionViewDidLeave = function () {
        this.storage.remove('EVALUATE_DETAIL_SKU');
    };
    DetailComponent.prototype.submit = function () {
        var _this = this;
        this.data.apply_inspection_id = this.apply_inspection_id;
        this.data.apply_inspection_no = this.apply_inspection_no;
        this.data.storage_condition = [];
        this.storage_condition_ary.forEach(function (elem, i) {
            elem.value && _this.data.storage_condition.push(i);
        });
        var params = JSON.parse(JSON.stringify(this.data));
        params.sku_appraisement = JSON.parse(JSON.stringify(this.sku_appraisement));
        delete params.updated_at;
        delete params.created_at;
        this.evalService.postInspectAppraisement(params).subscribe(function (res) {
            _this.es.showToast({
                color: res.status ? 'success' : 'danger',
                message: res.status ? res.message : '请填写完提交',
            });
            if (!res.status)
                return;
            setTimeout(function () {
                var route = location.hash.indexOf('detail') != -1 ? 'reload' : 'detail';
                _this.router.navigate([
                    '/evaluate/' + route,
                    res.data.inspection_appraisements_id,
                    _this.apply_inspection_id,
                    _this.apply_inspection_no,
                ]);
            }, 1000);
        });
    };
    DetailComponent.prototype.skuAppraisementChange = function (e, i) {
        this.sku_appraisement[i].appraisement = e.detail.value;
    };
    DetailComponent.prototype.descEnter = function (e, i) {
        this.sku_appraisement[i].desc = e;
    };
    DetailComponent.ctorParameters = function () { return [
        { type: _services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_3__["InspectEvaluateService"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
    ]; };
    DetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-detail',
            template: __webpack_require__(/*! raw-loader!./detail.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/evaluate/detail/detail.component.html"),
            styles: [__webpack_require__(/*! ./detail.component.scss */ "./src/app/pages/evaluate/detail/detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_3__["InspectEvaluateService"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_1__["PageEffectService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], DetailComponent);
    return DetailComponent;
}());



/***/ }),

/***/ "./src/app/pages/evaluate/evaluate.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/evaluate/evaluate.module.ts ***!
  \***************************************************/
/*! exports provided: EvaluatePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluatePageModule", function() { return EvaluatePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail/detail.component */ "./src/app/pages/evaluate/detail/detail.component.ts");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _evaluate_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./evaluate.page */ "./src/app/pages/evaluate/evaluate.page.ts");
/* harmony import */ var src_app_widget_widget_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/widget/widget.module */ "./src/app/widget/widget.module.ts");










var routes = [
    {
        path: 'evaluate',
        component: _evaluate_page__WEBPACK_IMPORTED_MODULE_8__["EvaluatePage"],
    },
    {
        path: 'evaluate/detail/:id/:applyId/:applyNo',
        component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__["DetailComponent"],
    },
    {
        path: 'evaluate/reload/:id/:applyId/:applyNo',
        component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__["DetailComponent"]
    }
];
var EvaluatePageModule = /** @class */ (function () {
    function EvaluatePageModule() {
    }
    EvaluatePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__["FlexLayoutModule"],
                src_app_widget_widget_module__WEBPACK_IMPORTED_MODULE_9__["WidgetModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild(routes)
            ],
            declarations: [_evaluate_page__WEBPACK_IMPORTED_MODULE_8__["EvaluatePage"], _detail_detail_component__WEBPACK_IMPORTED_MODULE_1__["DetailComponent"]],
        })
    ], EvaluatePageModule);
    return EvaluatePageModule;
}());



/***/ }),

/***/ "./src/app/pages/evaluate/evaluate.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/evaluate/evaluate.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w100 {\n  width: 100%;\n}\n\n.ml-20 {\n  margin-left: 20px !important;\n}\n\nion-item.js {\n  font-size: 14px;\n  --padding-start:0;\n  padding-left: 0 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Wb2x1bWVzL01hY2ludG9zaCBIRCAtIOaVsOaNri93ZWIvaGF3a2V5ZS1tb2JpbGUvc3JjL2FwcC9wYWdlcy9ldmFsdWF0ZS9ldmFsdWF0ZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2V2YWx1YXRlL2V2YWx1YXRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjs7QURFQTtFQUNFLDRCQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSwwQkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvZXZhbHVhdGUvZXZhbHVhdGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLncxMDAge1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG4ubWwtMjB7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtLmpzIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICAtLXBhZGRpbmctc3RhcnQ6MDtcbiAgcGFkZGluZy1sZWZ0OiAwICFpbXBvcnRhbnQ7XG59IiwiLncxMDAge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLm1sLTIwIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0uanMge1xuICBmb250LXNpemU6IDE0cHg7XG4gIC0tcGFkZGluZy1zdGFydDowO1xuICBwYWRkaW5nLWxlZnQ6IDAgIWltcG9ydGFudDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/evaluate/evaluate.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/evaluate/evaluate.page.ts ***!
  \*************************************************/
/*! exports provided: EvaluatePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluatePage", function() { return EvaluatePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/inspect-evaluate.service */ "./src/app/services/inspect-evaluate.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/page-effect.service */ "./src/app/services/page-effect.service.ts");







var EvaluatePage = /** @class */ (function () {
    function EvaluatePage(router, es, storage, InspectEval) {
        this.router = router;
        this.es = es;
        this.storage = storage;
        this.InspectEval = InspectEval;
        this.list = [];
        this.data = null;
        this.metaList = [];
        this.keywords = '';
        this.getListParams = {
            keywords: 'factory_name',
            value: '',
            page: 1,
        };
    }
    EvaluatePage.prototype.ngOnInit = function () { };
    EvaluatePage.prototype.ionViewWillEnter = function () {
        this.getListParams.page = 1;
        this.getList();
    };
    EvaluatePage.prototype.getList = function () {
        var _this = this;
        this.InspectEval.getEvaluateList(this.getListParams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (res) { return res.data; }))
            .subscribe(function (res) {
            _this.list = res.data;
            _this.metaList = JSON.parse(JSON.stringify(res.data));
            _this.getListParams.page = res.current_page + 1;
        });
    };
    EvaluatePage.prototype.loadData = function (event) {
        var _this = this;
        this.InspectEval.getEvaluateList(this.getListParams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (res) { return res.data; }))
            .subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.list = _this.list.concat(res.data);
                _this.metaList = JSON.parse(JSON.stringify(res.data));
                _this.getListParams.page = res.current_page + 1;
            }
            else {
                _this.es.showToast({
                    message: '别刷了，没有数据啦！',
                    color: 'danger',
                });
            }
            event.target.complete();
        });
    };
    EvaluatePage.prototype.toDetail = function (p) {
        this.router.navigate([
            '/evaluate/detail',
            p.inspection_appraisement_id ? p.inspection_appraisement_id : '000',
            p.apply_inspection_id,
            p.apply_inspection_no,
        ]);
        this.storage.set('EVALUATE_DETAIL_SKU', p.sku);
    };
    EvaluatePage.prototype.cancel = function (p) {
        var _this = this;
        this.es.showAlert({
            message: '确定要取消评价吗？',
            buttons: [
                {
                    text: '确定',
                    handler: function () {
                        _this.InspectEval.cancelInspectAppraisement(p.inspection_appraisement_id).subscribe(function (res) {
                            if (res.status) {
                                _this.es.showToast({
                                    color: 'success',
                                    message: res.message,
                                });
                                setTimeout(function () {
                                    _this.getListParams.page = 1;
                                    _this.getList();
                                }, 200);
                            }
                        });
                    },
                },
                {
                    text: '取消',
                },
            ],
        });
    };
    EvaluatePage.prototype.filterFactory = function (e) {
        var _this = this;
        this.getListParams.page = 1;
        this.InspectEval.getEvaluateList(this.getListParams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (res) { return res.data; }))
            .subscribe(function (res) {
            if (res.data && res.data.length) {
                _this.list = res.data;
                _this.getListParams.page = res.current_page + 1;
            }
            else {
                _this.es.showToast({
                    message: '暂未搜索到匹配的工厂',
                    color: 'danger',
                });
            }
        });
    };
    EvaluatePage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
        { type: _services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_1__["InspectEvaluateService"] }
    ]; };
    EvaluatePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-evaluate',
            template: __webpack_require__(/*! raw-loader!./evaluate.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/evaluate/evaluate.page.html"),
            styles: [__webpack_require__(/*! ./evaluate.page.scss */ "./src/app/pages/evaluate/evaluate.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _services_page_effect_service__WEBPACK_IMPORTED_MODULE_6__["PageEffectService"],
            _services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"],
            _services_inspect_evaluate_service__WEBPACK_IMPORTED_MODULE_1__["InspectEvaluateService"]])
    ], EvaluatePage);
    return EvaluatePage;
}());



/***/ }),

/***/ "./src/app/services/inspect-evaluate.service.ts":
/*!******************************************************!*\
  !*** ./src/app/services/inspect-evaluate.service.ts ***!
  \******************************************************/
/*! exports provided: InspectEvaluateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectEvaluateService", function() { return InspectEvaluateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var InspectEvaluateService = /** @class */ (function () {
    function InspectEvaluateService(http) {
        this.http = http;
    }
    InspectEvaluateService.prototype.getEvaluateList = function (obj) {
        //获取评价列表
        return this.http.get({ url: '/task/inspection_appraisement_list', params: obj });
    };
    InspectEvaluateService.prototype.getEvaluateById = function (inspection_appraisement_id) {
        return this.http.get({
            url: '/task/get_appraisement_data_by_id',
            params: { inspection_appraisement_id: inspection_appraisement_id },
        });
    };
    InspectEvaluateService.prototype.postInspectAppraisement = function (params) {
        return this.http.post({ url: '/task/inspection_appraisement', params: params });
    };
    InspectEvaluateService.prototype.cancelInspectAppraisement = function (inspection_appraisement_id) {
        return this.http.get({
            url: '/task/cancel_inspection_appraisement_by_id',
            params: { inspection_appraisement_id: inspection_appraisement_id },
        });
    };
    InspectEvaluateService.ctorParameters = function () { return [
        { type: _http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"] }
    ]; };
    InspectEvaluateService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_1__["HttpService"]])
    ], InspectEvaluateService);
    return InspectEvaluateService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-evaluate-evaluate-module-es5.js.map